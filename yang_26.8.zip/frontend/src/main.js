import {
  OpenFileDialog, SaveFile, SaveFileDialog,
  GetSettings, SaveSettings, DetectMaxima, InstallMaxima, KillMaxima,
  CheckLatexDeps, InstallLatex, CheckDocDeps, InstallPandoc,
  GeneratePDF, SavePDFDialog, SaveTexDialog, ExportMarkdown, ExportDocx, ExportOdt, SaveUploadedImage,
  ReverseSearch,
  PublicarEstadoResultado, AbrirXanelaResultado, DockResultado, GetEstadoResultado,
  AccionResultadoPDF, AccionResultadoTex, AccionResultadoMD, AccionResultadoDocx, AccionResultadoOdt,
  XerarContidoIA, XerarExercicioIA, XerarExameIA,
  GardarNaBiblioteca, ListarBiblioteca, EliminarDaBiblioteca,
  GetActualizacionYang, AplicarActualizacionYang,
  TaoContextoActivo, EnviarATarefaTao, TaoAlumnos, EnviarReparto,
  IdiomaPiztu,
} from '../bindings/matexe-wails/app.js'
import { Application, Events } from '@wailsio/runtime'
import { createEditor } from './editor.js'
import { createBlocksEditor } from './blocks.js'
import { createAssistant } from './assistant.js'
import glDict from '../../idiomas/gl.json'
import esDict from '../../idiomas/es.json'
import enDict from '../../idiomas/en.json'
import ptDict from '../../idiomas/pt.json'

// ── Idioma ───────────────────────────────────────────────────────────────
// gl.json é a fonte da verdade (todas as claves); es/en/pt poden estar
// incompletos (ou baleiros de todo, ver yang/idiomas/README.md) - I18N
// mestura sempre gl por baixo, así calquera clave sen traducir aínda amosa
// o galego en vez dun oco ou da propia clave crúa.
const DICTS = { gl: glDict, es: esDict, en: enDict, pt: ptDict }
let idiomaActual = 'gl'
let I18N = { ...glDict }
// idiomaPiztu: código que Piztu ten escollido (IdiomaPiztu(), ver app.go),
// "" se Yang arrincou sen contexto de Piztu (executable á man). Só un valor
// por defecto — resolto cedo no arranque, antes de que Opcións poida
// abrirse, e usado en openOptions/saveOptions para distinguir "segue a
// Piztu" (idioma: "" en Settings) de "elección explícita".
let idiomaPiztu = ''

function cargarIdioma(code) {
  idiomaActual = DICTS[code] ? code : 'gl'
  I18N = { ...glDict, ...(DICTS[idiomaActual] || {}) }
}

// t busca `clave` no dicionario activo; `fallback` (normalmente o propio
// texto galego xa escrito no HTML/JS) cobre o caso de arrincar antes de
// cargarIdioma() resolver, ou unha clave que nin sequera exista en gl.json
// por un despiste. `vars` interpola {nome} -> valor (ex. t('blocks.exercise.title', 'Exercicio {n}', {n: 3})).
function t(clave, fallback, vars) {
  let val = I18N[clave] ?? fallback ?? clave
  if (vars) {
    for (const k in vars) val = val.replaceAll(`{${k}}`, vars[k])
  }
  return val
}

// aplicarTraducions percorre o DOM estático (index.html) e substitúe cada
// texto marcado por data-i18n* polo valor do idioma activo. O texto galego
// que xa hai escrito en cada elemento serve de fallback (t() cae nel se
// falta a clave), así que non hai "oco" mentres carga nin se falla algo.
function aplicarTraducions() {
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    el.textContent = t(el.dataset.i18n, el.textContent)
  })
  document.querySelectorAll('[data-i18n-title]').forEach((el) => {
    el.title = t(el.dataset.i18nTitle, el.title)
  })
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    el.placeholder = t(el.dataset.i18nPlaceholder, el.placeholder)
  })
  document.querySelectorAll('[data-i18n-aria-label]').forEach((el) => {
    el.setAttribute('aria-label', t(el.dataset.i18nAriaLabel, el.getAttribute('aria-label')))
  })
  document.querySelectorAll('[data-i18n-html]').forEach((el) => {
    el.innerHTML = t(el.dataset.i18nHtml, el.innerHTML)
  })
}

const preview = document.getElementById('preview')
const seedInput = document.getElementById('seed')
const iterInput = document.getElementById('iterations')
const btnNew = document.getElementById('btnNew')
const btnOpen = document.getElementById('btnOpen')
const btnSave = document.getElementById('btnSave')
const btnSaveAs = document.getElementById('btnSaveAs')
const btnModeText = document.getElementById('btnModeText')
const btnModeBlocks = document.getElementById('btnModeBlocks')
const editorContainer = document.getElementById('editor')
const blocksContainer = document.getElementById('blocksEditor')
const matexeTagBar = document.getElementById('matexeTagBar')
const btnRun = document.getElementById('btnRun')
const btnKillMaxima = document.getElementById('btnKillMaxima')
const btnPrint = document.getElementById('btnPrint')
const btnPDF = document.getElementById('btnPDF')
const btnExportTex = document.getElementById('btnExportTex')
const btnExportMarkdown = document.getElementById('btnExportMarkdown')
const btnExportDocx = document.getElementById('btnExportDocx')
const btnExportOdt = document.getElementById('btnExportOdt')
const btnOptions = document.getElementById('btnOptions')
const btnAbout = document.getElementById('btnAbout')
const sobreOverlay = document.getElementById('sobreOverlay')
const btnAboutClose = document.getElementById('btnAboutClose')
const sobreVersion = document.getElementById('sobreVersion')
const sobreActualizacion = document.getElementById('sobreActualizacion')
const btnActualizarYang = document.getElementById('btnActualizarYang')
const statusEl = document.getElementById('status')
const warningsEl = document.getElementById('warnings')

const optionsOverlay = document.getElementById('optionsOverlay')
const optMaximaPath = document.getElementById('optMaximaPath')
const optCodeIni = document.getElementById('optCodeIni')
const optIAPreset = document.getElementById('optIAPreset')
const optIAApiKey = document.getElementById('optIAApiKey')
const optIAModel = document.getElementById('optIAModel')
const optIABaseURL = document.getElementById('optIABaseURL')
const optIABaseURLRow = document.getElementById('optIABaseURLRow')
const optLatexEngine = document.getElementById('optLatexEngine')
const optDecimais = document.getElementById('optDecimais')
const optDecimal = document.getElementById('optDecimal')
const optTimeout = document.getElementById('optTimeout')
const optXerarAoGardar = document.getElementById('optXerarAoGardar')
const optIdioma = document.getElementById('optIdioma')
const optExportPDF = document.getElementById('optExportPDF')
const optExportTex = document.getElementById('optExportTex')
const optExportMarkdown = document.getElementById('optExportMarkdown')
const optExportDocx = document.getElementById('optExportDocx')
const optExportOdt = document.getElementById('optExportOdt')
const btnDetect = document.getElementById('btnDetect')
const btnOptionsCancel = document.getElementById('btnOptionsCancel')
const btnOptionsSave = document.getElementById('btnOptionsSave')

const maximaWarning = document.getElementById('maximaWarning')
const btnInstallMaxima = document.getElementById('btnInstallMaxima')
const btnMaximaManual = document.getElementById('btnMaximaManual')
const btnMaximaDismiss = document.getElementById('btnMaximaDismiss')
const maximaManualOverlay = document.getElementById('maximaManualOverlay')
const btnMaximaManualClose = document.getElementById('btnMaximaManualClose')

const latexWarning = document.getElementById('latexWarning')
const latexWarningText = document.getElementById('latexWarningText')
const btnInstallLatex = document.getElementById('btnInstallLatex')
const btnLatexManual = document.getElementById('btnLatexManual')
const btnLatexDismiss = document.getElementById('btnLatexDismiss')
const latexManualOverlay = document.getElementById('latexManualOverlay')
const btnLatexManualClose = document.getElementById('btnLatexManualClose')

const pandocWarning = document.getElementById('pandocWarning')
const btnInstallPandoc = document.getElementById('btnInstallPandoc')
const btnPandocManual = document.getElementById('btnPandocManual')
const btnPandocDismiss = document.getElementById('btnPandocDismiss')
const pandocManualOverlay = document.getElementById('pandocManualOverlay')
const btnPandocManualClose = document.getElementById('btnPandocManualClose')

// Modo dúas xanelas (Opcións → Modo de traballo) - ver xanelaresultado.go.
// panePreview/panePreviewPlaceholder son exclusivos da xanela EDITOR
// (activarModoDobreEditor agocha unha e amosa a outra cando o resultado
// vive noutra xanela); btnReabrirResultado vive dentro do placeholder.
const panePreview = document.querySelector('.pane-preview')
const panePreviewPlaceholder = document.querySelector('.pane-preview-placeholder')
const placeholderAviso = document.querySelector('.placeholder-aviso')
const btnReabrirResultado = document.getElementById('btnReabrirResultado')
const btnDesacoplarResultado = document.getElementById('btnDesacoplarResultado')

// paneEditor/paneSplitter: divisor arrastrable entre código e resultado -
// ver initPaneSplitter, máis abaixo.
const paneEditor = document.querySelector('.pane-editor')
const paneSplitter = document.getElementById('paneSplitter')

let currentPath = null
let lastPDFBase64 = null
let lastLatexSource = null
let editMode = 'text'
let blocksEditor = null
// resultadoDesacoplado/codigoDeFondoActivo/intervalCodigoFondo: estado do
// panel de fondo en modo dúas xanelas - ver mostrarCodigoDeFondo/
// actualizarPanelFondo, máis abaixo. Declarados aquí (non xunto a esas
// funcións) porque switchMode xa os le dende o `switchMode('blocks')` do
// arranque (uns liñas máis abaixo), antes de chegar a esa sección.
let resultadoDesacoplado = false
let codigoDeFondoActivo = false
let intervalCodigoFondo = null
// previewZoom: nivel de zoom (Ctrl+/Ctrl-/Ctrl+0) das páxinas dentro do
// iframe de previsualización - ver pagesToPreviewHTML/ZOOM_SCRIPT. Vive aquí
// (non dentro do iframe) para sobrevivir a unha re-xeración (Xerar substitúe
// todo o srcdoc, o script inxectado esquecería o nivel); o propio script
// avisa dos cambios por postMessage (handleZoomMessage, máis abaixo).
let previewZoom = 1
// xerarAoGardarActivo reflicte Opcións → "Xerar automaticamente ao gardar"
// (Settings.XerarAoGardar, settings.go) - true por defecto (mesmo criterio
// có Go: !s.xerarAoGardar só es false cando o profesorado o desactivou
// explicitamente). saveFile/saveFileAs lena para decidir se chaman run()
// despois de gardar; actualízase ao arrincar (GetSettings, ao final deste
// ficheiro) e cada vez que se garda Opcións (saveOptions).
let xerarAoGardarActivo = true
// souXanelaResultado dío a propia URL coa que se creou esta xanela (ver
// AbrirXanelaResultado, xanelaresultado.go: "/?resultado=1"), dispoñible de
// forma síncrona dende o primeiro instante. true significa "esta xanela é
// a de resultado desacoplada, non teño editor propio" - run()/
// generatePDF()/exportTex()/exportMarkdown()/exportDocOffice() mírano para
// reenviar a acción ao proceso editor (accionRemota) no canto de intentar
// compilar cun editor baleiro.
const souXanelaResultado = new URLSearchParams(window.location.search).get('resultado') === '1'

const SAMPLE = `<H1>Documento de exemplo</H1>
REF: <EVAL>matexe_seed</EVAL><BR>
<HIDE>f(x):=x^2+1</HIDE>
f(x) = <EVAL>f(x)</EVAL><BR>
f'(x) = <EVAL>diff(f(x),x)</EVAL><BR>
Un número aleatorio: <EVAL>n1()</EVAL>
`

const editor = createEditor(document.getElementById('editor'), {
  initialDoc: SAMPLE,
  // onChange: só importa mentres o código de fondo (modo bloques desacoplado,
  // ver mostrarCodigoDeFondo) está activo - manexarCambioCodigoDeFondo xa se
  // encarga de ignoralo no resto de casos.
  onChange: () => manexarCambioCodigoDeFondo(),
})

// assistant: instancia única do asistente de IA (icona 🤖, ver
// assistant.js) - compartida entre o editor de Código (botón na barra de
// etiquetas, abaixo) e cada modal de anaco do editor de bloques (inxectado
// coma abrirAsistente en novoBlocksEditor).
const assistant = createAssistant({ t })

document.getElementById('btnAssistantCode').addEventListener('click', () => {
  const alvo = editor.getSelectionOrAll()
  assistant.open({
    tipo: 'documento',
    title: t('assistant.codeTitle', 'Asistente — Código'),
    getContent: () => alvo.text,
    setContent: (texto) => editor.replaceRange(alvo.from, alvo.to, texto),
  })
})

function novoBlocksEditor(initialDoc) {
  return createBlocksEditor(blocksContainer, {
    initialDoc, uploadImage: uploadImageFile, canUploadImage, generateWithAI, generateExerciseWithAI,
    generateExamWithAI, saveToLibrary, listLibrary, deleteFromLibrary, t,
    abrirAsistente: (opts) => assistant.open(opts),
  })
}

// Modo bloques por defecto: menos amigable arrincar en texto cru cando o
// obxectivo do editor de bloques é xustamente non ter que lembrar sintaxe.
switchMode('blocks')

// --- Modo de edición: texto (CodeMirror) <-> bloques (estilo Scratch) ---
// O documento .matex sempre viaxa como unha soa string cara ao backend
// (Generate/SaveFile/GeneratePDF xa usaban editor.getValue() antes deste
// modo); en modo bloques, syncToText() volca esa string en `editor` antes
// de calquera desas chamadas, para que o resto do fluxo non cambie nada.
function syncToText() {
  if (editMode === 'blocks' && blocksEditor) {
    editor.setValue(blocksEditor.getValue())
  }
}

// fileToBase64/uploadImageFile: única ponte entre blocks.js (que non fala
// nunca cos bindings Wails, ver blocks.js) e SaveUploadedImage. dirOf xa
// existe embaixo, reutilizado tal cal por generatePDF.
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '')
    reader.onerror = () => reject(reader.error)
    reader.readAsDataURL(file)
  })
}

async function uploadImageFile(file) {
  return SaveUploadedImage({
    baseDir: dirOf(currentPath),
    fileName: file.name,
    dataB64: await fileToBase64(file),
  })
}

// canUploadImage: comprobación previa (← botón "Escoller ficheiro…" do
// bloque Imaxe) para non abrir o selector do sistema cando aínda non hai
// onde gardar a imaxe - SaveUploadedImage esixe baseDir non baleiro (garda
// as imaxes canda o .matex, ver app.go), e dirOf(currentPath) só é "" cando
// o exame é novo e aínda non se gardou. Devolve null se se pode subir, ou a
// mensaxe a amosar se non.
function canUploadImage() {
  return currentPath ? null : t('blocks.imageUpload.needSave', 'Garda o exame primeiro (Ctrl+S) para poder engadir imaxes.')
}

// generateWithAI: única ponte entre blocks.js (botón ✨) e XerarContidoIA -
// mesmo criterio que uploadImageFile para a subida de imaxes.
async function generateWithAI(tipo, peticion) {
  return XerarContidoIA(tipo, peticion)
}

// generateExerciseWithAI: mesmo criterio, para o botón "✨ Exercicio con IA"
// (crea un exercicio enteiro, non un anaco solto).
async function generateExerciseWithAI(peticion) {
  return XerarExercicioIA(peticion)
}

// generateExamWithAI: mesmo criterio, para o botón "✨ Exame completo con
// IA" (crea VARIOS exercicios de vez, a partir dun tema e dun número de
// exercicios). modeloFiles é opcional: File[] (PDF) que blocks.js recolle
// dun <input type="file"> normal, convertidos aquí a base64 (mesmo xeito ca
// fileToBase64/uploadImageFile) antes de mandarllos ao backend.
async function generateExamWithAI(tema, numExercicios, modeloFiles) {
  const modelos = []
  for (const file of modeloFiles || []) {
    modelos.push({ fileName: file.name, dataB64: await fileToBase64(file) })
  }
  return XerarExameIA(tema, numExercicios, modelos)
}

// saveToLibrary/listLibrary/deleteFromLibrary: única ponte entre blocks.js
// (botóns "💾"/"📚 Biblioteca") e GardarNaBiblioteca/ListarBiblioteca/
// EliminarDaBiblioteca - mesmo criterio que as pontes de IA de enriba.
async function saveToLibrary(nome, tipo, contido) {
  return GardarNaBiblioteca(nome, tipo, contido)
}
async function listLibrary() {
  return ListarBiblioteca()
}
async function deleteFromLibrary(id) {
  return EliminarDaBiblioteca(id)
}

function switchMode(mode) {
  if (mode === editMode) return
  if (mode === 'blocks') {
    if (!blocksEditor) {
      blocksEditor = novoBlocksEditor(editor.getValue())
    } else {
      blocksEditor.setValue(editor.getValue())
    }
    editorContainer.classList.add('hidden')
    matexeTagBar.classList.add('hidden')
    blocksContainer.classList.remove('hidden')
    blocksEditor.focus()
  } else {
    syncToText()
    blocksContainer.classList.add('hidden')
    editorContainer.classList.remove('hidden')
    matexeTagBar.classList.remove('hidden')
    editor.focus()
  }
  editMode = mode
  actualizarPanelFondo()
  btnModeText.classList.toggle('active', mode === 'text')
  btnModeBlocks.classList.toggle('active', mode === 'blocks')
  btnModeText.setAttribute('aria-pressed', String(mode === 'text'))
  btnModeBlocks.setAttribute('aria-pressed', String(mode === 'blocks'))
}

btnModeText.addEventListener('click', () => switchMode('text'))
btnModeBlocks.addEventListener('click', () => switchMode('blocks'))

// --- Divisor arrastrable entre código e resultado (#paneSplitter) ---
// Só ten sentido en modo xanela única (con editor E resultado visibles á
// vez nesta mesma xanela) - en modo dúas xanelas, cada un vive na súa
// propia xanela OS, xa redimensionable arrastrando o propio bordo da
// xanela (ver entrarModoResultado/activarModoDobreEditor, que agochan
// #paneSplitter coma o resto do panel que xa non aplica).
const PANE_SPLITTER_KEY = 'yang.editorWidthPx'
const PANE_MIN_PX = 220 // mesmo mínimo có CSS (.pane-editor/.pane-preview min-width)

function aplicarLarguraEditor(px) {
  paneEditor.style.width = px + 'px'
}

// dragOverlay é un <div> transparente a pantalla completa que só existe
// mentres se arrastra o divisor - sen el, en canto o rato pasa por riba do
// <iframe id="preview"> (á dereita) o arrastre "atascábase": un iframe ten
// o seu propio documento, así que os mousemove que caen enriba del non
// chegan ao listener do documento principal (window) - só se notaba cara á
// dereita porque cara á esquerda o rato nunca sae do panel de código, sen
// iframe polo medio. O overlay tápao todo (z-index alto) e recibe el os
// eventos no seu lugar, coma calquera <div> normal do documento principal.
let dragOverlay = null
function crearDragOverlay() {
  const div = document.createElement('div')
  div.className = 'pane-splitter-overlay'
  document.body.appendChild(div)
  return div
}

function initPaneSplitter() {
  // Largura gardada de sesións anteriores (localStorage - preferencia
  // puramente visual desta máquina, non fai falla pasar por Opcións/Go).
  const gardada = parseInt(localStorage.getItem(PANE_SPLITTER_KEY), 10)
  if (gardada) aplicarLarguraEditor(gardada)

  let arrastrando = false

  paneSplitter.addEventListener('mousedown', (e) => {
    arrastrando = true
    paneSplitter.classList.add('dragging')
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'
    dragOverlay = crearDragOverlay()
    e.preventDefault()
  })

  window.addEventListener('mousemove', (e) => {
    if (!arrastrando) return
    const panesRect = paneEditor.parentElement.getBoundingClientRect()
    const max = panesRect.width - PANE_MIN_PX - paneSplitter.offsetWidth
    const px = Math.min(Math.max(e.clientX - panesRect.left, PANE_MIN_PX), max)
    aplicarLarguraEditor(px)
  })

  window.addEventListener('mouseup', () => {
    if (!arrastrando) return
    arrastrando = false
    paneSplitter.classList.remove('dragging')
    document.body.style.cursor = ''
    document.body.style.userSelect = ''
    if (dragOverlay) {
      dragOverlay.remove()
      dragOverlay = null
    }
    localStorage.setItem(PANE_SPLITTER_KEY, String(paneEditor.getBoundingClientRect().width))
  })
}
initPaneSplitter()

// Barra de etiquetas Matexe: mesma acción cós atallos Ctrl+M/E/H/P/T de
// editor.js, pero visible e clicable - un só listener delegado en vez dun
// por botón.
matexeTagBar.addEventListener('click', (e) => {
  const btn = e.target.closest('.matexe-tag-btn')
  if (btn) editor.wrapTag(btn.dataset.tag)
})

// --- Semente: aleatoria por defecto, contador simple (1, 2, 3...) en canto
// se toca a frecha. Un valor aleatorio evita que se xere sempre o mesmo
// exame se ninguén cambia nada; pero mover a frecha ±1 dende ese número
// grande non serviría de nada ("versión 84719, 84718..."), así que o
// primeiro toque "esquece" o aleatorio e empeza en 1.
let seedIsRandom = true
let prevSeedValue = String(Math.floor(Math.random() * 100000))
seedInput.value = prevSeedValue

seedInput.addEventListener('input', () => {
  if (seedIsRandom) {
    seedIsRandom = false
    const diff = Number(seedInput.value) - Number(prevSeedValue)
    if (Math.abs(diff) === 1) {
      // A frecha (ou ↑/↓ do teclado) moveu o valor un paso: é o primeiro
      // "toque", non escritura manual - reinicia a secuencia en 1.
      seedInput.value = '1'
    }
  }
  prevSeedValue = seedInput.value
})

function setStatus(text) {
  statusEl.textContent = text
}

// ── Panel de rexistro (← #log-panel de Piztu, mesmo comportamento: engade
// liñas, corta ás LOG_MAX_LINEAS máis recentes, autoscroll). Arrinca
// minimizado (ver .collapsed en index.html) - só se usa para depurar a
// xeración de documentos (Maxima/pdflatex/Pandoc), non é o foco da app. ──
const LOG_MAX_LINEAS = 500
const logOutput = document.getElementById('log-output')

function log(txt) {
  const linea = document.createElement('div')
  linea.textContent = txt
  logOutput.appendChild(linea)
  while (logOutput.childElementCount > LOG_MAX_LINEAS) {
    logOutput.removeChild(logOutput.firstChild)
  }
  logOutput.scrollTop = logOutput.scrollHeight
}

const logPanel = document.getElementById('log-panel')
const btnToggleLog = document.getElementById('btn-toggle-log')
btnToggleLog.addEventListener('click', () => {
  const colapsado = logPanel.classList.toggle('collapsed')
  btnToggleLog.textContent = colapsado ? '+' : '−'
})

const btnClearLog = document.getElementById('btn-clear-log')
btnClearLog.addEventListener('click', () => {
  logOutput.innerHTML = ''
})

function showWarnings(list) {
  warningsEl.innerHTML = ''
  if (!list || list.length === 0) {
    warningsEl.classList.remove('visible')
    return
  }
  for (const w of list) {
    const div = document.createElement('div')
    div.textContent = '⚠ ' + w
    warningsEl.appendChild(div)
  }
  warningsEl.classList.add('visible')
}

// pagesToPreviewHTML wraps the PDF's page images (one PNG per page, see
// GeneratePDFResult.PageImages / pdfPageImages in latexdoc.go) in a small
// scrollable HTML document for the preview iframe - it's what the webview
// actually renders, since WebKitGTK (Wails' engine on Linux) has no
// reliable native PDF viewer to point an <iframe>/<embed> at directly.
// Ctrl+clic nunha páxina -> "reverse search" (ver ReverseSearch en Go,
// reversesearch.go): a páxina é unha imaxe PLANA (PNG), sen texto nin
// nós - o único xeito de saber "que anaco a xerou" é medir o clic en
// píxeles relativos ao tamaño NATURAL da imaxe (non ao tamaño en pantalla,
// que pode estar reducido por max-width:100%) e mandarllo ao pai por
// postMessage; run() (main.js) escoita esa mensaxe e chama a ReverseSearch.
const REVERSE_SEARCH_SCRIPT = `
<script>
document.addEventListener('click', (e) => {
  if (!e.ctrlKey) return
  const img = e.target.closest('img.pdf-page')
  if (!img) return
  const rect = img.getBoundingClientRect()
  const scaleX = img.naturalWidth / rect.width
  const scaleY = img.naturalHeight / rect.height
  parent.postMessage({
    matexeReverseSearch: true,
    page: parseInt(img.dataset.page, 10),
    xPx: (e.clientX - rect.left) * scaleX,
    yPx: (e.clientY - rect.top) * scaleY,
  }, '*')
  e.preventDefault()
})
</script>`

// zoomScript: Ctrl+/Ctrl-/Ctrl+0 para as páxinas dentro do iframe de
// previsualización (e da xanela de resultado desacoplada, que reusa este
// mesmo HTML - ver entrarModoResultado). .pdf-page xa se axusta por defecto
// ao ancho dispoñible (max-width:100%), pero nun panel/xanela pequena iso
// pode quedar demasiado pequeno para ler - real report: "queda bastante
// pequeno, hai que forzar a vista". Ctrl+0 volve a ese axuste automático; o
// nivel avísase ao pai (handleZoomMessage) para sobrevivir a un "Xerar".
function zoomScript(initialZoom) {
  return `
<script>
let zoom = ${initialZoom}
function aplicarZoom() {
  document.querySelectorAll('.pdf-page').forEach((img) => {
    if (zoom === 1) { img.style.maxWidth = '100%'; img.style.width = ''; return }
    const disponible = document.body.clientWidth - 32 // 2x padding:1rem do body
    const axuste = Math.min(img.naturalWidth || disponible, disponible)
    img.style.maxWidth = 'none'
    img.style.width = Math.round(axuste * zoom) + 'px'
  })
}
document.addEventListener('keydown', (e) => {
  if (!(e.ctrlKey || e.metaKey)) return
  let novoZoom = zoom
  if (e.key === '+' || e.key === '=') novoZoom = Math.min(zoom * 1.2, 4)
  else if (e.key === '-' || e.key === '_') novoZoom = Math.max(zoom / 1.2, 0.3)
  else if (e.key === '0') novoZoom = 1
  else return
  e.preventDefault()
  zoom = novoZoom
  aplicarZoom()
  parent.postMessage({ matexeSetZoom: zoom }, '*')
})
window.addEventListener('load', aplicarZoom)
</script>`
}

// pagesToPreviewHTML wraps the PDF's page images (one PNG per page, see
// GeneratePDFResult.PageImages / pdfPageImages in latexdoc.go) in a small
// scrollable HTML document for the preview iframe - it's what the webview
// actually renders, since WebKitGTK (Wails' engine on Linux) has no
// reliable native PDF viewer to point an <iframe>/<embed> at directly.
function pagesToPreviewHTML(pageImages, zoom = previewZoom) {
  if (!pageImages || pageImages.length === 0) {
    // Mensaxe neutra a propósito: isto amósase tamén antes de xerar nada
    // (ex. a xanela de resultado en "Modo de traballo: Dúas xanelas" ábrese
    // xa dende o principio, sen nada aínda) - non se pode saber aquí se é
    // por iso ou por faltar pdftoppm de verdade. O aviso específico de
    // pdftoppm ausente (latexdoc.go) xa chega por separado, no panel de
    // avisos (showWarnings) despois de Xerar - non se perde información.
    return `<!doctype html><html><body><p style="font:14px sans-serif;color:#666;padding:1rem">${t('preview.noPages', 'Aínda non hai nada que amosar. Preme "Xerar" para compilar o documento.')}</p></body></html>`
  }
  // data-page 1-based, coma o espera synctex (e pdfPageImages en Go).
  const pages = pageImages.map((src, i) => `<img src="${src}" class="pdf-page" data-page="${i + 1}">`).join('\n')
  return `<!doctype html><html><head><meta charset="utf-8">
<style>
  body{margin:0;padding:1rem;background:#787878;display:flex;flex-direction:column;align-items:center;gap:1rem}
  .pdf-page{max-width:100%;box-shadow:0 2px 8px rgba(0,0,0,.35);background:#fff}
  @media print{ body{background:#fff;padding:0;gap:0} .pdf-page{box-shadow:none;max-width:100%;page-break-after:always} }
</style>
</head><body>
${pages}
${REVERSE_SEARCH_SCRIPT}
${zoomScript(zoom)}
</body></html>`
}

// publicarEstadoResultado (só na xanela EDITOR, modo dúas xanelas): envía
// o que run()/generatePDF() acaban de xerar ao proceso Go (Publica
// EstadoResultado, xanelaresultado.go), que o garda para atender a xanela
// de resultado (/estado para as páxinas, /accion/pdf|tex para gardalas sen
// recompilar, /accion/md|docx|odt para recompilalas cando llas pidan - ver
// accionRemota). Chamada barata e inofensiva aínda sen modo dúas xanelas
// activo (non hai ninguén escoitando).
function publicarEstadoResultado(result) {
  const nomeBase = currentPath ? currentPath.replace(/\.matex$/i, '').split(/[/\\]/).pop() : 'exame'
  PublicarEstadoResultado({
    source: editor.getValue(),
    codeIni: '',
    seed: parseInt(seedInput.value, 10) || 0,
    iterations: parseInt(iterInput.value, 10) || 1,
    baseDir: dirOf(currentPath),
  }, nomeBase, result.pageImages || [], result.warnings || [], result.pdfBase64 || '', result.latexSource || '')
}

// run compila o documento con Maxima + pdflatex (mesmo motor real que o
// PDF final, non a aproximación HTML+MathJax que usaba a versión anterior
// deste editor) e amosa cada páxina como imaxe na previsualización - así o
// que se ve é exactamente o que se vai imprimir/entregar.
async function run() {
  syncToText()
  btnRun.disabled = true
  setStatus(t('status.compilingPdf', 'Compilando PDF (Maxima + pdflatex)...'))
  showWarnings([])
  log('[XERAR] Compilando PDF (Maxima + pdflatex)...')
  try {
    const result = await GeneratePDF({
      source: editor.getValue(),
      codeIni: '',
      seed: parseInt(seedInput.value, 10) || 0,
      iterations: parseInt(iterInput.value, 10) || 1,
      baseDir: dirOf(currentPath),
    })
    lastPDFBase64 = result.pdfBase64
    lastLatexSource = result.latexSource
    preview.srcdoc = pagesToPreviewHTML(result.pageImages)
    showWarnings(result.warnings)
    publicarEstadoResultado(result)
    logPdflatex(result.log)
    setStatus(t('status.done', 'Feito.'))
    log('[XERAR] Feito.')
  } catch (err) {
    setStatus(t('status.error', 'Erro'))
    showWarnings([String(err)])
    log('[XERAR] ERRO: ' + err)
    checkMaxima()
    checkLatex()
  } finally {
    btnRun.disabled = false
  }
}

// logPdflatex vai ao panel de rexistro a saída de pdflatex/Maxima (campo
// `log` de GeneratePDFResult, latexdoc.go) cando hai algunha - liña a liña,
// co mesmo prefixo cós demais eventos do panel.
function logPdflatex(texto) {
  if (!texto) return
  for (const liña of texto.split('\n')) {
    if (liña.trim()) log('[PDFLATEX] ' + liña)
  }
}

// killMaxima recovers from a Maxima session that got stuck (an expression
// that never returns) MANUALLY, before the automatic per-call timeout
// (Opcións → "Tempo máximo de espera", cas.Session.SetTimeout) has a chance
// to fire on its own - it kills whatever Maxima process is currently
// running, which makes that in-flight call fail right away instead of
// waiting out the full timeout, so btnRun goes back to usable sooner.
async function killMaxima() {
  try {
    await KillMaxima()
    setStatus(t('status.maximaKilled', 'Sesión de Maxima interrompida. Volve premer Xerar.'))
    log('[XERAR] Sesión de Maxima interrompida.')
  } catch (err) {
    setStatus(String(err))
    log('[XERAR] ERRO ao reiniciar Maxima: ' + err)
  }
}

// newFile: limpa a pantalla (texto e bloques) para empezar un exame/práctica
// en branco, coma se se acabase de abrir Yang. Pregunta antes se hai
// contido sen gardar, para non perder traballo por un clic despistado.
function newFile() {
  syncToText()
  const hasContent = editor.getValue().trim() !== ''
  if (hasContent && !confirm(t('confirm.discardChanges', 'Vanse perder os cambios non gardados. Continuar?'))) return
  editor.setValue('')
  if (blocksEditor) blocksEditor.setValue('')
  currentPath = null
  lastPDFBase64 = null
  lastLatexSource = null
  preview.srcdoc = ''
  showWarnings([])
  setStatus(t('status.unsaved', 'sen gardar'))
}

async function openFile() {
  try {
    const res = await OpenFileDialog()
    if (!res) return
    editor.setValue(res.content)
    if (blocksEditor) blocksEditor.setValue(res.content)
    currentPath = res.path
    setStatus(currentPath)
  } catch (err) {
    setStatus(t('status.errorOpening', 'Erro ao abrir'))
    showWarnings([String(err)])
  }
}

// gardadoOk chama run() despois dun gardado con éxito, se Opcións → "Xerar
// automaticamente ao gardar" está activo (xerarAoGardarActivo) - así o
// aviso "Gardado: X" queda substituído polo propio resultado de run()
// (Compilando.../Feito.), que é máis relevante nese intre.
function gardadoOk() {
  if (xerarAoGardarActivo) run()
}

async function saveFile() {
  syncToText()
  try {
    if (currentPath) {
      await SaveFile(currentPath, editor.getValue())
      setStatus(t('status.saved', 'Gardado: ') + currentPath)
      gardadoOk()
    } else {
      const path = await SaveFileDialog('sen-nome.matex', editor.getValue())
      if (path) {
        currentPath = path
        setStatus(t('status.saved', 'Gardado: ') + currentPath)
        gardadoOk()
      }
    }
  } catch (err) {
    setStatus(t('status.errorSaving', 'Erro ao gardar'))
    showWarnings([String(err)])
  }
}

// saveFileAs abre sempre o selector para escoller nome/lugar, aínda que xa
// haxa un ficheiro aberto (a diferenza de saveFile/Ctrl+S, que unha vez hai
// currentPath sobrescribe ese mesmo ficheiro en silencio, sen preguntar -
// comportamento normal de "Gardar", pero sen isto non habería xeito de
// gardar unha copia con outro nome/lugar). Pásaselle a currentPath completa
// (non só o nome): SaveFileDialog xa reparte ela soa suxestión de nome e
// directorio de partida (splitDialogDefault, app.go), así o selector abre
// por defecto na mesma carpeta do ficheiro aberto, non nunha ao chou.
async function saveFileAs() {
  syncToText()
  try {
    const path = await SaveFileDialog(currentPath || 'sen-nome.matex', editor.getValue())
    if (path) {
      currentPath = path
      setStatus(t('status.saved', 'Gardado: ') + currentPath)
      gardadoOk()
    }
  } catch (err) {
    setStatus(t('status.errorSaving', 'Erro ao gardar'))
    showWarnings([String(err)])
  }
}

function printPreview() {
  if (!lastPDFBase64) {
    setStatus(t('status.generateBeforePrint', 'Xera antes de imprimir'))
    return
  }
  preview.contentWindow.focus()
  preview.contentWindow.print()
}

// accionRemota (só na xanela de RESULTADO, modo dúas xanelas): chama
// directamente un dos bindings AccionResultado{PDF,Tex,MD,Docx,Odt} (Go,
// xanelaresultado.go) - esta xanela non ten editor propio, así que non
// pode compilar nada ela soa; o proceso Go executa a MESMA lóxica que xa
// usan eses botóns na xanela única (GeneratePDF/ExportMarkdown/...) e
// devolve {path, warnings}, ou rexeita a promesa se hai erro.
async function accionRemota(accionFn, btn, statusCompiling, errKey, errFallback) {
  btn.disabled = true
  setStatus(statusCompiling)
  showWarnings([])
  log('[XERAR] ' + statusCompiling)
  try {
    const result = await accionFn()
    showWarnings(result.warnings || [])
    setStatus(result.path ? t('status.exported', 'Exportado: ') + result.path : t('status.unsaved', 'sen gardar'))
    log('[XERAR] ' + (result.path ? 'Exportado: ' + result.path : 'Feito.'))
  } catch (err) {
    setStatus(t(errKey, errFallback))
    showWarnings([String(err)])
    log('[XERAR] ERRO: ' + err)
  } finally {
    btn.disabled = false
  }
}

// exportTex garda o código .tex xa xerado (o que xa se compilou en
// run()/generatePDF(), sen recompilar de novo).
async function exportTex() {
  if (souXanelaResultado) {
    return accionRemota(AccionResultadoTex, btnExportTex, t('status.exporting', 'Exportando...'),
      'status.errorExporting', 'Erro ao exportar')
  }
  if (!lastLatexSource) {
    setStatus(t('status.generateBeforeExport', 'Xera antes de exportar'))
    return
  }
  try {
    const base = currentPath ? currentPath.replace(/\.matex$/i, '') + '.tex' : 'exame.tex'
    const path = await SaveTexDialog(base, lastLatexSource)
    if (path) {
      setStatus(t('status.exported', 'Exportado: ') + path)
      log('[XERAR] Exportado: ' + path)
    }
  } catch (err) {
    setStatus(t('status.errorExporting', 'Erro ao exportar'))
    showWarnings([String(err)])
    log('[XERAR] ERRO: ' + err)
  }
}

// exportMarkdown fai todo dun golpe (a diferenza de exportTex, que só garda
// o que xa había): abre o diálogo "Gardar como" e, se non se cancela,
// recompila con Maxima en modo Markdown e escribe o .md máis o seu cartafol
// images/ (gráficos/TikZ/imaxes subidas) directamente na ruta escollida -
// non hai preview Markdown na UI que se poida reutilizar. exportDocx/
// exportOdt (abaixo) seguen o mesmo esquema, pero pasando o resultado por
// Pandoc no canto de escribilo tal cal.
async function exportMarkdown() {
  if (souXanelaResultado) {
    return accionRemota(AccionResultadoMD, btnExportMarkdown, t('status.compilingMarkdown', 'Compilando Markdown...'),
      'status.errorExportingMarkdown', 'Erro ao exportar Markdown')
  }
  syncToText()
  btnExportMarkdown.disabled = true
  setStatus(t('status.compilingMarkdown', 'Compilando Markdown...'))
  showWarnings([])
  log('[XERAR] Compilando Markdown...')
  try {
    const base = currentPath ? currentPath.replace(/\.matex$/i, '') + '.md' : 'exame.md'
    const result = await ExportMarkdown({
      source: editor.getValue(),
      codeIni: '',
      seed: parseInt(seedInput.value, 10) || 0,
      iterations: parseInt(iterInput.value, 10) || 1,
      baseDir: dirOf(currentPath),
    }, base)
    showWarnings(result.warnings)
    setStatus(result.path ? t('status.exported', 'Exportado: ') + result.path : t('status.unsaved', 'sen gardar'))
    log('[XERAR] ' + (result.path ? 'Exportado: ' + result.path : 'Feito.'))
  } catch (err) {
    setStatus(t('status.errorExportingMarkdown', 'Erro ao exportar Markdown'))
    showWarnings([String(err)])
    log('[XERAR] ERRO: ' + err)
  } finally {
    btnExportMarkdown.disabled = false
  }
}

// inicializarEnvioATao amosa un botón extra "Enviar a Tao" só cando Yang foi
// aberto por Tao para editar unha tarefa de sesión (ver
// tao/yang_launch.go, contexto_tao.go, tarefa_tao.go) - abrindo Yang desde
// o mapa de Piztu ou á man, TaoContextoActivo() devolve false e este botón
// nin se crea. A diferenza de exportMarkdown, non hai diálogo "gardar
// como": xera o Markdown e empúxao decontado á pestana "Tarefa" de Tao
// (EnviarATarefaTao, Go) para que se actualice ao instante.
async function inicializarEnvioATao() {
  // A xanela de resultado non ten editor propio (ver souXanelaResultado
  // arriba) - este botón depende de editor.getValue(), así que só ten
  // sentido na xanela principal. Pendente se hai que estender o modo dúas
  // xanelas con isto tamén (mesmo patrón que accionRemota).
  if (souXanelaResultado) return

  let activo = false
  try {
    activo = await TaoContextoActivo()
  } catch (err) {
    return
  }
  if (!activo) return

  const btn = document.createElement('button')
  btn.id = 'btnEnviarTao'
  btn.textContent = '📤 ' + t('status.sendToTao', 'Enviar a Tao')
  btn.title = t('status.sendToTaoTitle', 'Xerar Markdown e actualizar a tarefa da sesión en Tao ao instante')
  btnExportMarkdown.insertAdjacentElement('afterend', btn)

  btn.addEventListener('click', async () => {
    syncToText()
    btn.disabled = true
    setStatus(t('status.sendingToTao', 'Enviando a Tao...'))
    showWarnings([])
    log('[XERAR] Enviando a Tao...')
    try {
      const result = await EnviarATarefaTao({
        source: editor.getValue(),
        codeIni: '',
        seed: parseInt(seedInput.value, 10) || 0,
        iterations: parseInt(iterInput.value, 10) || 1,
        baseDir: '',
      })
      showWarnings(result.warnings || [])
      setStatus(t('status.sentToTao', 'Enviado a Tao'))
      log('[XERAR] Enviado a Tao.')
    } catch (err) {
      setStatus(t('status.errorSendingToTao', 'Erro ao enviar a Tao'))
      showWarnings([String(err)])
      log('[XERAR] ERRO: ' + err)
    } finally {
      btn.disabled = false
    }
  })
}

// inicializarReparto amosa un botón extra "🎓 Repartir" a carón de "Enviar a
// Tao" cando, ademais de TaoContextoActivo, Tao mandou un alumnado non baleiro
// (TaoAlumnos, ver tao/yang_launch.go alumnosDaMateria) - docs/api-tao.md
// §11.2/§11.5. Sen alumnado (materia sen grupos, roster illegible...) este
// botón simplemente non se crea: só "Enviar a Tao" (a tarefa xeral) segue
// dispoñible, xeración normal, sen reparto.
async function inicializarReparto() {
  if (souXanelaResultado) return

  let activo = false
  try {
    activo = await TaoContextoActivo()
  } catch (err) {
    return
  }
  if (!activo) return

  let alumnos = []
  try {
    alumnos = (await TaoAlumnos()) || []
  } catch (err) {
    alumnos = []
  }
  if (alumnos.length === 0) return

  // Suxire Iteracións = nº de alumnos, só se o campo segue no valor por
  // defecto (non sobrescribe unha elección xa feita polo profesorado).
  if (iterInput.value === '' || iterInput.value === '1') {
    iterInput.value = String(alumnos.length)
  }

  const repartoAlumnos = alumnos.map((a) => ({ username: a.username, nome: a.nome || a.username, incluido: true, fallou: false }))

  const anchor = document.getElementById('btnEnviarTao') || btnExportMarkdown
  const btn = document.createElement('button')
  btn.id = 'btnRepartir'
  btn.textContent = '🎓 ' + t('reparto.abrirBoton', 'Repartir')
  btn.title = t('reparto.abrirBotonTitle', 'Xerar unha variante distinta para cada alumno e envialas coma tarefa individual')
  anchor.insertAdjacentElement('afterend', btn)

  const overlay = document.getElementById('repartoOverlay')
  const lista = document.getElementById('repartoLista')
  const aviso = document.getElementById('repartoAviso')
  const btnCancelar = document.getElementById('btnRepartirCancelar')
  const btnEnviar = document.getElementById('btnRepartirEnviar')

  function renderRepartoLista() {
    lista.innerHTML = ''
    repartoAlumnos.forEach((al, idx) => {
      const fila = document.createElement('div')
      fila.className = 'reparto-fila' + (al.incluido ? '' : ' reparto-excluido') + (al.fallou ? ' reparto-fallado' : '')

      const check = document.createElement('input')
      check.type = 'checkbox'
      check.checked = al.incluido
      check.addEventListener('change', () => {
        al.incluido = check.checked
        renderRepartoLista()
      })

      const nome = document.createElement('span')
      nome.className = 'reparto-nome'
      nome.textContent = (idx + 1) + '. ' + al.nome

      const up = document.createElement('button')
      up.type = 'button'
      up.textContent = '▲'
      up.disabled = idx === 0
      up.addEventListener('click', () => {
        ;[repartoAlumnos[idx - 1], repartoAlumnos[idx]] = [repartoAlumnos[idx], repartoAlumnos[idx - 1]]
        renderRepartoLista()
      })

      const down = document.createElement('button')
      down.type = 'button'
      down.textContent = '▼'
      down.disabled = idx === repartoAlumnos.length - 1
      down.addEventListener('click', () => {
        ;[repartoAlumnos[idx + 1], repartoAlumnos[idx]] = [repartoAlumnos[idx], repartoAlumnos[idx + 1]]
        renderRepartoLista()
      })

      fila.append(check, nome, up, down)
      lista.appendChild(fila)
    })
  }

  btn.addEventListener('click', () => {
    aviso.classList.add('hidden')
    renderRepartoLista()
    overlay.classList.remove('hidden')
  })
  btnCancelar.addEventListener('click', () => overlay.classList.add('hidden'))

  btnEnviar.addEventListener('click', async () => {
    const seleccionados = repartoAlumnos.filter((a) => a.incluido)
    if (seleccionados.length === 0) {
      aviso.textContent = t('reparto.senSeleccion', 'Selecciona polo menos un alumno.')
      aviso.classList.remove('hidden')
      return
    }

    // Desaxuste entre o que se xerou/revisou (Iteracións) e a selección
    // real: bloquea con confirmación explícita en vez dun aviso ignorable
    // (docs/api-tao.md §11.5) - evita mandar tarefas a medias por un
    // desconto mal feito.
    const iterations = parseInt(iterInput.value, 10) || 1
    if (iterations !== seleccionados.length) {
      const baseSeed = parseInt(seedInput.value, 10) || 0
      const msg = t('reparto.desaxusteConfirm',
        'Xeraches {iter} variante(s) pero seleccionaches {sel} alumno(s). ¿Repartir igualmente (unha variante por alumno seleccionado, sementes {seed}..{seedFin})?',
        { iter: iterations, sel: seleccionados.length, seed: baseSeed, seedFin: baseSeed + seleccionados.length - 1 })
      if (!confirm(msg)) return
    }

    syncToText()
    btnEnviar.disabled = true
    aviso.classList.add('hidden')
    setStatus(t('status.sendingReparto', 'Repartindo variantes...'))
    showWarnings([])
    log('[REPARTO] Repartindo a ' + seleccionados.length + ' alumno(s)...')
    try {
      const usernames = seleccionados.map((a) => a.username)
      const result = await EnviarReparto({
        source: editor.getValue(),
        codeIni: '',
        seed: parseInt(seedInput.value, 10) || 0,
        iterations: 1,
        baseDir: '',
      }, usernames)
      showWarnings(result.warnings || [])

      const resultados = result.resultados || []
      resultados.forEach((r) => {
        const al = repartoAlumnos.find((a) => a.username === r.username)
        if (al) al.fallou = !r.ok
      })
      const fallados = resultados.filter((r) => !r.ok)

      if (fallados.length === 0) {
        setStatus(t('status.repartoOk', 'Repartido a {n} alumno(s).', { n: resultados.length }))
        log('[REPARTO] Repartido a ' + resultados.length + ' alumno(s).')
        overlay.classList.add('hidden')
      } else {
        // Deixa marcados só os que fallaron, listos para reintentar
        // premendo "Repartir" outra vez sen tocar os que xa chegaron
        // (docs/api-tao.md §11.6, fallo parcial).
        repartoAlumnos.forEach((a) => { a.incluido = a.fallou })
        renderRepartoLista()
        const listaFallo = fallados.map((f) => f.username).join(', ')
        aviso.textContent = t('reparto.parcial',
          '{ok}/{total} enviados. Fallaron: {lista}. Quedan marcados para reintentar.',
          { ok: resultados.length - fallados.length, total: resultados.length, lista: listaFallo })
        aviso.classList.remove('hidden')
        setStatus(t('status.repartoParcial', 'Reparto parcial — mira os detalles'))
        log('[REPARTO] ERRO parcial: ' + listaFallo)
      }
    } catch (err) {
      setStatus(t('status.errorReparto', 'Erro ao repartir'))
      showWarnings([String(err)])
      log('[REPARTO] ERRO: ' + err)
    } finally {
      btnEnviar.disabled = false
    }
  })
}

// exportDocx/exportOdt seguen o mesmo criterio que exportMarkdown: todo dun
// golpe (diálogo "Gardar como" + recompilación en Maxima), sen preview
// propia na UI. A diferenza do .md, o corpo pasa por Pandoc no backend
// (docdoc.go) cunha plantilla de estilos "estilo exame" antes de escribirse
// - o .docx/.odt resultante xa vén listo para imprimir, coas imaxes
// incrustadas dentro do propio ficheiro.
async function exportDocOffice(accionRemotaFn, exportFn, btn, statusCompiling, ext, errKey, errFallback) {
  if (souXanelaResultado) {
    return accionRemota(accionRemotaFn, btn, statusCompiling, errKey, errFallback)
  }
  syncToText()
  btn.disabled = true
  setStatus(statusCompiling)
  showWarnings([])
  log('[XERAR] ' + statusCompiling)
  try {
    const base = currentPath ? currentPath.replace(/\.matex$/i, '') + ext : 'exame' + ext
    const result = await exportFn({
      source: editor.getValue(),
      codeIni: '',
      seed: parseInt(seedInput.value, 10) || 0,
      iterations: parseInt(iterInput.value, 10) || 1,
      baseDir: dirOf(currentPath),
    }, base)
    showWarnings(result.warnings)
    setStatus(result.path ? t('status.exported', 'Exportado: ') + result.path : t('status.unsaved', 'sen gardar'))
    log('[XERAR] ' + (result.path ? 'Exportado: ' + result.path : 'Feito.'))
  } catch (err) {
    setStatus(t(errKey, errFallback))
    showWarnings([String(err)])
    log('[XERAR] ERRO: ' + err)
    checkPandoc()
  } finally {
    btn.disabled = false
  }
}

function exportDocx() {
  return exportDocOffice(AccionResultadoDocx, ExportDocx, btnExportDocx,
    t('status.compilingDocx', 'Compilando Word (.docx)...'), '.docx',
    'status.errorExportingDocx', 'Erro ao exportar Word')
}

function exportOdt() {
  return exportDocOffice(AccionResultadoOdt, ExportOdt, btnExportOdt,
    t('status.compilingOdt', 'Compilando OpenDocument (.odt)...'), '.odt',
    'status.errorExportingOdt', 'Erro ao exportar OpenDocument')
}

function dirOf(path) {
  const m = /^(.*)[/\\][^/\\]*$/.exec(path || '')
  return m ? m[1] : ''
}

async function generatePDF() {
  if (souXanelaResultado) {
    return accionRemota(AccionResultadoPDF, btnPDF, t('status.exporting', 'Exportando...'),
      'status.errorCompilingPdf', 'Erro ao compilar PDF')
  }
  syncToText()
  btnPDF.disabled = true
  setStatus(t('status.compilingPdf', 'Compilando PDF (Maxima + pdflatex)...'))
  showWarnings([])
  log('[XERAR] Compilando PDF (Maxima + pdflatex)...')
  try {
    const result = await GeneratePDF({
      source: editor.getValue(),
      codeIni: '',
      seed: parseInt(seedInput.value, 10) || 0,
      iterations: parseInt(iterInput.value, 10) || 1,
      baseDir: dirOf(currentPath),
    })
    lastPDFBase64 = result.pdfBase64
    lastLatexSource = result.latexSource
    preview.srcdoc = pagesToPreviewHTML(result.pageImages)
    showWarnings(result.warnings)
    publicarEstadoResultado(result)
    logPdflatex(result.log)
    const base = currentPath ? currentPath.replace(/\.matex$/i, '') + '.pdf' : 'exame.pdf'
    const path = await SavePDFDialog(base, result.pdfBase64)
    setStatus(path ? t('status.pdfSaved', 'PDF gardado: ') + path : t('status.done', 'Feito.'))
    log('[XERAR] ' + (path ? 'PDF gardado: ' + path : 'Feito.'))
  } catch (err) {
    setStatus(t('status.errorCompilingPdf', 'Erro ao compilar PDF'))
    showWarnings([String(err)])
    log('[XERAR] ERRO: ' + err)
  } finally {
    btnPDF.disabled = false
  }
}

// --- Options modal ---

// IA_PRESETS mapea cada opción do selector "Provedor de IA" a que formato
// de fío fala (provedor, ver ia_client.go) e que enderezo de servidor usar
// - así o profesorado só escolle un nome de marca recoñecible, nunca
// escribe un enderezo nin sabe que "Qwen" e "ChatGPT" acaban falando o
// mesmo protocolo por baixo. "outro" queda cun enderezo baleiro a propósito
// (o único caso onde SI hai que escribilo á man: un provedor "compatible
// con OpenAI" que non está na lista).
const IA_PRESETS = {
  gemini: { provedor: 'gemini', baseURL: '', modeloExemplo: 'gemini-2.0-flash' },
  openai: { provedor: 'openai', baseURL: '', modeloExemplo: 'gpt-4o-mini' },
  anthropic: { provedor: 'anthropic', baseURL: '', modeloExemplo: 'claude-3-5-haiku-latest' },
  qwen: { provedor: 'openai', baseURL: 'https://dashscope.aliyuncs.com/compatible-mode/v1', modeloExemplo: 'qwen-plus' },
  perplexity: { provedor: 'openai', baseURL: 'https://api.perplexity.ai', modeloExemplo: 'sonar' },
  outro: { provedor: 'openai', baseURL: '', modeloExemplo: 'o-nome-exacto-do-modelo' },
}

// aplicarPresetIA actualiza o placeholder do modelo e (agás cando se está a
// prerrechear dende axustes xa gardados) o enderezo do servidor, e amosa a
// fila de "Enderezo do servidor" só para "outro" - os demais presets xa
// levan o seu enderezo fixo, non hai nada que o profesorado teña que ver
// nin tocar.
function aplicarPresetIA(preset, manterBaseURLGardado) {
  const p = IA_PRESETS[preset] || IA_PRESETS.gemini
  optIAModel.placeholder = p.modeloExemplo
  if (!manterBaseURLGardado) optIABaseURL.value = p.baseURL
  optIABaseURLRow.classList.toggle('hidden', preset !== 'outro')
}

optIAPreset.addEventListener('change', () => aplicarPresetIA(optIAPreset.value, false))

// aplicarVisibilidadeExportadores agocha/amosa os botóns da toolbar da
// previsualización (btnPDF/btnExportTex/.../btnExportOdt) segundo o que o
// profesorado marcou en Opcións. PDF/Tex/Markdown usan "!== false" (mesmo
// patrón ca xerarAoGardarActivo): un settings.json vello, ou un profesor
// que nunca abriu Opcións, non ten estas chaves (undefined) e os tres deben
// seguir visibles coma sempre. DOCX/ODT son o contrario - por defecto
// agochados (precisan Pandoc) - así que "!!" abonda.
function aplicarVisibilidadeExportadores(s) {
  btnPDF.classList.toggle('hidden', s.exportarPdf === false)
  btnExportTex.classList.toggle('hidden', s.exportarTex === false)
  btnExportMarkdown.classList.toggle('hidden', s.exportarMarkdown === false)
  btnExportDocx.classList.toggle('hidden', !s.exportarDocx)
  btnExportOdt.classList.toggle('hidden', !s.exportarOdt)
}

async function openOptions() {
  try {
    const s = await GetSettings()
    optMaximaPath.value = s.maximaPath || ''
    optCodeIni.value = s.codeIni || ''
    optIAPreset.value = s.iaPreset || 'gemini'
    aplicarPresetIA(optIAPreset.value, true) // manter o enderezo xa gardado, non o do preset
    optIAApiKey.value = s.iaApiKey || ''
    optIAModel.value = s.iaModel || ''
    optIABaseURL.value = s.iaBaseUrl || ''
    optLatexEngine.value = s.latexEngine || ''
    optDecimais.value = s.decimais || 2
    optDecimal.checked = !!s.decimal
    optTimeout.value = s.timeoutSegundos || 30
    optXerarAoGardar.checked = s.xerarAoGardar !== false
    optIdioma.value = s.idioma || idiomaPiztu || 'gl'
    optExportPDF.checked = s.exportarPdf !== false
    optExportTex.checked = s.exportarTex !== false
    optExportMarkdown.checked = s.exportarMarkdown !== false
    optExportDocx.checked = !!s.exportarDocx
    optExportOdt.checked = !!s.exportarOdt
    optionsOverlay.classList.remove('hidden')
  } catch (err) {
    setStatus(t('status.errorLoadingOptions', 'Erro ao cargar opcións'))
    showWarnings([String(err)])
  }
}

function closeOptions() {
  optionsOverlay.classList.add('hidden')
}

// refrescarIdioma aplica un cambio de idioma sen reiniciar Yang: retraduce
// o DOM estático (aplicarTraducions) e, se o editor de bloques xa existe,
// recréao co novo `t` (destroy + create) conservando o documento actual -
// blocksEditor non pode simplemente "redebuxarse" porque gardou `t` nun
// closure fixo ao crearse (ver novoBlocksEditor). O editor de texto
// (CodeMirror) non ten texto traducible, non fai falla tocalo.
function refrescarIdioma(code) {
  cargarIdioma(code)
  aplicarTraducions()
  if (blocksEditor) {
    const valorActual = blocksEditor.getValue()
    blocksEditor.destroy()
    blocksEditor = novoBlocksEditor(valorActual)
    if (editMode === 'blocks') blocksEditor.focus()
  }
  checkLatex() // latexWarningText leva texto dinámico interpolado, non só data-i18n
  pintarActualizacionYang() // sobreVersion/sobreActualizacion tamén levan texto interpolado
}

async function saveOptions() {
  try {
    // valorSeleccionado é o que se ve e se aplica; idiomaAGardar é o que se
    // persiste. Se o escollido coincide co idioma que Yang xa herdaría de
    // Piztu, gárdase "" (segue en modo automático: se Piztu cambia de idioma
    // máis adiante, Yang cámbiao con el). Só se garda un valor concreto cando
    // o profesorado escolleu algo DISTINTO — iso si é unha elección
    // explícita, que debe prevalecer sempre, mesmo sobre futuros cambios en
    // Piztu.
    const valorSeleccionado = optIdioma.value
    const idiomaAGardar = valorSeleccionado === idiomaPiztu ? '' : valorSeleccionado
    await SaveSettings({
      maximaPath: optMaximaPath.value.trim(),
      codeIni: optCodeIni.value,
      iaPreset: optIAPreset.value,
      iaProvedor: (IA_PRESETS[optIAPreset.value] || IA_PRESETS.gemini).provedor,
      iaApiKey: optIAApiKey.value.trim(),
      iaModel: optIAModel.value.trim(),
      iaBaseUrl: optIABaseURL.value.trim(),
      latexEngine: optLatexEngine.value,
      decimais: parseInt(optDecimais.value, 10) || 2,
      decimal: optDecimal.checked,
      timeoutSegundos: parseInt(optTimeout.value, 10) || 30,
      xerarAoGardar: optXerarAoGardar.checked,
      idioma: idiomaAGardar,
      exportarPdf: optExportPDF.checked,
      exportarTex: optExportTex.checked,
      exportarMarkdown: optExportMarkdown.checked,
      exportarDocx: optExportDocx.checked,
      exportarOdt: optExportOdt.checked,
    })
    xerarAoGardarActivo = optXerarAoGardar.checked
    aplicarVisibilidadeExportadores({
      exportarPdf: optExportPDF.checked,
      exportarTex: optExportTex.checked,
      exportarMarkdown: optExportMarkdown.checked,
      exportarDocx: optExportDocx.checked,
      exportarOdt: optExportOdt.checked,
    })
    if (valorSeleccionado !== idiomaActual) refrescarIdioma(valorSeleccionado)
    closeOptions()
    setStatus(t('status.optionsSaved', 'Opcións gardadas'))
  } catch (err) {
    setStatus(t('status.errorSavingOptions', 'Erro ao gardar opcións'))
    showWarnings([String(err)])
  }
}

async function detectMaxima() {
  const path = await DetectMaxima()
  optMaximaPath.value = path || ''
  setStatus(path ? t('status.found', 'Atopado: ') + path : t('status.maximaNotFound', 'Non se atopou Maxima'))
}

// --- Maxima missing warning / auto-install ---

async function checkMaxima() {
  try {
    const s = await GetSettings()
    maximaWarning.classList.toggle('hidden', !!s.maximaPath)
  } catch (err) {
    // ignore - the warning just won't show if settings can't be read
  }
}

async function installMaximaNow() {
  btnInstallMaxima.disabled = true
  btnInstallMaxima.textContent = t('status.installingMaxima', '⏳ Instalando... (pode pedir contrasinal)')
  try {
    const result = await InstallMaxima()
    if (result.success) {
      setStatus(t('status.maximaInstalled', 'Maxima instalado correctamente.'))
      maximaWarning.classList.add('hidden')
    } else {
      setStatus(t('status.autoInstallFailed', 'Non se puido instalar automaticamente'))
      showWarnings([result.log || t('status.unknownError', 'erro descoñecido')])
    }
  } catch (err) {
    setStatus(t('status.errorInstalling', 'Erro ao instalar'))
    showWarnings([String(err)])
  } finally {
    btnInstallMaxima.disabled = false
    btnInstallMaxima.textContent = t('banner.maxima.install', '⇩ Instalar automaticamente')
  }
}

// --- Aviso de LaTeX/pdftoppm ---
// Mesmo mecanismo que o de Maxima (checkMaxima/installMaximaNow) para o
// resto da canle de compilación: o motor LaTeX escollido en Opcións
// (GeneratePDF, latexdoc.go, xa falla cun erro que menciona ese mesmo
// motor se falta) e pdftoppm (necesario para a vista previa e para <TIKZ>
// en modo HTML). Chámase ao arrincar e despois de calquera instalación -
// "unha vez instalado desaparece o aviso" refírese a iso: non hai sondaxe
// en segundo plano, así que se se instala á man nun terminal á parte,
// desaparece cando se volva comprobar (arrinque seguinte, ou premendo
// calquera acción que chame checkLatex()).
async function checkLatex() {
  try {
    const s = await CheckLatexDeps()
    if (s.engineFound && s.pdftoppmFound) {
      latexWarning.classList.add('hidden')
      return
    }
    const faltan = []
    if (!s.engineFound) faltan.push(s.engine)
    if (!s.pdftoppmFound) faltan.push('pdftoppm (poppler-utils)')
    latexWarningText.textContent = t('status.latexMissing', '⚠ Falta {deps} neste equipo. É necesario para xerar/previsualizar PDFs.', {
      deps: faltan.join(t('status.latexMissing.and', ' e ')),
    })
    latexWarning.classList.remove('hidden')
  } catch (err) {
    // ignore - o aviso simplemente non se amosa se non se puido comprobar
  }
}

async function installLatexNow() {
  btnInstallLatex.disabled = true
  btnInstallLatex.textContent = t('status.installingLatex', '⏳ Instalando... (pode pedir contrasinal, tarda uns minutos)')
  try {
    const result = await InstallLatex()
    if (result.success) {
      setStatus(t('status.latexInstalled', 'LaTeX instalado correctamente.'))
      checkLatex()
    } else {
      setStatus(t('status.autoInstallFailed', 'Non se puido instalar automaticamente'))
      showWarnings([result.log || t('status.unknownError', 'erro descoñecido')])
    }
  } catch (err) {
    setStatus(t('status.errorInstalling', 'Erro ao instalar'))
    showWarnings([String(err)])
  } finally {
    btnInstallLatex.disabled = false
    btnInstallLatex.textContent = t('banner.latex.install', '⇩ Instalar automaticamente')
  }
}

// --- Aviso de Pandoc ---
// Mesmo mecanismo que Maxima/LaTeX (checkMaxima/checkLatex), pero para
// Pandoc - a única ferramenta extra que precisan ExportDocx/ExportOdt
// (docdoc.go), independente da canle de PDF (un profesor pode querer só
// Word/OpenDocument, sen tocar LaTeX en absoluto).
async function checkPandoc() {
  try {
    const s = await CheckDocDeps()
    pandocWarning.classList.toggle('hidden', !!s.pandocFound)
  } catch (err) {
    // ignore - o aviso simplemente non se amosa se non se puido comprobar
  }
}

async function installPandocNow() {
  btnInstallPandoc.disabled = true
  btnInstallPandoc.textContent = t('status.installingPandoc', '⏳ Instalando... (pode pedir contrasinal)')
  try {
    const result = await InstallPandoc()
    if (result.success) {
      setStatus(t('status.pandocInstalled', 'Pandoc instalado correctamente.'))
      pandocWarning.classList.add('hidden')
    } else {
      setStatus(t('status.autoInstallFailed', 'Non se puido instalar automaticamente'))
      showWarnings([result.log || t('status.unknownError', 'erro descoñecido')])
    }
  } catch (err) {
    setStatus(t('status.errorInstalling', 'Erro ao instalar'))
    showWarnings([String(err)])
  } finally {
    btnInstallPandoc.disabled = false
    btnInstallPandoc.textContent = t('banner.pandoc.install', '⇩ Instalar automaticamente')
  }
}

// --- Modo dúas xanelas (Opcións → Modo de traballo, ver xanelaresultado.go) ---

// entrarModoResultado configura ESTA xanela coma a "xanela de resultado":
// agocha todo agás o panel de resultado (que pasa a ocupar a xanela
// enteira, sen editor ao lado - ver .pane-preview en CSS, flex:1 abonda en
// canto .pane-editor está agochado) e escoita yang:resultado-actualizado
// (Events, emitido por PublicarEstadoResultado no proceso Go cada vez que
// o editor Xera/PDF) para manter as páxinas actualizadas - mesmo proceso,
// mesmo evento chega en tempo real, xa non fai falla sondar por HTTP coma
// no vello modo dous procesos.
function entrarModoResultado() {
  maximaWarning.classList.add('hidden')
  latexWarning.classList.add('hidden')
  pandocWarning.classList.add('hidden')
  document.getElementById('toolbar').classList.add('hidden')
  document.querySelector('.pane-editor').classList.add('hidden')
  paneSplitter.classList.add('hidden')

  const btnAcoplar = document.getElementById('btnAcoplarResultado')
  btnAcoplar.classList.remove('hidden')
  btnAcoplar.addEventListener('click', () => DockResultado())

  let ultimaVersion = -1
  function aplicarEstado(estado) {
    if (estado.version === ultimaVersion) return
    ultimaVersion = estado.version
    preview.srcdoc = pagesToPreviewHTML(estado.pageImages)
    showWarnings(estado.warnings)
  }

  // Subscribirse ANTES de pedir o snapshot inicial - se chega un Xerar()
  // entre medias, o evento non se perde (mesmo protocolo de hidratación
  // usado no spike de v3).
  Events.On('yang:resultado-actualizado', (e) => aplicarEstado(e.data))
  GetEstadoResultado().then(aplicarEstado).catch(() => {})
}

// activarModoDobreEditor agocha o panel de resultado NESTA xanela (o
// editor) cando Opcións → Modo de traballo == "dobre" - o resultado vive
// na outra xanela (entrarModoResultado), amosando no seu lugar un aviso +
// un botón para reabrila por se se pechou sen querer.
function activarModoDobreEditor() {
  resultadoDesacoplado = true
  panePreview.classList.add('hidden')
  panePreviewPlaceholder.classList.remove('hidden')
  actualizarPanelFondo()
}

// saírModoDobreEditor reverte activarModoDobreEditor - chámase ao recibir
// yang:resultado-pechado (Events, emitido por DockResultado/WindowClosing
// en xanelaresultado.go tanto co botón "Acoplar" coma coa X do xestor de
// xanelas). preview.srcdoc xa está actualizado (run()/generatePDF() sempre
// o escriben, mesmo con esta xanela agochada), así que abonda con
// amosala de novo - sen isto o aviso "resultado noutra xanela" quedaba
// colgado despois de pechar/acoplar a xanela de resultado.
function saírModoDobreEditor() {
  resultadoDesacoplado = false
  panePreviewPlaceholder.classList.add('hidden')
  panePreview.classList.remove('hidden')
  actualizarPanelFondo()
}

// refrescarCodigoDeFondo/manexarCambioCodigoDeFondo/mostrarCodigoDeFondo/
// agocharCodigoDeFondo/actualizarPanelFondo: en modo bloques CO resultado
// desacoplado, o panel de fondo (antes só o aviso "resultado noutra
// xanela") pasa a amosar o propio editor de código - o MESMO CodeMirror
// (con matexeTagBar, a súa barra de etiquetas) que en modo texto, movido
// aquí e totalmente editable - para poder escribir .matex a man sen ter
// que pechar a vista de bloques da esquerda. Sincronización BIDIRECCIONAL:
//   bloques -> código: sondeo cada 600ms (blocksEditor non ten evento de
//     cambio propio), pero só mentres o profesorado NON estea escribindo
//     no código (editorTenFoco) - senón perderíaselle o que vai escribindo.
//   código -> bloques: onChange de CodeMirror (editor.js), con debounce de
//     500ms mentres escribe + un volcado inmediato ao perder o foco (evita
//     que un sondeo colle a versión vella se o profesorado cambia a bloques
//     xusto despois de escribir, antes de que cumpra o debounce).
// sincronizandoDesdeBloques evita o ping-pong: o propio editor.setValue()
// de refrescarCodigoDeFondo dispara onChange coma calquera cambio, así que
// hai que distinguilo dun cambio real do profesorado.
// Só ten sentido en bloques: en texto o código xa está á vista na esquerda,
// e o aviso "resultado noutra xanela" (con "Reabrir") volve amosarse aí
// coma sempre - iso serve tamén de vía de escape se algunha vez fixese
// falla reabrir a xanela á man.
let sincronizandoDesdeBloques = false
let debounceCodigoDeFondo = null

function editorTenFoco() {
  return editorContainer.contains(document.activeElement)
}

function refrescarCodigoDeFondo() {
  if (editorTenFoco()) return
  const texto = blocksEditor ? blocksEditor.getValue() : ''
  if (texto === editor.getValue()) return
  sincronizandoDesdeBloques = true
  editor.setValue(texto)
  sincronizandoDesdeBloques = false
}

function volcarCodigoDeFondoABloques() {
  clearTimeout(debounceCodigoDeFondo)
  debounceCodigoDeFondo = null
  if (blocksEditor) blocksEditor.setValue(editor.getValue())
}

function manexarCambioCodigoDeFondo() {
  if (!codigoDeFondoActivo || sincronizandoDesdeBloques) return
  clearTimeout(debounceCodigoDeFondo)
  debounceCodigoDeFondo = setTimeout(volcarCodigoDeFondoABloques, 500)
}

// Ao perder o foco, volcar xa (non esperar o debounce) - ver comentario de
// enriba. relatedTarget (elemento que gaña o foco) pode vir baleiro nalgún
// caso raro do navegador; tratalo igual có resto (volcar de todos xeitos,
// é inofensivo facelo de máis).
editorContainer.addEventListener('focusout', (e) => {
  if (!codigoDeFondoActivo || editorContainer.contains(e.relatedTarget)) return
  if (debounceCodigoDeFondo) volcarCodigoDeFondoABloques()
})

function mostrarCodigoDeFondo() {
  if (codigoDeFondoActivo) return
  codigoDeFondoActivo = true
  refrescarCodigoDeFondo()
  placeholderAviso.classList.add('hidden')
  panePreviewPlaceholder.appendChild(matexeTagBar)
  panePreviewPlaceholder.appendChild(editorContainer)
  matexeTagBar.classList.remove('hidden')
  editorContainer.classList.remove('hidden')
  intervalCodigoFondo = setInterval(refrescarCodigoDeFondo, 600)
}

function agocharCodigoDeFondo() {
  if (!codigoDeFondoActivo) return
  if (debounceCodigoDeFondo) volcarCodigoDeFondoABloques()
  codigoDeFondoActivo = false
  clearInterval(intervalCodigoFondo)
  intervalCodigoFondo = null
  paneEditor.insertBefore(matexeTagBar, blocksContainer)
  paneEditor.insertBefore(editorContainer, blocksContainer)
  // Restaurar a visibilidade normal segundo o modo actual - este camiño
  // (acoplar) non pasa por switchMode (editMode non cambia), así que
  // ninguén máis a recoloca: en bloques teñen que quedar agochados de novo,
  // ou aparecerían por riba do editor de bloques (ver captura de Martin).
  matexeTagBar.classList.toggle('hidden', editMode === 'blocks')
  editorContainer.classList.toggle('hidden', editMode === 'blocks')
  placeholderAviso.classList.remove('hidden')
}

function actualizarPanelFondo() {
  if (resultadoDesacoplado && editMode === 'blocks') {
    mostrarCodigoDeFondo()
  } else {
    agocharCodigoDeFondo()
  }
}

btnReabrirResultado.addEventListener('click', async () => {
  try {
    await AbrirXanelaResultado()
  } catch (err) {
    setStatus(String(err))
  }
})

// --- Actualización de Yang (← botón "i" da barra) ---
// O backend comproba en fondo ao arrincar (evento actualizacion_yang_cambiada,
// ver EventsOn abaixo); aquí só se pinta o que xa se sabe. Mesmo mecanismo
// ca "Sobre Piztu" en piztu/frontend/src/main.js.
let actualizacionYang = null

function pintarActualizacionYang() {
  sobreVersion.textContent =
    t('about.version', 'Versión') + ' ' + (actualizacionYang ? actualizacionYang.versionLocal : '')

  const dispo = !!(actualizacionYang && actualizacionYang.disponible)
  btnAbout.classList.toggle('btn-actualizacion-dispo', dispo)

  if (dispo) {
    sobreActualizacion.textContent = t('about.novaversion', 'Nova versión dispoñible: {v}', {
      v: actualizacionYang.versionRemota,
    })
    sobreActualizacion.classList.remove('hidden')
    btnActualizarYang.classList.remove('hidden')
    btnActualizarYang.disabled = false
    btnActualizarYang.textContent = t('about.actualizar', '⟳ Actualizar')
  } else {
    sobreActualizacion.classList.add('hidden')
    btnActualizarYang.classList.add('hidden')
  }
}

function aplicarActualizacionYang(estado) {
  actualizacionYang = estado || null
  pintarActualizacionYang()
}

// Instala en quente a última versión de Yang e reinicia (← fondo azul no
// botón "i" cando GetActualizacionYang/evento actualizacion_yang_cambiada
// din que hai unha nova). Yang péchase só e reábrese xa actualizado.
btnActualizarYang.addEventListener('click', () => {
  if (!confirm(t('about.actualizar.confirmar',
      'Isto vai reiniciar Yang para aplicar a actualización. ¿Continuar?'))) {
    return
  }
  btnActualizarYang.disabled = true
  btnActualizarYang.textContent = t('about.actualizando', 'Actualizando...')
  AplicarActualizacionYang()
    .then(() => {
      btnActualizarYang.textContent = t('about.actualizar.ok', '✔ Reiniciando…')
      setTimeout(() => Application.Quit(), 400)
    })
    .catch((err) => {
      btnActualizarYang.disabled = false
      btnActualizarYang.textContent = t('about.actualizar', '⟳ Actualizar')
      showWarnings([String(err)])
    })
})

Events.On('actualizacion_yang_cambiada', (e) => aplicarActualizacionYang(e.data))

// --- Wiring ---

btnNew.addEventListener('click', newFile)
btnOpen.addEventListener('click', openFile)
btnSave.addEventListener('click', saveFile)
btnSaveAs.addEventListener('click', saveFileAs)
btnRun.addEventListener('click', run)
btnKillMaxima.addEventListener('click', killMaxima)
btnPrint.addEventListener('click', printPreview)
btnPDF.addEventListener('click', generatePDF)
btnExportTex.addEventListener('click', exportTex)
btnExportMarkdown.addEventListener('click', exportMarkdown)
btnExportDocx.addEventListener('click', exportDocx)
btnExportOdt.addEventListener('click', exportOdt)
btnOptions.addEventListener('click', openOptions)
btnDetect.addEventListener('click', detectMaxima)
btnOptionsCancel.addEventListener('click', closeOptions)
btnOptionsSave.addEventListener('click', saveOptions)

btnInstallMaxima.addEventListener('click', installMaximaNow)
btnMaximaManual.addEventListener('click', () => maximaManualOverlay.classList.remove('hidden'))
btnMaximaManualClose.addEventListener('click', () => maximaManualOverlay.classList.add('hidden'))
btnMaximaDismiss.addEventListener('click', () => maximaWarning.classList.add('hidden'))

btnInstallLatex.addEventListener('click', installLatexNow)
btnLatexManual.addEventListener('click', () => latexManualOverlay.classList.remove('hidden'))
btnLatexManualClose.addEventListener('click', () => latexManualOverlay.classList.add('hidden'))
btnLatexDismiss.addEventListener('click', () => latexWarning.classList.add('hidden'))

btnInstallPandoc.addEventListener('click', installPandocNow)
btnPandocManual.addEventListener('click', () => pandocManualOverlay.classList.remove('hidden'))
btnPandocManualClose.addEventListener('click', () => pandocManualOverlay.classList.add('hidden'))
btnPandocDismiss.addEventListener('click', () => pandocWarning.classList.add('hidden'))

btnAbout.addEventListener('click', () => sobreOverlay.classList.remove('hidden'))
btnAboutClose.addEventListener('click', () => sobreOverlay.classList.add('hidden'))

// handleReverseSearchClick recibe a mensaxe de REVERSE_SEARCH_SCRIPT (un
// Ctrl+clic sobre un resultado da previsualización), chama a ReverseSearch
// (Go, ver reversesearch.go) e, en modo Código, resalta a etiqueta
// <MAT>/<EVAL>/... correspondente en CodeMirror. En modo Bloques non fai
// nada por agora (fase 2 pendente: atopar e abrir o modal do anaco
// correspondente).
async function handleReverseSearchClick(e) {
  if (!e.data || !e.data.matexeReverseSearch) return
  // A xanela de resultado non ten editor onde resaltar nada, e o
  // ReverseSearch (Go) de todos xeitos correría contra un proceso que
  // nunca compilou nada el só (ver entrarModoResultado).
  if (souXanelaResultado) return
  if (editMode !== 'text') return
  try {
    const result = await ReverseSearch(e.data.page, e.data.xPx, e.data.yPx)
    const text = editor.getValue()
    const m = /^<(MAT|EVAL|HIDE|PLOT|TEX|TIKZ)>[\s\S]*?<\/\1>/.exec(text.slice(result.offset))
    if (!m) {
      setStatus(t('status.reverseSearchNoTag', 'Non se atopou a etiqueta orixinal (edicións despois de "Xerar"?)'))
      return
    }
    editor.selectRange(result.offset, result.offset + m[0].length)
  } catch (err) {
    // Erros esperables e frecuentes (clic antes de "Xerar", clic nunha zona
    // baleira da páxina...) - só na barra de estado, sen amosalos coma aviso.
    setStatus(String(err))
  }
}
window.addEventListener('message', handleReverseSearchClick)

// handleZoomMessage recibe o nivel de zoom de zoomScript (Ctrl+/Ctrl-/Ctrl+0
// dentro do iframe de previsualización) e gárdao en previewZoom para que
// sobreviva á próxima "Xerar" (pagesToPreviewHTML substitúe todo o srcdoc,
// perdendo calquera estado que só vivise dentro dese documento).
window.addEventListener('message', (e) => {
  if (!e.data || typeof e.data.matexeSetZoom !== 'number') return
  previewZoom = e.data.matexeSetZoom
})

// Ctrl+N/S/O/Enter/X/B work regardless of focus (bubble up from the
// editor's contenteditable DOM the same as from any other element); the
// Matexe tag shortcuts (Ctrl+M/E/H/P/T/F) are editor-only and live in
// editor.js - Ctrl+T (sen Alt) xa é "envolver en <TEX>" alí, por iso o modo
// texto usa Ctrl+Alt+T no canto de chocar con el.
//
// Ctrl+X (Xerar) preventDefault()a antes de que o navegador chegue a
// executar o "cortar" nativo cando hai selección no editor - por deseño: o
// profesorado pediu Ctrl+X para Xerar a propósito, sabendo que perde o
// atallo de teclado para cortar texto (segue dispoñible dende o menú
// contextual).
window.addEventListener('keydown', (e) => {
  // A xanela de resultado non ten editor/ficheiro propio - Ctrl+N/S/O/etc
  // non teñen sentido alí (ver entrarModoResultado).
  if (souXanelaResultado) return
  const mod = e.ctrlKey || e.metaKey
  if (mod && e.shiftKey && (e.key === 's' || e.key === 'S')) { e.preventDefault(); saveFileAs() }
  else if (mod && e.key === 's') { e.preventDefault(); saveFile() }
  else if (mod && e.key === 'n') { e.preventDefault(); newFile() }
  else if (mod && e.key === 'o') { e.preventDefault(); openFile() }
  else if (mod && (e.key === 'Enter' || e.key === 'x' || e.key === 'X')) { e.preventDefault(); run() }
  else if (mod && e.altKey && (e.key === 't' || e.key === 'T')) { e.preventDefault(); switchMode('text') }
  else if (mod && (e.key === 'b' || e.key === 'B')) { e.preventDefault(); switchMode('blocks') }
  else if (e.key === 'Escape') {
    closeOptions()
    maximaManualOverlay.classList.add('hidden')
    latexManualOverlay.classList.add('hidden')
    pandocManualOverlay.classList.add('hidden')
    sobreOverlay.classList.add('hidden')
  }
})

setStatus(t('status.unsaved', 'sen gardar'))
pintarActualizacionYang() // versión local xa dispoñible dende o arranque, aínda sen resposta de GitHub
GetActualizacionYang().then(aplicarActualizacionYang).catch(() => {})

// Idioma gardado: aplícase despois do arranque (en galego por defecto) en
// vez de bloquear a creación inicial dos editores nunha chamada async - un
// posible "flash" breve en galego é preferible a reestruturar todo o
// arranque do módulo arredor dun await. refrescarIdioma tamén recrea
// blocksEditor, así que isto cobre tanto o HTML estático coma a paleta de
// bloques recén creada por switchMode('blocks') máis arriba.
//
// Prioridade (ver saveOptions): 1) Settings.Idioma, se o profesorado xa
// escolleu un idioma propio en Opcións - prevalece sempre; 2) IdiomaPiztu(),
// se Yang arrincou dende Piztu e aínda non hai elección propia; 3) galego
// (xa é o que está cargado por defecto, non fai falla refrescar).
Promise.all([GetSettings(), IdiomaPiztu().catch(() => '')]).then(([s, ip]) => {
  idiomaPiztu = ip || ''
  xerarAoGardarActivo = s.xerarAoGardar !== false
  const idiomaEfectivo = s.idioma || idiomaPiztu
  if (idiomaEfectivo && idiomaEfectivo !== 'gl') refrescarIdioma(idiomaEfectivo)
  aplicarVisibilidadeExportadores(s)
}).catch(() => {})

// arrincarModoXanelas decide a UI segundo a xanela: Yang arrinca sempre
// acoplado (xanela única) - non hai axuste que cambie iso, desacoplar é
// unha decisión manual de sesión (botón "Desacoplar", ver máis abaixo). Só
// a xanela de resultado agocha checkMaxima/checkLatex/checkPandoc (non
// compila nada ela soa, eses avisos non teñen sentido alí).
function arrincarModoXanelas() {
  if (souXanelaResultado) {
    entrarModoResultado()
    return
  }
  checkMaxima()
  checkLatex()
  checkPandoc()
  Events.On('yang:resultado-pechado', saírModoDobreEditor)

  // btnDesacoplarResultado (só existe na xanela editor, ver HTML) - fai o
  // camiño de ida do que saírModoDobreEditor fai de volta, dispoñible en
  // calquera momento. Se AbrirXanelaResultado falla, vólvese ao estado
  // anterior en vez de deixar o panel agochado sen xanela.
  btnDesacoplarResultado.classList.remove('hidden')
  btnDesacoplarResultado.addEventListener('click', async () => {
    activarModoDobreEditor()
    try {
      await AbrirXanelaResultado()
    } catch (err) {
      saírModoDobreEditor()
      setStatus(String(err))
    }
  })
}
arrincarModoXanelas()

inicializarEnvioATao().then(() => inicializarReparto())
