// assistant.js: xanela de chat do asistente de IA integrado (icona 🤖) -
// compartida entre o editor de Código (main.js: documento enteiro ou
// selección) e cada modal de anaco do editor de bloques (blocks.js:
// Enunciado/Variable/Fórmula/Gráfico/TikZ - "Imaxe" queda fóra, é un
// ficheiro do disco, non hai texto que editar). Unha soa instancia
// (singleton): créase con createAssistant() e reábrese/reconfígurase cada
// vez con open({...}) - mesmo patrón cós modais .overlay/.modal que xa usa
// blocks.js (ensureModal).
//
// Protocolo co backend (AsistenteIA, app.go): a petición vai co contido
// ACTUAL do que se está a editar; a resposta é ou unha explicación en
// prosa (accion "responder", non toca nada) ou unha proposta de contido
// novo completo (accion "editar") que se amosa cun botón "Aplicar" - NUNCA
// se substitúe contido sen que o profesorado prema ese botón.
import { AsistenteIA } from '../bindings/matexe-wails/app.js'

export function createAssistant({ t }) {
  let overlay, modal, titleEl, log, input, sendBtn
  let ctx = null // { tipo, getContent, setContent } - ver open()

  // makeDraggable: mesma idea ca a súa homóloga en blocks.js (premer e
  // arrastrar o título move o cadro) - non se comparte código entre os dous
  // ficheiros a propósito, é pequeno dabondo (12 liñas) para que non pague
  // a pena o acoplamento extra de exportalo dun módulo a outro.
  function makeDraggable(box, handle) {
    handle.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return
      const rect = box.getBoundingClientRect()
      box.style.position = 'fixed'
      box.style.margin = '0'
      box.style.left = rect.left + 'px'
      box.style.top = rect.top + 'px'
      const startX = e.clientX
      const startY = e.clientY
      const startLeft = rect.left
      const startTop = rect.top
      function onMove(ev) {
        box.style.left = startLeft + ev.clientX - startX + 'px'
        box.style.top = startTop + ev.clientY - startY + 'px'
      }
      function onUp() {
        window.removeEventListener('mousemove', onMove)
        window.removeEventListener('mouseup', onUp)
      }
      window.addEventListener('mousemove', onMove)
      window.addEventListener('mouseup', onUp)
      e.preventDefault()
    })
  }

  function ensure() {
    if (overlay) return
    overlay = document.createElement('div')
    overlay.className = 'overlay hidden'
    modal = document.createElement('div')
    modal.className = 'modal modal--assistant'
    overlay.appendChild(modal)
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close() })
    document.body.appendChild(overlay)

    const head = document.createElement('div')
    head.className = 'assistant-head'
    titleEl = document.createElement('h2')
    titleEl.className = 'modal-drag-handle'
    const closeBtn = document.createElement('button')
    closeBtn.type = 'button'
    closeBtn.className = 'assistant-close'
    closeBtn.textContent = '✕'
    closeBtn.addEventListener('click', close)
    head.appendChild(titleEl)
    head.appendChild(closeBtn)
    modal.appendChild(head)
    makeDraggable(modal, titleEl)

    log = document.createElement('div')
    log.className = 'assistant-log'
    modal.appendChild(log)

    const form = document.createElement('form')
    form.className = 'assistant-form'
    input = document.createElement('textarea')
    input.rows = 2
    input.placeholder = t('assistant.placeholder', 'Pregunta algo ou pide un cambio…')
    sendBtn = document.createElement('button')
    sendBtn.type = 'submit'
    sendBtn.className = 'primary'
    sendBtn.textContent = t('assistant.send', 'Enviar')
    form.appendChild(input)
    form.appendChild(sendBtn)
    modal.appendChild(form)

    form.addEventListener('submit', (e) => { e.preventDefault(); send() })
    // Intro envía; Maiús+Intro insire un salto de liña (comportamento
    // estándar dun caixa de chat, e evita ter que premer sempre o botón).
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
    })
  }

  function addMessage(role, text) {
    const div = document.createElement('div')
    div.className = 'assistant-msg assistant-msg--' + role
    div.textContent = text
    log.appendChild(div)
    log.scrollTop = log.scrollHeight
    return div
  }

  async function send() {
    const peticion = input.value.trim()
    if (!peticion || !ctx) return
    input.value = ''
    addMessage('user', peticion)
    sendBtn.disabled = true
    const thinking = addMessage('assistant', t('assistant.thinking', 'Pensando…'))
    try {
      const resp = await AsistenteIA({ tipo: ctx.tipo, contido: ctx.getContent(), peticion })
      thinking.remove()
      if (resp.accion === 'editar') {
        const msg = addMessage('assistant', resp.texto || t('assistant.editProposed', 'Teño unha proposta de cambio lista.'))
        msg.appendChild(document.createElement('br'))
        const applyBtn = document.createElement('button')
        applyBtn.type = 'button'
        applyBtn.className = 'assistant-apply'
        applyBtn.textContent = t('assistant.apply', '✓ Aplicar este cambio')
        applyBtn.addEventListener('click', () => {
          ctx.setContent(resp.contido)
          applyBtn.disabled = true
          applyBtn.textContent = t('assistant.applied', '✓ Aplicado')
        })
        msg.appendChild(applyBtn)
      } else {
        addMessage('assistant', resp.texto)
      }
    } catch (err) {
      thinking.remove()
      addMessage('error', String(err && err.message ? err.message : err))
    } finally {
      sendBtn.disabled = false
      input.focus()
    }
  }

  // open reconfigura a xanela para un novo contexto de edición e a amosa
  // (limpa a conversa anterior - cada apertura é un tema novo, non ten
  // sentido arrastrar mensaxes doutro anaco/documento):
  //   tipo: "documento" (editor de Código) ou o "type" dun anaco de
  //     blocks-serialize.js (text/variables/formula/image-plot/image-tikz).
  //   title: texto amosado na cabeceira (ex. "Fórmula", "Código").
  //   getContent()/setContent(texto): len/escriben o contido a editar - o
  //     chamador decide de onde ven (editor.js ou un <textarea> do modal de
  //     bloques).
  function open({ tipo, title, getContent, setContent }) {
    ensure()
    ctx = { tipo, getContent, setContent }
    titleEl.innerHTML = `<span aria-hidden="true">🤖</span> ${title}`
    log.innerHTML = ''
    modal.style.position = ''
    modal.style.left = ''
    modal.style.top = ''
    modal.style.margin = ''
    overlay.classList.remove('hidden')
    requestAnimationFrame(() => input.focus())
  }

  function close() {
    if (overlay) overlay.classList.add('hidden')
  }

  return { open, close }
}
