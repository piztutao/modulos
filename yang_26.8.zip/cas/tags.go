package cas

import (
	"encoding/base64"
	"fmt"
	"html"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
)

// tagPattern mirrors the alternation regex built in Tcas.parse_text from
// cas.pas: (?s) makes '.' match newlines too, since a tag's content can
// span multiple lines. TIKZ has no Pascal ancestor - it's new, added for
// the block editor's "gráfico TikZ" element type (see blocks-serialize.js).
var tagPattern = regexp.MustCompile(`(?s)<MAT>(.*?)</MAT>|<EVAL>(.*?)</EVAL>|<HIDE>(.*?)</HIDE>|<PLOT>(.*?)</PLOT>|<TEX>(.*?)</TEX>|<TIKZ>(.*?)</TIKZ>|<SISTEMA>(.*?)</SISTEMA>`)

// TagPattern exposes tagPattern to other packages that need to scan a
// .matex source for tag boundaries WITHOUT evaluating them - e.g.
// insertOffsetMarkers (reversesearch.go) needs the exact byte offset of
// every tag in the PRISTINE source (before ParseText runs), for the
// Ctrl+clic-on-a-result "reverse search" feature. Kept as a single
// definition (this var) so a caller of TagPattern can never drift from
// what ParseText itself actually matches.
var TagPattern = tagPattern

// OutDir is where generated images (<PLOT>) are written, relative to the
// final HTML file - mirrors Tcas.pathDocs.
func (m *Maxima) SetOutDir(dir string) { m.outDir = dir }

// ParseText walks textToParse left to right, sends every Matexe tag
// (<MAT>/<EVAL>/<HIDE>/<PLOT>/<TEX>/<TIKZ>/<SISTEMA>) it finds to Maxima in
// order, and splices the result back in. Ports Tcas.parse_text +
// Tcas.processTag.
func (m *Maxima) ParseText(text string) (string, error) {
	matches := tagPattern.FindAllStringSubmatchIndex(text, -1)
	var out strings.Builder
	last := 0

	for _, idx := range matches {
		out.WriteString(text[last:idx[0]])
		last = idx[1]

		kind, content := "", ""
		switch {
		case idx[2] != -1:
			kind, content = "MAT", text[idx[2]:idx[3]]
		case idx[4] != -1:
			kind, content = "EVAL", text[idx[4]:idx[5]]
		case idx[6] != -1:
			kind, content = "HIDE", text[idx[6]:idx[7]]
		case idx[8] != -1:
			kind, content = "PLOT", text[idx[8]:idx[9]]
		case idx[10] != -1:
			kind, content = "TEX", text[idx[10]:idx[11]]
		case idx[12] != -1:
			kind, content = "TIKZ", text[idx[12]:idx[13]]
		case idx[14] != -1:
			kind, content = "SISTEMA", text[idx[14]:idx[15]]
		}
		content = strings.TrimSpace(content)
		if content == "" {
			continue
		}

		repl, err := m.processTag(kind, content)
		if err != nil {
			return "", fmt.Errorf("<%s>%s</%s>: %w", kind, content, kind, err)
		}
		out.WriteString(repl)
	}
	out.WriteString(text[last:])
	return out.String(), nil
}

// processTag ports Tcas.process_MAT / process_EVAL / process_HIDE /
// process_PLOT / process_TEX.
func (m *Maxima) processTag(kind, content string) (string, error) {
	switch kind {
	case "MAT":
		content = normalizeLatexSubscripts(content)
		if sym, ok := specialCaseSymbol(content); ok {
			return m.renderMathSymbol(sym), nil
		}
		if txt, ok := mathProseAsText(content); ok {
			return m.renderLiteralText(txt), nil
		}
		if expr, ok := pureNumericArithmetic(content); ok {
			return m.renderMathSymbol(expr), nil
		}
		// Unevaluated, un-simplified expression -> TeX.
		return m.ToTeX(autoQuoteLimit(content), false)
	case "EVAL":
		content = normalizeLatexSubscripts(content)
		if sym, ok := specialCaseSymbol(content); ok {
			return m.renderMathSymbol(sym), nil
		}
		if txt, ok := mathProseAsText(content); ok {
			return m.renderLiteralText(txt), nil
		}
		// Evaluated expression -> TeX.
		return m.ToTeX(content, true)
	case "HIDE":
		content = normalizeLatexSubscripts(content)
		// Executed silently in the CAS session, nothing shown - but a
		// Maxima-level error (bad syntax, unknown option...) must still
		// surface: silently swallowing it would leave later tags that
		// depend on this one's variables failing in a much more confusing
		// way (or worse, plotting/showing stale values from a previous
		// run). See maximaErrorFrom.
		raw, err := m.Send(content, true)
		if err != nil {
			return "", err
		}
		if msg := maximaErrorFrom(raw); msg != "" {
			return "", fmt.Errorf("erro de Maxima: %s", msg)
		}
		return "", nil
	case "PLOT":
		return m.plot(content)
	case "TEX":
		// Content may itself contain tags (parsed first), then wrapped
		// as raw TeX like Tcas.CAS_TeX. It's already valid TeX source
		// either way, so both formats just wrap it as inline math.
		inner, err := m.ParseText(content)
		if err != nil {
			return "", err
		}
		if m.Format == FormatLatex {
			return m.protect("$" + inner + "$"), nil
		}
		return fmt.Sprintf(`<span class="math">\(%s\)</span>`, inner), nil
	case "TIKZ":
		return m.tikz(content)
	case "SISTEMA":
		return m.renderSistema(content)
	default:
		return "", fmt.Errorf("unsupported tag <%s>", kind)
	}
}

// renderSistema groups several equations (one per line, plain Maxima
// source - no individual <MAT> wrapper needed) under one shared brace, real
// report: three separate <MAT>eq</MAT> tags, each in its own <p>, render as
// three unrelated lines instead of the "system of equations" notation
// (brace + stacked equations) a maths teacher expects. amsmath's "cases"
// environment already draws exactly that (left brace, left-aligned rows,
// no equation numbering) - loaded in both LaTeX preambles (see
// latexPreambleTemplatePDF/Unicode in latexdoc.go) and understood natively
// by MathJax (HTML preview) and by Pandoc's LaTeX-math reader (Markdown ->
// DOCX/ODT, see docdoc.go), so one wrapping covers every export format.
// Each line goes through toTeXValue the same way a lone <MAT> would
// (unevaluated - a system is shown as posed, not solved) - kept separate
// from MAT's own specialCaseSymbol/mathProseAsText short-circuits since
// those exist for edge cases (a bare "<MAT>>=</MAT>", interval notation...)
// that don't apply to actual equations.
func (m *Maxima) renderSistema(content string) (string, error) {
	var rows []string
	for _, line := range strings.Split(content, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		line = normalizeLatexSubscripts(line)
		value, hasMath, err := m.toTeXValue(autoQuoteLimit(line), false)
		if err != nil {
			return "", err
		}
		if !hasMath {
			// Maxima-level error on this one line (bad syntax...) - surface
			// it the same way ParseText surfaces any other tag error,
			// instead of silently dropping the row from the system.
			return "", fmt.Errorf("erro de Maxima en %q: %s", line, value)
		}
		rows = append(rows, value)
	}
	if len(rows) == 0 {
		return "", nil
	}
	inner := "\\begin{cases}\n" + strings.Join(rows, " \\\\\n") + "\n\\end{cases}"

	if m.Format == FormatLatex || m.Format == FormatMarkdown {
		return m.protect("$$" + inner + "$$"), nil
	}
	return `<span class="math">\[` + inner + `\]</span>`, nil
}

// bareRelationalSymbols catches the single most common mistake found
// empirically in IA-generated (and occasionally hand-typed) content: a bare
// comparison operator, no operands, wrapped in <MAT>/<EVAL> to reference it
// in prose (e.g. "a desigualdade ten <MAT>>=</MAT>"). Maxima's parser
// always rejects this ("is not a prefix operator") since there's nothing to
// evaluate - it was never a Maxima expression to begin with, just notation.
// Explicitly forbidding it in the IA's system prompt (see gemini_client.go's
// chuletaMatexe) didn't reliably stop it from recurring, so it's handled
// here directly instead: recognised before ever reaching Maxima and
// rendered as the plain math symbol, regardless of where the mistake came
// from.
var bareRelationalSymbols = map[string]string{
	"=": "=", "==": "=",
	"!=": `\neq`, "#": `\neq`, "≠": `\neq`,
	"<": "<", ">": ">",
	"<=": `\leq`, "≤": `\leq`,
	">=": `\geq`, "≥": `\geq`,
}

// bareRelationalSymbol reports whether content (already trimmed by the
// caller, ParseText) is exactly one of bareRelationalSymbols - nothing
// else, no operands - and if so returns its LaTeX math rendering.
func bareRelationalSymbol(content string) (string, bool) {
	sym, ok := bareRelationalSymbols[content]
	return sym, ok
}

// intervalRe matches "(A, B)" / "[A, B]" / "(A, B]" / "[A, B)" - interval
// notation for a solution set, another very common IA/hand-typed mistake
// wrapped in <MAT>/<EVAL> (e.g. "<MAT>(-inf, -2]</MAT>"). Bounds must be
// paren/bracket-free (no nested "f(x)"-style calls) - anything more complex
// falls through to the normal Maxima path unchanged, same as before.
var intervalRe = regexp.MustCompile(`^([(\[])\s*([^,()\[\]]+?)\s*,\s*([^,()\[\]]+?)\s*([)\]])$`)

// infinityWordRe recognises an interval bound that's some spelling of
// infinity ("inf", "-inf", "+infinity", "∞", "-∞"...) - the strongest
// signal that a "(A, B)"-shaped tag is interval notation and not a
// legitimate two-statement Maxima expression (which round parens with a
// comma otherwise are: valid syntax, but SILENTLY evaluates to just B,
// discarding A - confirmed empirically with `tex((3, inf))` printing only
// "∞" - worse than a visible error, so this is intercepted proactively
// rather than only reacting to a parse failure like bareRelationalSymbol).
var infinityWordRe = regexp.MustCompile(`(?i)^([+\-−]?)\s*(?:inf|infinity|∞)$`)

// intervalNotationSymbol reports whether content is interval notation (see
// intervalRe) that Maxima would either reject outright (mismatched
// bracket types - never valid Maxima syntax) or silently misinterpret
// (matched round parens - only intercepted when a bound is recognisably
// "infinity", to avoid ever touching a real two-statement Maxima
// expression a teacher intentionally wrote). "[A, B]" alone (matched
// square brackets, no infinity) is left untouched: that's already a valid
// Maxima list, and Maxima's own tex([A,B]) renders it exactly like a
// closed interval anyway.
func intervalNotationSymbol(content string) (string, bool) {
	mm := intervalRe.FindStringSubmatch(content)
	if mm == nil {
		return "", false
	}
	open, lower, upper, closeCh := mm[1], mm[2], mm[3], mm[4]
	mismatched := (open == "(" && closeCh == "]") || (open == "[" && closeCh == ")")
	if !mismatched {
		if !(open == "(" && closeCh == ")") {
			return "", false // "[A, B]" (matched square brackets): already valid Maxima, leave it
		}
		if !infinityWordRe.MatchString(strings.TrimSpace(lower)) && !infinityWordRe.MatchString(strings.TrimSpace(upper)) {
			return "", false // matched "(A, B)", neither bound is infinity - leave Maxima to handle it
		}
	}
	return open + renderIntervalBound(lower) + ", " + renderIntervalBound(upper) + closeCh, true
}

// renderIntervalBound renders a single interval bound as LaTeX math: an
// infinity spelling becomes \infty (with its sign, if any), anything else
// passes through as-is - bounds here are expected to already be simple
// literals ("-2", "3"), not expressions needing further evaluation.
func renderIntervalBound(bound string) string {
	bound = strings.TrimSpace(bound)
	if mm := infinityWordRe.FindStringSubmatch(bound); mm != nil {
		return mm[1] + `\infty`
	}
	return bound
}

// latexSubscriptRe matches LaTeX-style subscript braces on a plain
// alphanumeric subscript: "R_{eq}", "V_{1}", "I_{total}". Real report:
// <MAT>R_{eq}</MAT> (from prose like "la resistencia equivalente R_{eq}")
// fails with Maxima's "incorrect syntax: { is not an infix operator" -
// unlike LaTeX, Maxima's "{" always opens a SET literal, never a grouping
// for "_", so "R_{eq}" parses as the identifier "R_" immediately followed
// by the set "{eq}" with nothing joining them. Maxima's own identifier
// syntax already allows the underscore directly ("R_eq" is one valid
// symbol name, and Maxima's tex() renders it back with a real LaTeX
// subscript, "R_{eq}") - so the fix is to normalize the braces away before
// the content ever reaches Maxima, not to special-case it out to plain
// text like bareRelationalSymbol/intervalNotationSymbol: a normalized
// "R_eq" is still a real, evaluable Maxima expression (e.g. "R_{eq} =
// R_{1} + R_{2}" keeps working as an equation, not just a lone label).
// Left deliberately narrow to a single alphanumeric run: a comma or
// operator inside the braces ("x_{i,j}", "x_{i+1}") is genuine multi-level
// LaTeX notation Maxima has no equivalent for anyway, so it's left
// untouched and falls through to the same syntax error as before (not a
// regression - just not newly fixed).
var latexSubscriptRe = regexp.MustCompile(`_\{([A-Za-z0-9]+)\}`)

// normalizeLatexSubscripts strips LaTeX subscript braces (see
// latexSubscriptRe) from MAT/EVAL/HIDE content - the three tag kinds whose
// content is Maxima source. Left out of PLOT/TEX/TIKZ: PLOT content can
// contain quoted string literals (plot titles/legends) where blindly
// rewriting "_{...}" would silently change the displayed text instead of
// fixing a syntax error, and TEX/TIKZ content is raw LaTeX/TikZ source
// where "_{...}" is already correct, valid syntax that must not be touched.
func normalizeLatexSubscripts(content string) string {
	return latexSubscriptRe.ReplaceAllString(content, "_$1")
}

// limitCallRe matches a bare (unquoted) limit(...) call at the very start
// of a <MAT> expression.
var limitCallRe = regexp.MustCompile(`^limit\s*\(`)

// autoQuoteLimit prefixes a bare limit(...) call with a quote (') so Maxima
// treats it as an inert "noun" form instead of evaluating it immediately.
// Real report: <MAT>limit(sqrt(x^2+6*x)-x,x,inf)</MAT> rendered as a bare
// "3" instead of the limit notation - <MAT>'s own promise ("Mostra a
// expresión SEN avaliar", the tagbar tooltip) doesn't hold for limit():
// Maxima executes any unquoted function call as soon as it parses it,
// regardless of ToTeX's forceEval - only the noun-form quote keeps it
// symbolic, and tex() already knows how to typeset a quoted limit as
// \lim_{x\to a}{...} (verified against real Maxima output). Deliberately
// scoped to limit() only, not diff/integrate/sum/product: those normally
// SHOULD show their computed formula inside <MAT> (e.g. diff(x^2,x) -> "2x"
// is exactly what's wanted) - limit() is the one case that visibly
// contradicts <MAT>'s own contract by collapsing to a lone number. A
// professor who already writes 'limit(...) by hand is unaffected (the
// leading quote means the string no longer starts with "limit(").
func autoQuoteLimit(content string) string {
	if limitCallRe.MatchString(content) {
		return "'" + content
	}
	return content
}

// pureNumericArithmeticRe matches a chain of plain number literals joined by
// +, -, * or ^, no variables (e.g. "548 + 375", "12.5 - 3 + 1", "2^3 * 3",
// "2^4 * 3^2 * 5" - a prime factorisation, as posed by a factor-decomposition
// exercise). Originally +/- only; widened after a second real report:
// <MAT>48 = 2^4 * 3</MAT> printed "48 = 48" instead of the factorisation as
// written, same root cause as the first report below applied to * and ^ too.
// Real report #1: <MAT>548 + 375</MAT> printed "923" instead of the sum as
// written - unlike limit() (autoQuoteLimit), where quoting the call keeps it
// symbolic, numeric-literal arithmetic is collapsed by Maxima's SIMPLIFIER
// at parse time, before "evaluation" (what a leading quote blocks) even
// applies - confirmed empirically: tex('(548+375)) still prints "923". A
// single literal ("923" alone) deliberately falls through to the normal
// Maxima/ToTeX path unchanged (see pureNumericArithmeticHasOperator) -
// there's nothing to "un-simplify" and no operator to strip the quote's
// effect from.
var pureNumericArithmeticRe = regexp.MustCompile(`^-?\d+(?:\.\d+)?(?:\s*[+\-*^]\s*-?\d+(?:\.\d+)?)*$`)

// pureNumericArithmeticHasOperator reports whether s (already matched by
// pureNumericArithmeticRe) contains an actual operator, as opposed to being
// a single bare literal - needed because pureNumericArithmeticRe alone must
// also accept a bare literal now (a "=" side like the "48" in
// "48 = 2^4 * 3" is legitimately just one literal). Skips index 0: a leading
// "-" there is a sign, not an operator.
func pureNumericArithmeticHasOperator(s string) bool {
	if s == "" {
		return false
	}
	return strings.ContainsAny(s[1:], "+-*^")
}

// exponentDigitsRe wraps an exponent in braces for LaTeX: bare "2^34" would
// otherwise typeset as "3" superscript followed by a baseline "4" (LaTeX's
// "^" only grabs the single next token) - "2^{34}" is what's actually
// meant. Single-digit exponents ("2^3") already render fine without braces,
// but bracing them too is harmless, so this applies unconditionally.
var exponentDigitsRe = regexp.MustCompile(`\^(-?\d+(?:\.\d+)?)`)

// renderPureNumericArithmetic turns a matched expression into LaTeX source:
// braces multi-digit exponents (exponentDigitsRe) and swaps "*" for "\cdot"
// (the conventional symbol for a factor decomposition, e.g. "2^3 \cdot 3"
// instead of a bare asterisk) - digits/+/-/./whitespace need no escaping.
func renderPureNumericArithmetic(expr string) string {
	expr = exponentDigitsRe.ReplaceAllString(expr, `^{$1}`)
	return strings.ReplaceAll(expr, "*", `\cdot`)
}

// pureNumericArithmetic reports whether content (already trimmed by the
// caller, ParseText) is pure numeric arithmetic (see pureNumericArithmeticRe)
// - either standalone, or as one "=" comparing two such sides (e.g.
// "48 = 2^4 * 3", a factorisation as posed) - returning its LaTeX rendering
// (see renderPureNumericArithmetic). MAT-only (see processTag): EVAL must
// keep evaluating, that's its whole point, so this is never consulted from
// the EVAL branch.
func pureNumericArithmetic(content string) (string, bool) {
	if parts := strings.SplitN(content, "=", 2); len(parts) == 2 {
		lhs, rhs := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
		if !pureNumericArithmeticRe.MatchString(lhs) || !pureNumericArithmeticRe.MatchString(rhs) {
			return "", false
		}
		if !pureNumericArithmeticHasOperator(lhs) && !pureNumericArithmeticHasOperator(rhs) {
			return "", false // "5 = 5": no factorisation on either side, nothing to preserve
		}
		return renderPureNumericArithmetic(lhs) + " = " + renderPureNumericArithmetic(rhs), true
	}
	if !pureNumericArithmeticRe.MatchString(content) || !pureNumericArithmeticHasOperator(content) {
		return "", false
	}
	return renderPureNumericArithmetic(content), true
}

// specialCaseSymbol tries every known "this was never meant to be Maxima
// source" shape (see bareRelationalSymbol/intervalNotationSymbol) before a
// MAT/EVAL tag's content reaches Maxima at all.
func specialCaseSymbol(content string) (string, bool) {
	if sym, ok := bareRelationalSymbol(content); ok {
		return sym, true
	}
	return intervalNotationSymbol(content)
}

// renderMathSymbol wraps a symbol already known to be valid LaTeX math
// source (bareRelationalSymbol's output) the same way ToTeX wraps a
// successful Maxima result, without a round-trip through Maxima at all.
func (m *Maxima) renderMathSymbol(sym string) string {
	if m.Format == FormatLatex || m.Format == FormatMarkdown {
		return m.protect("$" + sym + "$")
	}
	return `<span class="math">\(` + sym + `\)</span>`
}

// countTopLevelEquals counts "=" characters that sit OUTSIDE any
// (), [], {} nesting - i.e. genuinely chaining/qualifying the whole
// expression, not glued inside a nested list or function-call argument. A
// valid multi-argument call like "ev(f(x),x=3,y=2)" keeps every "=" one
// level deep inside the outer "(...)", so it reports zero and is correctly
// left alone; "PM = [3 - 1, 0 - 2, 2 - 3] = [2, -2, -1]" (real report -
// note the "=" signs are top-level even though the content also has
// commas, just nested ones inside the "[...]" lists) reports 2. Doesn't
// bother distinguishing ">="/"<="/"!="/"==" from a bare "=" - a false
// positive here only means legitimate content that already uses one of
// those operators TWICE at the top level (rare) renders as plain text
// instead of being evaluated, not a wrong result or a crash.
func countTopLevelEquals(content string) int {
	depth := 0
	count := 0
	for _, r := range content {
		switch r {
		case '(', '[', '{':
			depth++
		case ')', ']', '}':
			if depth > 0 {
				depth--
			}
		case '=':
			if depth == 0 {
				count++
			}
		}
	}
	return count
}

// mathProseAsText catches content that reads as mathematical NOTATION
// rather than a single evaluable Maxima expression: either a chain of
// relations (countTopLevelEquals >= 2, e.g. "(x-1)/2 = (y+1)/1 = z/2", the
// standard shorthand for a line's symmetric equations in 3D geometry) or a
// label with a dangling "=" at the end (e.g. "dom(f) = ", the general form
// of the trailing-"=" rule already forbidden in gemini_client.go's
// chuletaMatexe - bareRelationalSymbol only catches a BARE operator with
// nothing else, this catches the same mistake with a real expression
// glued in front, which keeps recurring despite the explicit prompt
// rule). Maxima's parser always rejects both ("a=b=c" parses as "(a=b)=c",
// a LOGICAL comparison where an ALGEBRAIC value was expected; a trailing
// "=" is simply incomplete). Neither shape has one single "correct"
// evaluation to fall back to the way bareRelationalSymbol/
// intervalNotationSymbol do, so both render as plain literal text instead
// - always safe, since it's exactly what the content would have looked
// like as ordinary prose outside any tag to begin with.
func mathProseAsText(content string) (string, bool) {
	if _, ok := bareRelationalSymbols[content]; ok {
		return "", false // xa ten a súa propia renderización (só o símbolo)
	}
	if strings.HasSuffix(content, "=") || countTopLevelEquals(content) >= 2 {
		return content, true
	}
	return "", false
}

// renderLiteralText renders content that never was (or turned out not to
// be) valid Maxima source as ordinary prose instead - same treatment as
// document text outside any tag (EscapeLatexProse: LaTeX-escaped, with the
// same Unicode math-symbol substitutions as escapeOutsideMath in
// latexdoc.go), just reached from inside a MAT/EVAL tag instead of from a
// text node.
func (m *Maxima) renderLiteralText(text string) string {
	if m.Format == FormatLatex || m.Format == FormatMarkdown {
		return m.protect(EscapeLatexProse(text))
	}
	return html.EscapeString(text)
}

// maximaErrorFrom detects a Maxima-level error in a Send response - Maxima
// reports these on its own console output ("draw: unknown option axes \n --
// an error. To debug this try: debugmode(true);"), not as a failed command,
// so Session.rawSend/Send see it as ordinary (successful) output. Returns
// the error message (everything before "-- an error."), or "" if the
// response doesn't look like an error at all.
func maximaErrorFrom(raw string) string {
	idx := strings.Index(raw, "-- an error.")
	if idx == -1 {
		return ""
	}
	return strings.TrimSpace(raw[:idx])
}

// plot ports Tcas.process_PLOT + TMaxima.CAS_Plot: routes Maxima's
// draw2d/draw3d output through gnuplot and returns an <img>/\includegraphics
// reference. LaTeX output uses "pdf" - a real VECTOR file, which pdflatex's
// \includegraphics accepts directly - so the graph stays crisp at any
// zoom/print size instead of the blocky, aliased look of a raster PNG
// scaled up inside the PDF (gnuplot's legacy "png" terminal, used here
// before). HTML/Markdown previews still need a raster (no <img>/![]() PDF
// support), so those use "pngcairo" instead of plain "png" - gnuplot's
// modern anti-aliased PNG terminal, noticeably sharper lines/fonts even
// without going vector (confirmed side-by-side against real Maxima output).
// Both terminals confirmed to work with this gnuplot/Maxima version by
// direct `maxima -b` runs before wiring this in.
func (m *Maxima) plot(expr string) (string, error) {
	m.plotCount++
	ext, term := "png", "pngcairo"
	if m.Format == FormatLatex {
		ext, term = "pdf", "pdf"
	}
	filename := fmt.Sprintf("img_%d.%s", m.plotCount, ext)
	imgDir := filepath.Join(m.outDir, "images")
	if err := os.MkdirAll(imgDir, 0o755); err != nil {
		return "", err
	}
	fullPath := filepath.ToSlash(filepath.Join(imgDir, filename))
	baseNoExt := strings.TrimSuffix(fullPath, "."+ext)

	for _, opt := range []string{
		`set_plot_option([plot_format, gnuplot])`,
		fmt.Sprintf(`set_plot_option([gnuplot_term, %s])`, term),
		fmt.Sprintf(`set_plot_option([gnuplot_out_file,"%s"])`, fullPath),
	} {
		if _, err := m.Send(opt, false); err != nil {
			return "", err
		}
	}

	line := expr
	switch {
	case strings.Contains(line, "draw2d("):
		line = strings.Replace(line, "draw2d(",
			fmt.Sprintf(`draw2d(terminal='%s, file_name="%s",`, term, baseNoExt), 1)
	case strings.Contains(line, "draw3d("):
		line = strings.Replace(line, "draw3d(",
			fmt.Sprintf(`draw3d(terminal='%s, file_name="%s",`, term, baseNoExt), 1)
	}
	// Maxima answers a bad draw2d/draw3d call (e.g. an option that belongs to
	// plot2d, not draw2d - "unknown option axes") as plain error text on its
	// own console output, not as a Go error: Send only fails on a
	// communication problem. Left unchecked, no PNG ever gets written and
	// the failure only surfaces much later, as a baffling "file not found"
	// from pdflatex - check here instead, right where the real cause is.
	raw, err := m.Send(line, true)
	if err != nil {
		return "", err
	}
	if msg := maximaErrorFrom(raw); msg != "" {
		return "", fmt.Errorf("erro de Maxima ao debuxar: %s", msg)
	}

	if m.Format == FormatLatex {
		// LaTeX needs a real file on disk, referenced relative to the
		// .tex file being compiled - leave it where it is, in images/.
		return m.protect(fmt.Sprintf("\\begin{center}\\includegraphics[width=0.55\\textwidth]{images/%s}\\end{center}", filename)), nil
	}
	if m.Format == FormatMarkdown {
		// Markdown export: same idea as LaTeX (real file, referenced
		// relative to the .md file, already sitting in images/), just with
		// Markdown's own image syntax instead of \includegraphics. Alt text
		// is a plain fixed label, not expr: Maxima plot calls are full of
		// literal []/() that would break the ![alt](url) syntax if dropped
		// in raw (html.EscapeString, used by the HTML branch below, doesn't
		// help here - Markdown's special characters aren't HTML's).
		return m.protect(fmt.Sprintf("![gráfico](images/%s)", filename)), nil
	}

	// Embed the PNG directly so the resulting HTML is self-contained -
	// convenient for previewing in the webview without an asset server,
	// and for the final exported/printed document.
	png, err := os.ReadFile(fullPath)
	if err != nil {
		return "", fmt.Errorf("reading generated plot %s: %w", fullPath, err)
	}
	dataURI := "data:image/png;base64," + base64.StdEncoding.EncodeToString(png)
	return fmt.Sprintf(`<img src="%s" alt="%s">`, dataURI, html.EscapeString(expr)), nil
}

// tikz ports the new <TIKZ> tag: raw TikZ source. In LaTeX mode it's
// wrapped in a tikzpicture environment INSIDE \begin{center}...\end{center}
// - matching plot()/renderImg() below, and not just cosmetic: a bare
// tikzpicture is valid INLINE LaTeX content (no implicit \par), so a
// diagram wedged between two blocks with no whitespace between them (the
// block editor concatenates blocks with none, see blocks-serialize.js)
// rendered mid-paragraph, at whatever height the drawing turned out to be,
// overlapping the surrounding text instead of getting its own line (real
// report). \begin{center}, being list-based (trivlist), forces \par both
// entering and leaving regardless of what's textually adjacent to it, the
// same guarantee plot()/renderImg() already relied on - now tikzpicture
// gets it too. The compiled document already loads the tikz package (see
// latexPreambleTemplate in latexdoc.go) so pdflatex renders it natively, no
// raster step needed. In HTML preview mode a browser can't render TikZ, so
// a throwaway standalone LaTeX doc containing only the tikzpicture is
// compiled with pdflatex and
// rasterized with pdftoppm (part of poppler-utils - much more commonly
// preinstalled than a full ImageMagick/Ghostscript chain), then embedded
// as a data: URI exactly like plot() does for gnuplot output above.
// Missing tools or a bad TikZ snippet degrade to a visible inline warning
// instead of aborting the whole generation - ParseText's caller has no
// other channel to surface a per-tag warning in HTML mode.
func (m *Maxima) tikz(code string) (string, error) {
	if m.Format == FormatLatex {
		return m.protect("\\begin{center}\\begin{tikzpicture}\n" + code + "\n\\end{tikzpicture}\\end{center}"), nil
	}
	if !commandExists("pdflatex") {
		return `<p class="matexe-warning">⚠ Non se puido xerar o debuxo TikZ: non se atopou pdflatex.</p>`, nil
	}
	if !commandExists("pdftoppm") {
		return `<p class="matexe-warning">⚠ Non se puido xerar o debuxo TikZ: non se atopou pdftoppm (paquete poppler-utils).</p>`, nil
	}

	tmpDir, err := os.MkdirTemp("", "matexe-tikz-*")
	if err != nil {
		return "", err
	}
	defer os.RemoveAll(tmpDir)

	doc := "\\documentclass[tikz,border=2pt]{standalone}\n\\begin{document}\n" +
		"\\begin{tikzpicture}\n" + code + "\n\\end{tikzpicture}\n\\end{document}\n"
	if err := os.WriteFile(filepath.Join(tmpDir, "doc.tex"), []byte(doc), 0o644); err != nil {
		return "", err
	}

	cmd := exec.Command("pdflatex", "-interaction=nonstopmode", "-halt-on-error", "doc.tex")
	cmd.Dir = tmpDir
	if err := cmd.Run(); err != nil {
		return `<p class="matexe-warning">⚠ Erro compilando o debuxo TikZ (revisa a sintaxe).</p>`, nil
	}

	pngPath := filepath.Join(tmpDir, "doc.png")
	conv := exec.Command("pdftoppm", "-png", "-r", "150", "-singlefile",
		filepath.Join(tmpDir, "doc.pdf"), filepath.Join(tmpDir, "doc"))
	if out, err := conv.CombinedOutput(); err != nil {
		return "", fmt.Errorf("pdftoppm: %w: %s", err, out)
	}

	png, err := os.ReadFile(pngPath)
	if err != nil {
		return "", fmt.Errorf("reading generated tikz png %s: %w", pngPath, err)
	}

	if m.Format == FormatMarkdown {
		// Same treatment as plot(): a real file in images/, referenced by
		// relative path, instead of an embedded data: URI. Shares
		// m.plotCount with plot() so filenames never collide when a
		// document mixes <PLOT> and <TIKZ> blocks.
		m.plotCount++
		filename := fmt.Sprintf("img_%d.png", m.plotCount)
		imgDir := filepath.Join(m.outDir, "images")
		if err := os.MkdirAll(imgDir, 0o755); err != nil {
			return "", err
		}
		if err := os.WriteFile(filepath.Join(imgDir, filename), png, 0o644); err != nil {
			return "", fmt.Errorf("writing tikz png %s: %w", filename, err)
		}
		return m.protect(fmt.Sprintf("![tikz](images/%s)", filename)), nil
	}

	dataURI := "data:image/png;base64," + base64.StdEncoding.EncodeToString(png)
	return fmt.Sprintf(`<img src="%s" alt="tikz">`, dataURI), nil
}
