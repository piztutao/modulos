package main

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

// Settings persists user-configurable options across runs, mirroring the
// "Opciones" dialog (UfrmOpciones.pas) in the 2013 app: CAS path and the
// Maxima preamble code.
type Settings struct {
	MaximaPath string `json:"maximaPath"`
	CodeIni    string `json:"codeIni"` // empty = use the embedded default
	// IAProvedor/IAAPIKey/IAModel/IABaseURL configuran o asistente de IA
	// opcional (botón ✨ nos bloques, ver ia_client.go) - calquera provedor
	// que fale un dos tres formatos de fío soportados (Gemini nativo,
	// Anthropic nativo, ou "compatible con OpenAI" - que cobre ChatGPT e
	// moitos outros, ver chamarIA). IAAPIKey baleira = asistente
	// desactivado, o resto de Yang funciona igual sen el.
	IAProvedor string `json:"iaProvedor"` // "gemini" | "anthropic" | "openai"
	IAAPIKey   string `json:"iaApiKey"`
	IAModel    string `json:"iaModel"`
	// IABaseURL só fai falla para un provedor "compatible con OpenAI" que
	// non sexa a propia OpenAI (Qwen, Perplexity...) - baleiro = enderezo
	// oficial do provedor (ver baseURLPorDefecto). O selector do frontend xa
	// o prerreche cos presets coñecidos, o profesorado non ten por que velo.
	IABaseURL string `json:"iaBaseUrl"`
	// IAPreset non o le ningunha chamada á IA - é só o valor do selector do
	// frontend (que nome de provedor amosar), gardado á parte de
	// IAProvedor/IABaseURL para poder redebuxar exactamente o mesmo preset
	// ao reabrir Opcións (ex. distinguir "Qwen" de "Outro" aínda que os dous
	// resolvan a IAProvedor="openai" cun IABaseURL parecido).
	IAPreset string `json:"iaPreset"`
	// LatexEngine escolle o compilador: "" ou "pdflatex" (por defecto),
	// "xelatex" ou "lualatex" (soporte Unicode/fontes do sistema nativo,
	// útil para símbolos especiais coma letras gregas ou fontes propias).
	LatexEngine string `json:"latexEngine"`
	// Decimais limita as cifras decimais que Maxima amosa nos resultados en
	// coma flotante (ex. "3.56" en vez de "3.555555555555556") - sen isto,
	// calquera cálculo que non quede en fracción exacta propaga toda a
	// precisión da máquina ao PDF. 0/sen configurar = usar o valor por
	// defecto (2), resolto no punto de uso - mesmo patrón ca LatexEngine.
	Decimais int `json:"decimais"`
	// Decimal, cando true, fai que TODOS os resultados de <MAT>/<EVAL> se
	// amosen en coma decimal por defecto (ex. "1.15"), en vez da fracción
	// exacta que Maxima usa por defecto cando o cálculo só ten enteiros
	// (ex. "23/20") - ver cas.Maxima.ForzarDecimal/matexe_decimal. Por
	// defecto (false) mantense o comportamento previo, fracción exacta,
	// que precisan exercicios coma "Simplificación de fraccións"
	// (testdata/test.matex) - un profesor de física que queira sempre
	// decimal actívao aquí en vez de escribir matexe_decimal(...) en cada
	// <MAT>; un exercicio solto que queira a excepción contraria pode
	// envolver <MAT>matexe_fraccion(...)</MAT> aínda con isto activado.
	Decimal bool `json:"decimal"`
	// TimeoutSegundos limita canto agarda Yang por unha resposta de Maxima
	// a UNHA soa chamada (<MAT>/<EVAL>/<HIDE>...) antes de dala por
	// atascada (bucle infinito, ou proceso morto/wedged) e reiniciar a
	// sesión automaticamente - ver cas.Session.SetTimeout. 0/sen configurar
	// = usar o valor por defecto (30s), resolto no punto de uso - mesmo
	// patrón ca Decimais/LatexEngine.
	TimeoutSegundos int `json:"timeoutSegundos"`
	// Idioma escolle a lingua da interface: "" ou "gl" (galego, por
	// defecto), "es", "en" ou "pt". Os dicionarios en si viven en
	// yang/idiomas/*.json, importados directamente polo frontend
	// (frontend/src/main.js) - este campo só persiste a escolla do
	// profesorado entre sesións, o propio Go nunca traduce nada.
	Idioma string `json:"idioma"`
	// XerarAoGardar, cando activo (por defecto), fai que Gardar/Gardar como
	// (Ctrl+S) tamén recompile o documento (mesmo que premer Xerar/Ctrl+X) -
	// así a vista previa nunca queda desincronizada do que se acaba de
	// gardar. Un *bool (non un bool a secas) porque o valor por defecto é
	// true: un ficheiro settings.json vello (ou un profesor que nunca abriu
	// Opcións) non ten esta chave, e un bool normal léraa como false
	// (desactivado) por defecto de Go - mesmo problema que Decimais/
	// TimeoutSegundos resolven con "0 = usar o valor por defecto", pero aquí
	// false SI é un valor válido e distinguible de "sen configurar" (nil),
	// así que fai falla un punteiro. Ver XerarAoGardarResolto.
	XerarAoGardar *bool `json:"xerarAoGardar,omitempty"`
	// ExportarPDF/ExportarTex/ExportarMarkdown/ExportarDocx/ExportarOdt
	// deciden que botóns de exportación amosa a toolbar da previsualización
	// (btnPDF/btnExportTex/btnExportMarkdown/btnExportDocx/btnExportOdt en
	// frontend/src/main.js) - un profesor que só use PDF pode agochar TeX/MD/
	// DOCX/ODT en vez de ter cinco botóns sempre visibles. PDF/Tex/Markdown
	// son *bool (mesmo motivo ca XerarAoGardar: por defecto ACTIVADOS, así
	// que "sen configurar" (nil) ten que distinguirse de "false" explícito).
	// Docx/Odt son bool normal porque por defecto van DESACTIVADOS (precisan
	// Pandoc, unha dependencia extra que non todo profesorado instala) - o
	// valor cero de Go (false) xa é o defecto correcto, non fai falla
	// punteiro.
	ExportarPDF      *bool `json:"exportarPdf,omitempty"`
	ExportarTex      *bool `json:"exportarTex,omitempty"`
	ExportarMarkdown *bool `json:"exportarMarkdown,omitempty"`
	ExportarDocx     bool  `json:"exportarDocx"`
	ExportarOdt      bool  `json:"exportarOdt"`
}

// XerarAoGardarResolto devolve XerarAoGardar coa regra de "sen configurar
// (nil) -> true" xa aplicada, mesmo criterio ca DecimaisResolto/
// TimeoutResolto pero para un booleano.
func (s Settings) XerarAoGardarResolto() bool {
	return s.XerarAoGardar == nil || *s.XerarAoGardar
}

// ExportarPDFResolto/ExportarTexResolto/ExportarMarkdownResolto aplican a
// mesma regra de "sen configurar (nil) -> true" ca XerarAoGardarResolto -
// un settings.json vello, ou un profesor que nunca abriu Opcións, non ten
// estas chaves e os cinco botóns de exportación deben seguir visibles coma
// sempre.
func (s Settings) ExportarPDFResolto() bool {
	return s.ExportarPDF == nil || *s.ExportarPDF
}

func (s Settings) ExportarTexResolto() bool {
	return s.ExportarTex == nil || *s.ExportarTex
}

func (s Settings) ExportarMarkdownResolto() bool {
	return s.ExportarMarkdown == nil || *s.ExportarMarkdown
}

// DecimaisResolto devolve Decimais coa regra de "0/sen configurar -> 2"
// xa aplicada, para pasarlle un valor listo a cas.Maxima.SetDecimais.
func (s Settings) DecimaisResolto() int {
	if s.Decimais <= 0 {
		return 2
	}
	return s.Decimais
}

// TimeoutResolto devolve TimeoutSegundos coa regra de "0/sen configurar ->
// 30s" xa aplicada, listo para cas.Maxima.SetTimeout.
func (s Settings) TimeoutResolto() time.Duration {
	if s.TimeoutSegundos <= 0 {
		return 30 * time.Second
	}
	return time.Duration(s.TimeoutSegundos) * time.Second
}

func settingsPath() (string, error) {
	dir, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	dir = filepath.Join(dir, "yang")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	return filepath.Join(dir, "settings.json"), nil
}

func loadSettings() Settings {
	s := Settings{MaximaPath: findMaxima()}
	path, err := settingsPath()
	if err != nil {
		return s
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return s
	}
	var loaded Settings
	if json.Unmarshal(b, &loaded) == nil {
		if loaded.MaximaPath != "" {
			s.MaximaPath = loaded.MaximaPath
		}
		s.CodeIni = loaded.CodeIni
		s.IAProvedor = loaded.IAProvedor
		s.IAAPIKey = loaded.IAAPIKey
		s.IAModel = loaded.IAModel
		s.IABaseURL = loaded.IABaseURL
		s.IAPreset = loaded.IAPreset
		s.LatexEngine = loaded.LatexEngine
		s.Decimais = loaded.Decimais
		s.Decimal = loaded.Decimal
		s.TimeoutSegundos = loaded.TimeoutSegundos
		s.Idioma = loaded.Idioma
		s.XerarAoGardar = loaded.XerarAoGardar
		s.ExportarPDF = loaded.ExportarPDF
		s.ExportarTex = loaded.ExportarTex
		s.ExportarMarkdown = loaded.ExportarMarkdown
		s.ExportarDocx = loaded.ExportarDocx
		s.ExportarOdt = loaded.ExportarOdt
	}
	migrarAxustesIAVellos(b, &s)
	return s
}

// migrarAxustesIAVellos le un settings.json gardado por unha versión
// anterior a esta (só tiña geminiApiKey/geminiModel, sempre Gemini, sen os
// campos IA* xenéricos de enriba) e completa eses campos novos se aínda
// están baleiros - así un profesor que xa tiña a IA configurada non ten
// que volver escribir a clave despois de actualizar Yang. Non toca nada se
// xa hai IAAPIKey (configuración xa migrada ou feita coa versión nova).
func migrarAxustesIAVellos(b []byte, s *Settings) {
	if s.IAAPIKey != "" {
		return
	}
	var vello struct {
		GeminiAPIKey string `json:"geminiApiKey"`
		GeminiModel  string `json:"geminiModel"`
	}
	if json.Unmarshal(b, &vello) != nil || vello.GeminiAPIKey == "" {
		return
	}
	s.IAProvedor = string(ProvedorGemini)
	s.IAPreset = string(ProvedorGemini)
	s.IAAPIKey = vello.GeminiAPIKey
	s.IAModel = vello.GeminiModel
}

func saveSettingsToDisk(s Settings) error {
	path, err := settingsPath()
	if err != nil {
		return err
	}
	b, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o644)
}

// findMaxima looks for the maxima binary in common locations and finally
// falls back to a PATH lookup, mirroring the fallback chain in
// TMainForm.run / TMaxima.CAS_open.
func findMaxima() string {
	candidates := []string{"/usr/bin/maxima", "/usr/local/bin/maxima"}
	for _, c := range candidates {
		if _, err := os.Stat(c); err == nil {
			return c
		}
	}
	if p, err := exec.LookPath("maxima"); err == nil {
		return p
	}
	return ""
}

// GetSettings returns the currently active settings, exposed to the UI's
// options panel.
func (a *App) GetSettings() Settings {
	return a.settings
}

// SaveSettings persists new settings and applies them immediately.
func (a *App) SaveSettings(s Settings) error {
	a.settings = s
	a.maximaPath = s.MaximaPath
	return saveSettingsToDisk(s)
}

// DetectMaxima re-runs the auto-detection, for a "detectar" button in the
// options panel.
func (a *App) DetectMaxima() string {
	return findMaxima()
}
