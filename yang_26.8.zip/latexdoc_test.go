package main

import (
	"bytes"
	"context"
	"encoding/base64"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// TestLatexConverterIgnoresExTag is the regression test for the block
// editor's structural <EX> tag (blocks-serialize.js): it must render like
// span/a/font (children only, no wrapper) and must NOT be recorded as an
// unsupported tag, or every PDF export of a block-editor document would
// carry a spurious "etiqueta HTML sen soporte" warning.
func TestLatexConverterIgnoresExTag(t *testing.T) {
	nodes, err := parseFragment("<EX>ola</EX>")
	if err != nil {
		t.Fatal(err)
	}
	conv := newLatexConverter("", "")
	var out strings.Builder
	for _, n := range nodes {
		out.WriteString(conv.render(n))
	}
	if !strings.Contains(out.String(), "ola") {
		t.Fatalf("expected content to pass through, got: %q", out.String())
	}
	if conv.unknownTags["ex"] {
		t.Errorf("<EX> should not be flagged as an unsupported tag")
	}
}

// TestLatexConverterRendersHr is the regression test for "⚠ etiqueta HTML
// sen soporte en PDF: <hr>" showing up on any document with a horizontal
// rule: <hr> must render as an actual visible line (not silently vanish,
// which is what the default case would do - <hr> is a void element, no
// children to pass through) and must NOT be recorded as an unsupported tag.
func TestLatexConverterRendersHr(t *testing.T) {
	nodes, err := parseFragment("<p>antes</p><hr><p>despois</p>")
	if err != nil {
		t.Fatal(err)
	}
	conv := newLatexConverter("", "")
	var out strings.Builder
	for _, n := range nodes {
		out.WriteString(conv.render(n))
	}
	if !strings.Contains(out.String(), `\rule{\linewidth}`) {
		t.Errorf("expected a \\rule (horizontal line), got: %q", out.String())
	}
	if conv.unknownTags["hr"] {
		t.Errorf("<hr> should not be flagged as an unsupported tag")
	}
}

// TestLatexConverterRendersSubSup is the regression test for "limx → ∞"
// showing up flat/unstacked in the PDF instead of a proper subscript: <sub>/
// <sup> fell into the default case (unknown tag, children-only) before this
// fix, so "lim<sub>x → ∞</sub>" lost its subscript entirely. Must render as
// $_{...}$/$^{...}$ and must NOT be recorded as an unsupported tag.
func TestLatexConverterRendersSubSup(t *testing.T) {
	nodes, err := parseFragment("lim<sub>x → ∞</sub> e x<sup>2</sup>")
	if err != nil {
		t.Fatal(err)
	}
	conv := newLatexConverter("", "")
	var out strings.Builder
	for _, n := range nodes {
		out.WriteString(conv.render(n))
	}
	got := out.String()
	if !strings.Contains(got, `$_{x `) {
		t.Errorf("expected a $_{...} subscript, got: %q", got)
	}
	if !strings.Contains(got, `$^{2}$`) {
		t.Errorf("expected a $^{...} superscript, got: %q", got)
	}
	if conv.unknownTags["sub"] || conv.unknownTags["sup"] {
		t.Errorf("<sub>/<sup> should not be flagged as unsupported tags")
	}
}

// TestImgIncludeOptions covers the width/height sizing the block editor's
// "Inserir imaxe" control (blocks.js) adds to <IMG>: no size at all keeps
// the original centred/30%-width default (standalone=true), one dimension
// keeps the aspect ratio, and both dimensions together stretch to that
// exact box - same semantics as plain HTML <img width height>.
func TestImgIncludeOptions(t *testing.T) {
	cases := []struct {
		name           string
		width, height  string
		wantOpts       string
		wantStandalone bool
	}{
		{"none", "", "", `width=0.3\textwidth`, true},
		{"width only, px", "120", "", "width=3.175cm,keepaspectratio", false},
		{"height only, cm unit", "", "4cm", "height=4cm,keepaspectratio", false},
		{"both, mixed units", "5cm", "60mm", "width=5cm,height=60mm", false},
		{"percent width", "50%", "", `width=0.5\textwidth,keepaspectratio`, false},
		{"unparseable falls back to standalone", "auto", "", `width=0.3\textwidth`, true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			opts, standalone := imgIncludeOptions(c.width, c.height)
			if opts != c.wantOpts || standalone != c.wantStandalone {
				t.Errorf("imgIncludeOptions(%q, %q) = (%q, %v), want (%q, %v)",
					c.width, c.height, opts, standalone, c.wantOpts, c.wantStandalone)
			}
		})
	}
}

// TestMotoresParaProbarPreferidoInexistente is the regression test for the
// "usuario ten mal seleccionado o compilador" case: if the configured
// engine doesn't exist as a command at all, motoresParaProbar must still
// offer whatever real engines ARE installed (as fallback candidates),
// instead of returning a list that only ever contains the broken choice.
func TestMotoresParaProbarPreferidoInexistente(t *testing.T) {
	candidatos := motoresParaProbar("motor-que-non-existe-xyz")
	for _, m := range candidatos {
		if m == "motor-que-non-existe-xyz" {
			t.Fatalf("motoresParaProbar non debería devolver un motor que non existe: %v", candidatos)
		}
	}
	// Se hai polo menos un motor LaTeX real instalado nesta máquina, ten
	// que aparecer na lista (é o que permite o fallback).
	for _, m := range []string{"pdflatex", "xelatex", "lualatex"} {
		if commandExists(m) {
			found := false
			for _, c := range candidatos {
				if c == m {
					found = true
				}
			}
			if !found {
				t.Errorf("%s está instalado pero non aparece entre os candidatos: %v", m, candidatos)
			}
		}
	}
}

// TestCompileLatexAutoFallback exercises the transparent-fallback path
// itself: with a preferred engine that can't run at all, compileLatexAuto
// must still produce a PDF using whatever real engine is installed, and
// report that engine back via usedEngine so the caller can warn the user.
func TestCompileLatexAutoFallback(t *testing.T) {
	if !commandExists("pdflatex") {
		t.Skip("pdflatex not found on this machine, skipping")
	}
	dir := t.TempDir()
	pdf, _, log, usedEngine, err := compileLatexAuto(dir, "Ola mundo", "motor-que-non-existe-xyz")
	if err != nil {
		t.Fatalf("compileLatexAuto debería recuperarse co fallback, pero fallou: %v\nlog:\n%s", err, log)
	}
	if usedEngine == "" || usedEngine == "motor-que-non-existe-xyz" {
		t.Errorf("usedEngine debería ser un motor real instalado, foi %q", usedEngine)
	}
	if !bytes.HasPrefix(pdf, []byte("%PDF")) {
		t.Fatalf("output doesn't look like a PDF (%d bytes)", len(pdf))
	}
}

// TestGeneratePDF exercises App.GeneratePDF - the exact code path the
// compiled app runs for "PDF (LaTeX)" - against the real 2013 sample
// documents, compiling all the way to actual PDF bytes with pdflatex.
func TestGeneratePDF(t *testing.T) {
	a := &App{}
	a.startup(context.Background())
	if strings.TrimSpace(a.maximaPath) == "" {
		t.Skip("maxima not found on this machine, skipping")
	}
	if !commandExists("pdflatex") {
		t.Skip("pdflatex not found on this machine, skipping")
	}

	entries, err := os.ReadDir("testdata")
	if err != nil {
		t.Fatalf("reading testdata: %v", err)
	}

	// test.matex references logo.png relative to this dir in the original
	// tree - point BaseDir there so the <IMG> path gets exercised too.
	baseDir := "/home/usuario/Descargas/matexe.2013/files.maxima/test.out"

	for _, e := range entries {
		if !strings.HasSuffix(e.Name(), ".matex") {
			continue
		}
		e := e
		t.Run(e.Name(), func(t *testing.T) {
			src, err := os.ReadFile(filepath.Join("testdata", e.Name()))
			if err != nil {
				t.Fatal(err)
			}

			result, err := a.GeneratePDF(GeneratePDFRequest{
				Source:     string(src),
				Seed:       7,
				Iterations: 2,
				BaseDir:    baseDir,
			})
			if err != nil {
				t.Fatalf("GeneratePDF failed: %v\nlog:\n%s", err, result.Log)
			}
			if len(result.Warnings) > 0 {
				t.Logf("warnings: %v", result.Warnings)
			}

			pdf, decErr := base64.StdEncoding.DecodeString(result.PDFBase64)
			if decErr != nil {
				t.Fatalf("decoding PDF: %v", decErr)
			}
			if !bytes.HasPrefix(pdf, []byte("%PDF")) {
				t.Fatalf("output doesn't look like a PDF (%d bytes)", len(pdf))
			}
			t.Logf("%s: %d bytes of PDF generated", e.Name(), len(pdf))

			// Preview page images (pdfPageImages) back the block editor's
			// print preview - every compile should produce at least one.
			if len(result.PageImages) == 0 {
				t.Errorf("expected at least one page image, got none (warnings: %v)", result.Warnings)
			}
			for i, img := range result.PageImages {
				if !strings.HasPrefix(img, "data:image/png;base64,") {
					t.Errorf("page %d: expected a PNG data URI, got prefix %q", i, img[:min(40, len(img))])
				}
			}
			t.Logf("%s: %d page image(s)", e.Name(), len(result.PageImages))

			// Save it somewhere persistent (this run's t.TempDir) so it can
			// be eyeballed manually if needed.
			out := filepath.Join(t.TempDir(), e.Name()+".pdf")
			if err := os.WriteFile(out, pdf, 0o644); err != nil {
				t.Fatal(err)
			}
			t.Logf("saved to %s", out)
		})
	}
}
