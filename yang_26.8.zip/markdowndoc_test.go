package main

import (
	"strings"
	"testing"
)

// TestMarkdownConverterHR comproba que <hr> se traduce a "---" (regra
// horizontal estándar en Markdown) no canto de caer no ramo "default" de
// renderElement, que o marcaría coma etiqueta sen soporte e dispararía o
// aviso "etiqueta HTML sen soporte en Markdown" na UI.
func TestMarkdownConverterHR(t *testing.T) {
	nodes, err := parseFragment("<p>Antes</p><hr><p>Despois</p>")
	if err != nil {
		t.Fatalf("parseFragment: %v", err)
	}
	conv := newMarkdownConverter("", t.TempDir())
	var out string
	for _, n := range nodes {
		out += conv.render(n)
	}
	if conv.unknownTags["hr"] {
		t.Error("<hr> non debería quedar marcado coma etiqueta sen soporte")
	}
	if !strings.Contains(out, "---") {
		t.Errorf("esperaba unha regra horizontal (---) na saída, obtiven: %q", out)
	}
}
