package main

import (
	"bytes"
	"fmt"
	"os/exec"
	"runtime"
	"strings"
)

// InstallStatus reports the outcome of an install attempt back to the UI.
type InstallStatus struct {
	Success bool   `json:"success"`
	Log     string `json:"log"`
}

func commandExists(name string) bool {
	_, err := exec.LookPath(name)
	return err == nil
}

// linuxInstallCommand picks the first available package manager and
// returns the full command line to install Maxima + gnuplot with it.
// apt gets "update &&" first since a stale package cache is the most
// common reason a fresh install fails; the others normally auto-refresh.
func linuxInstallCommand() (argv []string, mgrName string, ok bool) {
	switch {
	case commandExists("apt-get"):
		return []string{"sh", "-c", "apt-get update && apt-get install -y maxima maxima-share gnuplot"}, "apt-get", true
	case commandExists("dnf"):
		return []string{"dnf", "install", "-y", "maxima", "gnuplot"}, "dnf", true
	case commandExists("pacman"):
		return []string{"pacman", "-Sy", "--noconfirm", "maxima", "gnuplot"}, "pacman", true
	case commandExists("zypper"):
		return []string{"zypper", "install", "-y", "maxima", "gnuplot"}, "zypper", true
	}
	return nil, "", false
}

// linuxLatexInstallCommand mirrors linuxInstallCommand for the LaTeX
// toolchain: pdflatex (base+recommended, covers amsmath/amssymb/xcolor/
// geometry), TikZ (its own package on Debian/Ubuntu - texlive-latex-base
// alone does NOT include it, confirmed on this machine's dpkg -S), xelatex/
// lualatex (both optional engines offered in Opcións), and poppler-utils
// (pdftoppm - needed for the print preview and for <TIKZ> in HTML mode).
// Deliberately NOT texlive-full: that pulls in several GB of packages
// (fonts/languages Yang never uses) for what's normally a ~300-500MB
// install with these named packages.
func linuxLatexInstallCommand() (argv []string, mgrName string, ok bool) {
	switch {
	case commandExists("apt-get"):
		return []string{"sh", "-c", "apt-get update && apt-get install -y texlive-latex-base texlive-latex-recommended texlive-pictures texlive-xetex texlive-luatex poppler-utils"}, "apt-get", true
	case commandExists("dnf"):
		return []string{"dnf", "install", "-y", "texlive-latex", "texlive-collection-pictures", "texlive-xetex", "texlive-luatex", "poppler-utils"}, "dnf", true
	case commandExists("pacman"):
		return []string{"pacman", "-Sy", "--noconfirm", "texlive-core", "texlive-pictures", "poppler"}, "pacman", true
	case commandExists("zypper"):
		return []string{"zypper", "install", "-y", "texlive", "texlive-latex", "poppler-tools"}, "zypper", true
	}
	return nil, "", false
}

// linuxPandocInstallCommand mirrors linuxInstallCommand/linuxLatexInstallCommand
// for Pandoc - the only extra tool ExportDocx/ExportOdt (docdoc.go) need,
// independent of the Maxima/LaTeX chain (a professor may want Word/
// OpenDocument output without ever touching PDF).
func linuxPandocInstallCommand() (argv []string, mgrName string, ok bool) {
	switch {
	case commandExists("apt-get"):
		return []string{"sh", "-c", "apt-get update && apt-get install -y pandoc"}, "apt-get", true
	case commandExists("dnf"):
		return []string{"dnf", "install", "-y", "pandoc"}, "dnf", true
	case commandExists("pacman"):
		return []string{"pacman", "-Sy", "--noconfirm", "pandoc"}, "pacman", true
	case commandExists("zypper"):
		return []string{"zypper", "install", "-y", "pandoc"}, "zypper", true
	}
	return nil, "", false
}

// DocDepsStatus mirrors LatexDepsStatus, for the DOCX/ODT export chain
// (docdoc.go) instead of the PDF one.
type DocDepsStatus struct {
	PandocFound bool `json:"pandocFound"`
}

// CheckDocDeps reports whether Pandoc is installed - see exportViaPandoc
// (docdoc.go), the only thing ExportDocx/ExportOdt actually need beyond
// what GeneratePDF already requires (Maxima).
func (a *App) CheckDocDeps() DocDepsStatus {
	return DocDepsStatus{PandocFound: commandExists("pandoc")}
}

// InstallPandoc mirrors InstallMaxima/InstallLatex exactly (same pkexec/
// winget/brew pattern, same "only runs when the user explicitly asks" rule)
// for Pandoc instead - see linuxPandocInstallCommand for what gets installed.
func (a *App) InstallPandoc() InstallStatus {
	var cmd *exec.Cmd

	switch runtime.GOOS {
	case "linux":
		argv, mgrName, ok := linuxPandocInstallCommand()
		if !ok {
			return InstallStatus{Log: "Non se atopou un xestor de paquetes coñecido (apt/dnf/pacman/zypper). Instala Pandoc manualmente."}
		}
		if !commandExists("pkexec") {
			return InstallStatus{Log: fmt.Sprintf("Non se atopou 'pkexec' para pedir permisos de administrador. Instala manualmente nun terminal cos comandos de %s.", mgrName)}
		}
		cmd = exec.Command("pkexec", argv...)

	case "windows":
		if !commandExists("winget") {
			return InstallStatus{Log: "Non se atopou winget. Descarga Pandoc manualmente desde https://pandoc.org/installing.html"}
		}
		cmd = exec.Command("winget", "install", "--id", "JohnMacFarlane.Pandoc", "-e",
			"--silent", "--accept-source-agreements", "--accept-package-agreements")

	case "darwin":
		if !commandExists("brew") {
			return InstallStatus{Log: "Non se atopou Homebrew. Instala Pandoc manualmente desde https://pandoc.org/installing.html"}
		}
		cmd = exec.Command("brew", "install", "pandoc")

	default:
		return InstallStatus{Log: "Sistema operativo non recoñecido para instalación automática."}
	}

	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	runErr := cmd.Run()
	log := strings.TrimSpace(out.String())

	// Re-detect regardless of the reported exit code, mesmo criterio que
	// InstallMaxima/InstallLatex.
	status := a.CheckDocDeps()
	if !status.PandocFound {
		if runErr != nil {
			log += "\n" + runErr.Error()
		}
		return InstallStatus{Success: false, Log: log}
	}
	return InstallStatus{Success: true, Log: log}
}

// LatexDepsStatus reports whether the tools Yang needs to compile/preview
// PDFs are installed - same idea as checking a.maximaPath, but for the rest
// of the compilation chain: the LaTeX engine currently selected in Opcións
// (GeneratePDF, latexdoc.go, fails with an error mentioning this same
// engine if it's missing) plus pdftoppm (poppler-utils), needed for the
// print preview (pdfPageImages) and for <TIKZ> in HTML mode (cas/tags.go).
type LatexDepsStatus struct {
	Engine        string `json:"engine"`
	EngineFound   bool   `json:"engineFound"`
	PdftoppmFound bool   `json:"pdftoppmFound"`
}

// OK reports whether everything Yang needs to compile a PDF is present -
// exposed as a method (not just a computed JS boolean) so the frontend
// doesn't have to duplicate this exact condition.
func (s LatexDepsStatus) OK() bool { return s.EngineFound && s.PdftoppmFound }

// CheckLatexDeps re-derives the configured engine the same way GeneratePDF
// does (empty setting = pdflatex), so switching engines in Opcións updates
// what gets checked without needing anything else to change.
func (a *App) CheckLatexDeps() LatexDepsStatus {
	engine := strings.TrimSpace(a.settings.LatexEngine)
	if engine == "" {
		engine = "pdflatex"
	}
	return LatexDepsStatus{
		Engine:        engine,
		EngineFound:   commandExists(engine),
		PdftoppmFound: commandExists("pdftoppm"),
	}
}

// InstallMaxima tries to install Maxima (+gnuplot for <PLOT>) using the
// platform's native package manager. On Linux it goes through pkexec so
// this GUI app never needs a terminal to prompt for a sudo password - the
// desktop's own polkit agent shows the native authentication dialog. It
// only runs when the user explicitly asks for it from the UI.
func (a *App) InstallMaxima() InstallStatus {
	var cmd *exec.Cmd

	switch runtime.GOOS {
	case "linux":
		argv, mgrName, ok := linuxInstallCommand()
		if !ok {
			return InstallStatus{Log: "Non se atopou un xestor de paquetes coñecido (apt/dnf/pacman/zypper). Instala Maxima manualmente."}
		}
		if !commandExists("pkexec") {
			return InstallStatus{Log: fmt.Sprintf("Non se atopou 'pkexec' para pedir permisos de administrador. Instala manualmente nun terminal cos comandos de %s.", mgrName)}
		}
		cmd = exec.Command("pkexec", argv...)

	case "windows":
		if !commandExists("winget") {
			return InstallStatus{Log: "Non se atopou winget. Descarga Maxima manualmente desde https://maxima.sourceforge.io"}
		}
		cmd = exec.Command("winget", "install", "--id", "Maxima.Maxima", "-e",
			"--silent", "--accept-source-agreements", "--accept-package-agreements")

	case "darwin":
		if !commandExists("brew") {
			return InstallStatus{Log: "Non se atopou Homebrew. Instala Maxima manualmente desde https://maxima.sourceforge.io"}
		}
		cmd = exec.Command("brew", "install", "maxima", "gnuplot")

	default:
		return InstallStatus{Log: "Sistema operativo non recoñecido para instalación automática."}
	}

	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	runErr := cmd.Run()
	log := strings.TrimSpace(out.String())

	// Re-detect regardless of the reported exit code - some package
	// managers exit non-zero on warnings even when the install succeeded.
	a.settings.MaximaPath = findMaxima()
	a.maximaPath = a.settings.MaximaPath
	saveSettingsToDisk(a.settings)

	if a.maximaPath == "" {
		if runErr != nil {
			log += "\n" + runErr.Error()
		}
		return InstallStatus{Success: false, Log: log}
	}
	return InstallStatus{Success: true, Log: log}
}

// InstallLatex mirrors InstallMaxima exactly (same pkexec/winget/brew
// pattern, same "only runs when the user explicitly asks" rule) for the
// LaTeX toolchain instead - see linuxLatexInstallCommand for what actually
// gets installed and why.
func (a *App) InstallLatex() InstallStatus {
	var cmd *exec.Cmd

	switch runtime.GOOS {
	case "linux":
		argv, mgrName, ok := linuxLatexInstallCommand()
		if !ok {
			return InstallStatus{Log: "Non se atopou un xestor de paquetes coñecido (apt/dnf/pacman/zypper). Instala LaTeX manualmente."}
		}
		if !commandExists("pkexec") {
			return InstallStatus{Log: fmt.Sprintf("Non se atopou 'pkexec' para pedir permisos de administrador. Instala manualmente nun terminal cos comandos de %s.", mgrName)}
		}
		cmd = exec.Command("pkexec", argv...)

	case "windows":
		if !commandExists("winget") {
			return InstallStatus{Log: "Non se atopou winget. Instala MiKTeX manualmente desde https://miktex.org"}
		}
		cmd = exec.Command("winget", "install", "--id", "MiKTeX.MiKTeX", "-e",
			"--silent", "--accept-source-agreements", "--accept-package-agreements")

	case "darwin":
		if !commandExists("brew") {
			return InstallStatus{Log: "Non se atopou Homebrew. Instala MacTeX manualmente desde https://www.tug.org/mactex/"}
		}
		cmd = exec.Command("brew", "install", "--cask", "mactex-no-gui")

	default:
		return InstallStatus{Log: "Sistema operativo non recoñecido para instalación automática."}
	}

	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	runErr := cmd.Run()
	log := strings.TrimSpace(out.String())

	// Re-detect regardless of the reported exit code, mesmo criterio que
	// InstallMaxima - algúns xestores de paquetes devolven un código non
	// cero por avisos aínda que a instalación fose ben.
	status := a.CheckLatexDeps()
	if !status.OK() {
		if runErr != nil {
			log += "\n" + runErr.Error()
		}
		return InstallStatus{Success: false, Log: log}
	}
	return InstallStatus{Success: true, Log: log}
}
