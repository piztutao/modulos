package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"strings"
	"time"
)

// Cliente de IA xenérico: fala con calquera provedor que use un destes tres
// formatos de fío (case a inmensa maioría do mercado):
//   - "gemini": API nativa de Google Gemini (systemInstruction + contents).
//   - "anthropic": API nativa de Claude (x-api-key + system + messages).
//   - "openai": formato "chat completions" de OpenAI - o que tamén falan de
//     fábrica moitos outros provedores en modo "compatible con OpenAI"
//     (Qwen/DashScope, Perplexity, Groq, Mistral, DeepSeek, Ollama en
//     local...), así que este mesmo camiño cobre ChatGPT E calquera destes
//     só cambiando o enderezo do servidor (ver baseURLPorDefecto/Settings.
//     IABaseURL) - por iso "xenérico/universal": non hai que escribir un
//     adaptador novo por cada marca, só para os poucos formatos de fío
//     realmente distintos que existen.
//
// O profesorado escolle un provedor por nome nun selector (Opcións, ver
// frontend/index.html) que xa pon o formato de fío e o enderezo por
// defecto correctos - nunca ten que sabelo nin escribilo á man.
type ProvedorIA string

const (
	ProvedorGemini    ProvedorIA = "gemini"
	ProvedorAnthropic ProvedorIA = "anthropic"
	ProvedorOpenAI    ProvedorIA = "openai" // tamén calquera "compatible con OpenAI"
)

var iaHTTPClient = &http.Client{Timeout: 90 * time.Second}

// baseURLPorDefecto devolve o enderezo oficial do provedor cando
// Settings.IABaseURL queda baleiro - só fai falla escribir un enderezo á
// man para un provedor "compatible con OpenAI" que non sexa a propia
// OpenAI (Qwen, Perplexity...), e aínda así o selector do frontend xa trae
// eses enderezos coma preset.
func baseURLPorDefecto(provedor ProvedorIA) string {
	switch provedor {
	case ProvedorGemini:
		return "https://generativelanguage.googleapis.com/v1beta"
	case ProvedorAnthropic:
		return "https://api.anthropic.com/v1"
	default:
		return "https://api.openai.com/v1"
	}
}

// chamarIA é o punto de entrada único que usan XerarContidoIA/
// XerarExercicioIA/XerarExameIA (app.go): decide o formato de fío polo
// provedor configurado e devolve o texto de resposta xa limpo de valados
// Markdown. `s` é a configuración completa (non só as claves) para que
// engadir un catro provedor no futuro só toque este switch, non cada
// chamador.
func chamarIA(s Settings, sistema, peticion string) (string, error) {
	if s.IAAPIKey == "" {
		return "", fmt.Errorf("falta a clave da API de IA (configúraa en Opcións)")
	}
	if s.IAModel == "" {
		return "", fmt.Errorf("falta o modelo de IA (configúrao en Opcións)")
	}

	provedor := ProvedorIA(s.IAProvedor)
	if provedor == "" {
		provedor = ProvedorGemini // configuracións anteriores a esta versión (só Gemini)
	}
	baseURL := strings.TrimRight(strings.TrimSpace(s.IABaseURL), "/")
	if baseURL == "" {
		baseURL = baseURLPorDefecto(provedor)
	}

	switch provedor {
	case ProvedorAnthropic:
		return chamarAnthropic(baseURL, s.IAAPIKey, s.IAModel, sistema, peticion)
	case ProvedorGemini:
		return chamarGemini(baseURL, s.IAAPIKey, s.IAModel, sistema, peticion)
	default:
		return chamarOpenAICompatible(baseURL, s.IAAPIKey, s.IAModel, sistema, peticion)
	}
}

// ── Gemini (nativo) ──────────────────────────────────────────────────────

type geminiPeticion struct {
	SystemInstruction *geminiContido  `json:"systemInstruction,omitempty"`
	Contents          []geminiContido `json:"contents"`
}

type geminiContido struct {
	Role  string        `json:"role,omitempty"`
	Parts []geminiParte `json:"parts"`
}

type geminiParte struct {
	Text string `json:"text,omitempty"`
}

type geminiResposta struct {
	Candidates []struct {
		Content geminiContido `json:"content"`
	} `json:"candidates"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

// chamarGemini envía `sistema` coma systemInstruction e `peticion` coma único
// contido do usuario. Idéntica xestión de erros ca en Xesta (mesmas
// mensaxes, mesmo comportamento comprobado empiricamente contra a API real:
// systemInstruction precisa Role:"user" ou a API devolve 400 sen máis
// detalle).
func chamarGemini(baseURL, apiKey, model, sistema, peticion string) (string, error) {
	corpo := geminiPeticion{
		SystemInstruction: &geminiContido{Role: "user", Parts: []geminiParte{{Text: sistema}}},
		Contents: []geminiContido{
			{Role: "user", Parts: []geminiParte{{Text: peticion}}},
		},
	}
	dados, err := json.Marshal(corpo)
	if err != nil {
		return "", err
	}

	url := baseURL + "/models/" + model + ":generateContent"
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(dados))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-goog-api-key", apiKey)

	resp, err := iaHTTPClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("non se puido contactar coa IA: %w", err)
	}
	defer resp.Body.Close()

	corpoResposta, _ := io.ReadAll(resp.Body)
	var r geminiResposta
	if err := json.Unmarshal(corpoResposta, &r); err != nil {
		return "", fmt.Errorf("resposta non válida da IA (HTTP %d)", resp.StatusCode)
	}
	if r.Error != nil {
		return "", fmt.Errorf("erro da IA: %s", r.Error.Message)
	}
	if resp.StatusCode != http.StatusOK || len(r.Candidates) == 0 || len(r.Candidates[0].Content.Parts) == 0 {
		return "", fmt.Errorf("a IA non devolveu resultado (HTTP %d)", resp.StatusCode)
	}

	return limparValadosMarkdown(r.Candidates[0].Content.Parts[0].Text), nil
}

// ── Anthropic (nativo, Claude) ───────────────────────────────────────────

type anthropicPeticion struct {
	Model     string             `json:"model"`
	MaxTokens int                `json:"max_tokens"`
	System    string             `json:"system,omitempty"`
	Messages  []anthropicMensaxe `json:"messages"`
}

type anthropicMensaxe struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type anthropicResposta struct {
	Content []struct {
		Type string `json:"type"`
		Text string `json:"text"`
	} `json:"content"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

// chamarAnthropic fala coa API de Messages de Claude (api.anthropic.com) -
// autenticación por cabeceira x-api-key (non Bearer) e cabeceira obrigatoria
// anthropic-version, a diferenza dos outros dous formatos.
func chamarAnthropic(baseURL, apiKey, model, sistema, peticion string) (string, error) {
	corpo := anthropicPeticion{
		Model:     model,
		MaxTokens: 8192,
		System:    sistema,
		Messages:  []anthropicMensaxe{{Role: "user", Content: peticion}},
	}
	dados, err := json.Marshal(corpo)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequest(http.MethodPost, baseURL+"/messages", bytes.NewReader(dados))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", apiKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	resp, err := iaHTTPClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("non se puido contactar coa IA: %w", err)
	}
	defer resp.Body.Close()

	corpoResposta, _ := io.ReadAll(resp.Body)
	var r anthropicResposta
	if err := json.Unmarshal(corpoResposta, &r); err != nil {
		return "", fmt.Errorf("resposta non válida da IA (HTTP %d)", resp.StatusCode)
	}
	if r.Error != nil {
		return "", fmt.Errorf("erro da IA: %s", r.Error.Message)
	}
	if resp.StatusCode != http.StatusOK || len(r.Content) == 0 {
		return "", fmt.Errorf("a IA non devolveu resultado (HTTP %d)", resp.StatusCode)
	}

	var texto strings.Builder
	for _, bloque := range r.Content {
		if bloque.Type == "text" {
			texto.WriteString(bloque.Text)
		}
	}
	return limparValadosMarkdown(texto.String()), nil
}

// ── OpenAI / "compatible con OpenAI" (ChatGPT, Qwen, Perplexity, Groq...) ──

type openAIPeticion struct {
	Model    string          `json:"model"`
	Messages []openAIMensaxe `json:"messages"`
}

type openAIMensaxe struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type openAIResposta struct {
	Choices []struct {
		Message struct {
			Content string `json:"content"`
		} `json:"message"`
	} `json:"choices"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

// chamarOpenAICompatible fala o formato "chat completions" (POST
// {baseURL}/chat/completions, Authorization: Bearer <clave>) - o mesmo que
// falan de fábrica moitos outros provedores cando se lles pasa o enderezo
// axeitado (ver baseURLPorDefecto e os presets do selector no frontend).
func chamarOpenAICompatible(baseURL, apiKey, model, sistema, peticion string) (string, error) {
	corpo := openAIPeticion{
		Model: model,
		Messages: []openAIMensaxe{
			{Role: "system", Content: sistema},
			{Role: "user", Content: peticion},
		},
	}
	dados, err := json.Marshal(corpo)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequest(http.MethodPost, baseURL+"/chat/completions", bytes.NewReader(dados))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+apiKey)

	resp, err := iaHTTPClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("non se puido contactar coa IA: %w", err)
	}
	defer resp.Body.Close()

	corpoResposta, _ := io.ReadAll(resp.Body)
	var r openAIResposta
	if err := json.Unmarshal(corpoResposta, &r); err != nil {
		return "", fmt.Errorf("resposta non válida da IA (HTTP %d)", resp.StatusCode)
	}
	if r.Error != nil {
		return "", fmt.Errorf("erro da IA: %s", r.Error.Message)
	}
	if resp.StatusCode != http.StatusOK || len(r.Choices) == 0 {
		return "", fmt.Errorf("a IA non devolveu resultado (HTTP %d)", resp.StatusCode)
	}

	return limparValadosMarkdown(r.Choices[0].Message.Content), nil
}

// chuletaMatexe resume as etiquetas propias de Matexe — o único que a IA
// non coñece de fábrica (Maxima/LaTeX en xeral xa os coñece ben, non fai
// falla explicalos). Fonte: yang/help/Matexe Help/3*.html e cas/tags.go.
const chuletaMatexe = `Matexe é a linguaxe de marcado deste programa (Yang) para exames: HTML normal
con etiquetas especiais que Maxima procesa antes de xerar o documento final.

- <MAT>expr</MAT>: mostra a expresión SEN avaliar, en LaTeX.
- <EVAL>expr</EVAL>: avalía a expresión e mostra o resultado en LaTeX.
- <HIDE>expr1; expr2; ...</HIDE>: executa en silencio (varias expresións
  separadas por ; ou $), non mostra nada — para definir variables/funcións
  antes de usalas noutro anaco.
- <PLOT>chamada</PLOT>: xera unha imaxe cun gráfico Maxima (plot2d, plot3d,
  draw2d, draw3d).
- <TIKZ>código</TIKZ>: debuxo en código TikZ puro (LaTeX/pgf, non Maxima).
- <TEX>código</TEX>: LaTeX literal.
- <SISTEMA>eq1
  eq2
  eq3</SISTEMA>: sistema de ecuacións cunha chave compartida. UNHA ecuación
  Maxima por liña, SEN <MAT>/<EVAL> arredor de cada unha (o propio <SISTEMA>
  xa manda cada liña a Maxima). Úsao SEMPRE que o enunciado pida resolver/
  clasificar un sistema de varias ecuacións á vez - NUNCA repartas as
  ecuacións en varias <MAT> soltas nun <p> cada unha, iso non debuxa a chave:
  - CORRECTO: <SISTEMA>
x + 2*y - z = 4
2*x - y + z = 1
-x + y + 2*z = 3
</SISTEMA>
  - INCORRECTO: <p><MAT>x + 2*y - z = 4</MAT></p><p><MAT>2*x - y + z = 1</MAT></p>...

IMPORTANTE: o contido de <MAT>/<EVAL>/<HIDE> é sempre código MAXIMA, NUNCA
LaTeX xa escrito - é o propio Maxima quen o converte a LaTeX bonito
automaticamente, ti non tes que facelo. Usa sempre a sintaxe Maxima:
- CORRECTO: <MAT>sin(alpha)</MAT>  ->  INCORRECTO: <MAT>\sin(\alpha)</MAT>
- CORRECTO: <MAT>3/5</MAT>         ->  INCORRECTO: <MAT>\frac{3}{5}</MAT>
- CORRECTO: <MAT>sqrt(x)</MAT>     ->  INCORRECTO: <MAT>\sqrt{x}</MAT>
- CORRECTO: <MAT>4*x</MAT>         ->  INCORRECTO: <MAT>4x</MAT> (Maxima esixe
  o * de multiplicar; "4x" non é unha expresión válida)
- CORRECTO: <MAT>x^2</MAT>         ->  INCORRECTO: <MAT>x^{2}</MAT>
Nomes de variables tampouco levan barra invertida nin chaves: usa "alpha",
"pi" (ou %pi), "theta"... nunca "\alpha"/"\pi"/"\theta".

NUNCA metas unidades (kWh, Ω, A, V, h...) dentro de <MAT>/<EVAL> usando a
función text() de Maxima - é o mesmo erro que "4x": falta o * antes de
text(...), e Maxima falla con "text is not an infix operator":
- INCORRECTO: <MAT>2 text(" kWh") * 3 text(" h")</MAT>
As unidades van SEMPRE coma texto HTML normal, FÓRA de <MAT>/<EVAL> - a
expresión de dentro leva só números e variables, nada de texto:
- CORRECTO: <MAT>2 * 3</MAT> kWh

Fóra de <MAT>/<EVAL>, no texto normal dun anaco "text", os símbolos
matemáticos Unicode soltos (≈, ≤, ≥, ≠, ±, ×, ÷, →, ⇒, ∞, ∪, ∩, ∈, letras
gregas...) están ben coma texto normal - úsaos con confianza cando non
formen parte dunha expresión Maxima completa que se poida avaliar. Regra
clara para decidir entre texto normal e <MAT>/<EVAL>: se o que queres
mostrar é unha expresión Maxima COMPLETA (ten sentido avaliala ou
simplificala), vai en <MAT>/<EVAL>; se é só notación solta que estás a citar
(un símbolo de comparación referíndote a el, un intervalo coma "(-∞, -2]",
unha unión "A ∪ B"...), vai coma texto normal, NUNCA metido en <MAT>/<EVAL>
- Maxima non entende notación de intervalos nin un símbolo de comparación
sen os dous lados, e fallará:
- INCORRECTO: (incluído porque a desigualdade ten <MAT>>=</MAT>)
- CORRECTO: (incluído porque a desigualdade ten ≥)
- INCORRECTO: Solución: <MAT>(-inf, -2]</MAT> unida con <MAT>(3, inf)</MAT>
- CORRECTO: Solución: (-∞, -2] ∪ (3, +∞)

MOI IMPORTANTE, REGRA SEN EXCEPCIÓNS: o contido de <MAT>/<EVAL> ten que ser
SEMPRE unha expresión Maxima COMPLETA e válida por si soa. Antes de escribir
calquera <MAT>...</MAT> ou <EVAL>...</EVAL>, comproba que o de dentro, illado
do resto, sería aceptado por Maxima tal cal. Un "=" ao final sen lado dereito
NUNCA é válido - se che sae iso, é que tiñas que ter posto ese anaco coma
texto normal, non coma MAT:
- INCORRECTO: <MAT>cos(alpha) = </MAT><EVAL>cos_val</EVAL>
- INCORRECTO: <MAT>A =</MAT> <EVAL>area</EVAL>
- INCORRECTO: <MAT>f'(x) =</MAT> <EVAL>diff(f(x),x)</EVAL>
- INCORRECTO: <MAT>m = (6 - 2)/(3 - 1) =</MAT> <EVAL>m1</EVAL> (o mesmo erro
  aínda que a fórmula vaia dentro: CALQUERA "=" ao final, con ou sen máis
  texto antes, rompe sempre o parser de Maxima)
- CORRECTO: m = <MAT>(6 - 2)/(3 - 1)</MAT> = <EVAL>m1</EVAL>  (unha cadea
  "nome = fórmula = valor" repártese en TRES anacos: "nome = " coma texto,
  a fórmula soa en <MAT>, " = " coma texto, e o valor en <EVAL> - nunca vaia
  o "=" dentro da etiqueta, nin ao principio nin ao final)
- CORRECTO (máis simple): cos(α) = <EVAL>cos_val</EVAL>  (o "nome = " vai
  coma texto HTML normal, FÓRA de calquera etiqueta; só o valor calculado
  vai en <EVAL>)
Letras gregas soltas coma "α" no texto normal (fóra de MAT/EVAL) son HTML
válido, úsaas sen problema coma parte do texto.

PROHIBIDO usar un apóstrofo (') dentro de <MAT>/<EVAL>/<HIDE>, en ningún
caso: "f'(x)" (notación de "prima" para a derivada) NON é Maxima válido - o
apóstrofo ten outro significado en Maxima e rompe SEMPRE o parser, sen
excepción:
- INCORRECTO: <MAT>f'(x)</MAT>, <MAT>f'(x) =</MAT>, <EVAL>f'(3)</EVAL> (as
  tres fallan sempre, é o erro máis común - revisa antes de escribir "'"
  dentro de calquera etiqueta e sácao se o atopas)
- CORRECTO: escribe "f'(x)" coma texto HTML normal, FÓRA de <MAT>/<EVAL>,
  cando só queres nomear/referirte á derivada (é só texto, non se avalúa);
  usa <EVAL>diff(f(x),x)</EVAL> (sen apóstrofo ningún) cando queres o
  resultado calculado da derivada, e <EVAL>subst(3,x,diff(f(x),x))</EVAL>
  (non "f'(3)") para o seu valor nun punto.

PROHIBIDO usar unha barra invertida (\) dentro de <MAT>/<EVAL>/<HIDE>, en
ningún caso - non é notación de continuación de liña coma en bash/LaTeX,
Maxima non a entende e rompe SEMPRE o parser (e nun <HIDE> con varias
expresións separadas por ";", arrastra ao erro TODAS as que veñen despois):
- INCORRECTO: <HIDE>mcd_res: 2^3*3; mcm_res: 2^4*3^2*5; \</HIDE>
- CORRECTO: <HIDE>mcd_res: 2^3*3; mcm_res: 2^4*3^2*5;</HIDE> (varias
  expresións nunha soa liña, sen barra invertida ningunha ao final nin no
  medio)

Exemplos de Maxima válidos: f(x):=x^2+1 ; diff(f(x),x) ; integrate(x^2,x) ;
solve(x^2-4=0,x) ; plot2d(x^2,[x,-2,2]) ; sin(alpha) ; sqrt(1-x^2) ;
limit(f(x),x,inf).

<MAT>limit(...)</MAT> amosa a notación do límite (non un número solto) SEN
que fagas nada especial - Yang xa o cita internamente, escribe limit(...) tal
cal, SEN apóstrofo diante (o apóstrofo segue prohibido en <MAT>/<EVAL>, regra
enriba).

<sub>/<sup> (HTML normal, fóra de <MAT>/<EVAL>) están soportados para
notación solta que non é unha expresión Maxima completa, ex. "lim<sub>x →
∞</sub>" nunha frase, ou "H<sub>2</sub>O".

Para VALORES ALEATORIOS (datos que cambian en cada variante do exame, ex.
"unha resistencia de tantos ohmios"): a función de Maxima chámase
random(n) (número enteiro entre 0 e n-1), NUNCA "rand(n)" - "rand" NON
EXISTE en Maxima. Isto é perigoso porque NON dá erro ningún: rand(9) é
sintaxe válida (unha chamada a unha función sen definir), así que Maxima
déixaa sen avaliar e sae literal e mal no exame ("R = rand(9)+2" en vez
dun número). Mellor aínda ca random(n) cru, este programa xa trae
xeradores feitos para isto, defínense en <HIDE> e úsanse en <EVAL>:
- n0()/n1()/n2(): natural aleatorio pequeno/mediano/grande (2 a 4, 2 a 10,
  2 a 101 respectivamente).
- z0()/z1()/z2(): igual que n0/n1/n2 pero enteiro con signo aleatorio.
- q0()/q1()/q2(): igual pero racional (fracción) non enteira.
Exemplo completo e correcto: <HIDE>R_val: n1()</HIDE> ... resistencia de
<EVAL>R_val</EVAL> Ω.`

// systemPromptPara devolve a chuleta común máis unha instrución de saída
// estrita para `tipo` (o mesmo "type" que usa blocks-serialize.js), para que
// o resultado se poida meter directamente no textarea do bloque sen
// envoltorios nin explicacións. "image-upload" non ten sentido aquí (é un
// ficheiro do disco, non contido xerable) — o frontend non ofrece o botón ✨
// nese caso, pero devolver un prompt razoable de todos xeitos non fai mal.
func systemPromptPara(tipo string) string {
	var instrucion string
	switch tipo {
	case "formula", "variables":
		instrucion = "Escribe SÓ unha expresión Maxima válida, nunha soa liña, sen etiquetas " +
			"<EVAL>/<HIDE> ao redor, sen explicacións nin comentarios. Exemplo de resposta " +
			"completa e correcta: diff(x^2+1,x)"
	case "image-plot":
		instrucion = "Escribe SÓ unha chamada Maxima de debuxo (plot2d, plot3d, draw2d ou " +
			"draw3d), sen etiquetas ao redor, sen explicacións. Exemplo de resposta completa " +
			"e correcta: plot2d(x^2,[x,-2,2])"
	case "image-tikz":
		instrucion = "Escribe SÓ código TikZ, SEN \\begin{tikzpicture}/\\end{tikzpicture} " +
			"(Yang xa os pon), sen explicacións. Exemplo de resposta completa e correcta: " +
			"\\draw (0,0) -- (1,0) -- (0,1) -- cycle;"
	default: // "text"
		instrucion = "Escribe SÓ o texto/HTML do enunciado (parágrafos, <b>, <i>, listas... " +
			"permitidos), en galego salvo que se pida outro idioma, sen explicacións adicionais " +
			"nin comentarios sobre o que fixeches."
	}
	return chuletaMatexe + "\n\n" + instrucion
}

// asistenteEdicionRe recoñece unha proposta de edición na resposta do
// asistente (ver systemPromptAsistente/AsistenteIA, app.go). Marcas de
// texto simples en vez de pedirlle á IA que devolva JSON a propósito: o
// contido que se está a editar adoita levar código Maxima/TikZ/HTML cheo
// de aspas e barras invertidas - escapalo correctamente dentro dun string
// JSON é un xeito doado de que a IA rompa o parseo sen querer. Coas marcas,
// o contido vai literal, sen escapar nada.
var asistenteEdicionRe = regexp.MustCompile(`(?s)<<<EDICION>>>\s*\n?(.*?)\n?\s*<<<FIN_EDICION>>>`)

// systemPromptAsistente é o prompt do asistente de IA integrado (icona 🤖,
// editor de Código e modais do editor de bloques - ver AsistenteIA, app.go):
// a diferenza de systemPromptPara (que xera SEMPRE contido novo dende cero),
// aquí a IA recibe o contido ACTUAL e ten que decidir por si mesma se a
// petición é unha PREGUNTA (responde en prosa, non toca nada) ou unha
// instrución de CAMBIO (propón contido novo completo, envolto nas marcas
// que asistenteEdicionRe recoñece). tipo engade "documento" (o .matex
// enteiro do editor de Código) aos tipos xa coñecidos de blocks-serialize.js.
func systemPromptAsistente(tipo string) string {
	var descricionTipo string
	switch tipo {
	case "documento":
		descricionTipo = "un documento .matex COMPLETO (o exame/práctica enteiro: HTML normal mesturado con etiquetas Matexe)"
	case "formula", "variables":
		descricionTipo = "unha soa expresión Maxima"
	case "image-plot":
		descricionTipo = "unha chamada Maxima de debuxo (plot2d/plot3d/draw2d/draw3d)"
	case "image-tikz":
		descricionTipo = "código TikZ (sen \\begin{tikzpicture}/\\end{tikzpicture}, Yang xa os pon)"
	default: // "text"
		descricionTipo = "o HTML/texto dun enunciado (pode levar etiquetas Matexe embebidas, ex. <MAT>...</MAT>)"
	}
	return chuletaMatexe + fmt.Sprintf(`

Es un asistente integrado no editor de Yang. O profesorado mándache o
CONTIDO ACTUAL (%s) e unha petición en linguaxe natural - pode ser:

- Unha PREGUNTA sobre ese contido (explica, non toques nada): responde en
  prosa normal, en galego salvo que se pida outro idioma. NON uses as
  marcas de edición descritas abaixo para unha simple pregunta.
- Unha instrución de CAMBIO: envolve o contido NOVO COMPLETO (non só a
  parte que cambia, o texto enteiro que debe quedar) entre as marcas
  <<<EDICION>>> e <<<FIN_EDICION>>>, cada unha na súa propia liña. Podes
  engadir unha explicación breve FÓRA das marcas (antes ou despois), pero
  dentro delas vai só o contido en si, literal, sen valados markdown e sen
  comentarios sobre o cambio mesturados co contido.
- Se o contido actual vén baleiro, calquera petición é para CREAR contido
  novo (mesmas marcas de edición).
`, descricionTipo)
}

// tiposAnacoValidos son os "type" que blocks-serialize.js sabe interpretar
// como anaco dun exercicio (mesmos que ELEMENT_META en blocks.js, agás
// "image-upload": é un ficheiro do disco, non hai nada que a IA xere aí).
var tiposAnacoValidos = map[string]bool{
	"text": true, "variables": true, "formula": true, "image-plot": true, "image-tikz": true,
}

// systemPromptExercicio pide á IA un EXERCICIO enteiro (varios anacos en
// orde, non un anaco solto coma systemPromptPara) en JSON estrito, para que
// o profesorado nunca teña que escoller un tipo de bloque nin saber que
// existen "EVAL"/"HIDE" — só describe o exercicio, Yang crea os anacos.
const systemPromptExercicio = chuletaMatexe + `

Vas crear un EXERCICIO completo para un exame, composto por unha lista
ordenada de anacos. Cada anaco ten "type" (un destes valores exactos: "text",
"variables", "formula", "image-plot", "image-tikz") e "content" (o contido
dese anaco, na sintaxe que corresponda ao seu type):
- "text": HTML/texto do enunciado (parágrafos, <b>, <i>, listas...). Calquera
  cálculo ou símbolo matemático DENTRO dun "text" ten que ir coas etiquetas
  <MAT>/<EVAL> descritas enriba (ex. "<p>f'(x) = <EVAL>diff(f(x),x)</EVAL></p>"
  ou "<p>Dada <MAT>f(x) = x^2+1</MAT>:</p>") - NUNCA "\( \)", "$...$" nin
  LaTeX cru: Yang non os interpreta, só as etiquetas Matexe.
- "variables": expresión(s) Maxima executadas en silencio para definir datos
  do exercicio (ex. "f(x):=x^2+1", ou varias separadas por ; ou $) - úsao
  cando o exercicio precise unha función ou valor previo antes de mostrar
  nada, ou cando queiras gardar un resultado para amosalo despois cun <EVAL>
  dentro dun "text" (ex. "cos_val: sqrt(1-sen_val^2)").
- "formula": UNHA soa expresión Maxima simple que se avalía e mostra tal
  cal - NON unha lista, NON unha ecuación simbólica con "=". Se queres
  amosar varios resultados etiquetados (ex. "cos(α) = 0.8"), NON uses
  "formula": fainos coma parte dun anaco "text" con <EVAL> embebido para
  cada un (ex. "<p>cos(α) = <EVAL>cos_val</EVAL></p>").
- "image-plot": UNHA chamada Maxima de debuxo (plot2d/plot3d/draw2d/draw3d).
- "image-tikz": código TikZ (sen \begin{tikzpicture}).

Regras estritas:
- Devolve SÓ un array JSON válido, sen texto adicional, sen explicacións,
  sen valados markdown (nada de ` + "```" + ` ao redor).
- Normalmente o primeiro anaco é "text" co enunciado; se fai falla definir
  algo antes de avalialo, usa "variables" xusto despois; usa "formula"/
  "image-plot"/"image-tikz" só para UN resultado ou gráfico final illado -
  para calquera outra mestura de texto+resultado, mételo nun "text" con
  <EVAL>/<MAT> embebidos, coma nos exemplos de enriba.
- En galego salvo que se pida outro idioma.

Exemplo de resposta completa e correcta (para "a derivada dunha función
cadrática, con gráfico"):
[{"type":"text","content":"Calcula a derivada de f(x) = x^2 + 3x - 2 e representa graficamente a función."},{"type":"variables","content":"f(x):=x^2+3*x-2"},{"type":"formula","content":"diff(f(x),x)"},{"type":"image-plot","content":"plot2d(f(x),[x,-5,5])"}]`

// systemPromptExame reemprega toda a instrución de systemPromptExercicio
// (forma dun exercicio: array de anacos type/content) para pedir un EXAME
// ENTEIRO de `numExercicios` exercicios distintos sobre un tema - o
// profesorado só escribe o tema (petición a chamarIA), o número xa vai
// fixado aquí no prompt de sistema. Diferenza coa resposta dun exercicio
// solto: agora é un array DE arrays (un array de anacos por exercicio).
func systemPromptExame(numExercicios int) string {
	return systemPromptExercicio + fmt.Sprintf(`

Agora NON crees un só exercicio: crea EXACTAMENTE %d exercicios distintos
sobre o tema indicado, variados na formulación e, cando teña sentido, en
dificultade progresiva (do máis sinxelo ao máis avanzado). Cada exercicio
segue tendo a mesma forma descrita enriba (un array de anacos "type"/
"content").

Devolve SÓ un array JSON de %d elementos, onde cada elemento é o array de
anacos dun exercicio (é dicir, un array de arrays). Sen texto adicional, sen
explicacións, sen valados markdown.

Exemplo de resposta completa e correcta para 2 exercicios sobre "derivadas":
[[{"type":"text","content":"Calcula a derivada de f(x) = x^2 + 3x - 2."},{"type":"formula","content":"diff(x^2+3*x-2,x)"}],[{"type":"text","content":"Calcula a derivada de g(x) = sin(x)*x."},{"type":"formula","content":"diff(sin(x)*x,x)"}]]`, numExercicios, numExercicios)
}

// instrucionModelosPDF engádese a systemPromptExame só cando o profesorado
// xuntou algún PDF modelo (ver textoDeModelosPDF, pdftext.go): deixa claro
// que hai que crear unha OBRA DERIVADA (mesmo tema/formato/dificultade),
// nunca copiar literalmente o texto do documento orixinal.
const instrucionModelosPDF = `

Xúntase a continuación o texto extraído dun ou varios documentos PDF que o
profesorado marcou coma MODELO/referencia (despois do separador "---
DOCUMENTO(S) MODELO ---" na petición do usuario). Úsaos para collerlles o
tema, o formato, o estilo de enunciado e o nivel de dificultade, pero NON
copies literalmente os seus enunciados nin os seus valores numéricos: crea
unha obra DERIVADA - exercicios novos, inspirados nese modelo (mesmo tipo de
pregunta, dificultade semellante), nunca idénticos nin unha simple
paráfrase. Se o profesorado tamén escribiu un tema á parte, combina os dous;
se non escribiu ningún tema, deriva ti o tema a partir do(s) documento(s).`

// ExercicioAnaco é un anaco do exercicio que devolve XerarExercicioIA -
// mesma forma que un elemento de blocks-serialize.js (type/content), listo
// para makeElement(a.Type, a.Content) no frontend.
type ExercicioAnaco struct {
	Type    string `json:"type"`
	Content string `json:"content"`
}

// limparValadosMarkdown quita un posible cerco ```...``` que a IA engada
// malia que llo pedimos explicitamente que non o faga.
func limparValadosMarkdown(texto string) string {
	t := strings.TrimSpace(texto)
	if strings.HasPrefix(t, "```") {
		primeiraLiña := strings.IndexByte(t, '\n')
		if primeiraLiña != -1 {
			t = t[primeiraLiña+1:]
		}
		t = strings.TrimSuffix(strings.TrimSpace(t), "```")
	}
	return strings.TrimSpace(t)
}
