package main

import (
	"context"
	"encoding/base64"
	"os"
	"strings"
	"testing"
)

// TEMP: check the new 1º ESO exam file compiles cleanly in both HTML and PDF.
func TestExamCheck(t *testing.T) {
	a := &App{}
	a.startup(context.Background())
	if strings.TrimSpace(a.maximaPath) == "" {
		t.Skip("needs maxima")
	}
	src, err := os.ReadFile("/home/usuario/Descargas/exame-1eso-matematicas.matex")
	if err != nil {
		t.Fatal(err)
	}

	t.Run("HTML", func(t *testing.T) {
		result, err := a.Generate(GenerateRequest{Source: string(src), Seed: 3, Iterations: 2})
		if err != nil {
			t.Fatalf("Generate failed: %v", err)
		}
		if len(result.Warnings) > 0 {
			t.Logf("warnings: %v", result.Warnings)
		}
		if strings.Contains(result.HTML, "background-color:#fdd") {
			t.Errorf("an error was captured inline in the HTML output - check the log")
		}
		out := t.TempDir() + "/exam-check.html"
		os.WriteFile(out, []byte(result.HTML), 0o644)
		t.Logf("saved to %s (%d bytes)", out, len(result.HTML))
	})

	if !commandExists("pdflatex") {
		t.Skip("needs pdflatex")
	}
	t.Run("PDF", func(t *testing.T) {
		result, err := a.GeneratePDF(GeneratePDFRequest{Source: string(src), Seed: 3, Iterations: 1})
		if err != nil {
			t.Fatalf("GeneratePDF failed: %v\nlog:\n%s", err, result.Log)
		}
		if len(result.Warnings) > 0 {
			t.Logf("warnings: %v", result.Warnings)
		}
		pdf, _ := base64.StdEncoding.DecodeString(result.PDFBase64)
		out := t.TempDir() + "/exam-check.pdf"
		if err := os.WriteFile(out, pdf, 0o644); err != nil {
			t.Fatal(err)
		}
		t.Logf("saved to %s (%d bytes)", out, len(pdf))
	})
}
