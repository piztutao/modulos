package main

import (
	"embed"

	"github.com/wailsapp/wails/v3/pkg/application"
)

//go:embed all:frontend/dist
var assets embed.FS

//go:embed build/linux/icon.png
var appIcon []byte

// nomeXanelaEditor é o Name da xanela principal. A de resultado
// (nomeXanelaResultado, xanelaresultado.go) créase baixo demanda.
const nomeXanelaEditor = "editor"

func main() {
	app := NewApp()

	wailsApp := application.New(application.Options{
		Name:        "Yang",
		Description: "Editor de exames de Yang (matemáticas, Maxima + LaTeX)",
		Services: []application.Service{
			application.NewService(app),
		},
		Assets: application.AssetOptions{
			Handler: application.AssetFileServerFS(assets),
		},
		Icon: appIcon,
		Linux: application.LinuxOptions{
			ProgramName: "Yang",
		},
		// pecharXanelaResultado xa non fai falla en OnShutdown coma en v2
		// (era para matar o PROCESO fillo do modo dúas xanelas - agora a
		// xanela de resultado é só outra fiestra do MESMO proceso, morre
		// soa cando o proceso remata).
	})

	// Xanela principal ("editor") - maximizada dende o arranque, coma Tao
	// (Yang lánzase substituíndo a Piztu, non coma unha xanela máis a carón
	// dela - ver o Ctrl+clic en piztu/frontend/src/main.js).
	wailsApp.Window.NewWithOptions(application.WebviewWindowOptions{
		Name:             nomeXanelaEditor,
		Title:            "Yang",
		Width:            1024,
		Height:           768,
		StartState:       application.WindowStateMaximised,
		BackgroundColour: application.NewRGB(23, 24, 28),
		URL:              "/",
	})

	if err := wailsApp.Run(); err != nil {
		println("Error:", err.Error())
	}
}
