package main

import (
	"context"
	"encoding/json"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Cliente da API local de Tao (docs/api-tao.md). Pancho a consulta, cando está
// dispoñible, para resolver o nome e apelidos COMPLETOS do alumnado a partir do
// username que xa lle deu File Browser (dixitalizacion/sesions/*.json) — en vez de
// confiar cegamente no "nome" que esa sesión publicou, que pode caer no propio
// username cando Tao aínda non coñecía o nome real do alumno nese equipo no
// intre de publicala (ver tao/filebrowser.go, publicarSesion). É exactamente o bug
// que motivou isto: o informe amosaba o mesmo valor en Usuario e en Nome.
//
// É UN consumidor máis do mecanismo XERAL de descubrimento (docs/api-tao.md §2),
// distinto do pipe efémero Tao→Yang (yang/taoclient.go, variable TAO_CONTEXTO) —
// aquel é dun só uso, atado a un lanzamento concreto; este busca "hai un Tao con
// sesión de profesor/admin activa nesta mesma máquina" e, se o hai, aprovéitao.
//
// Sempre opcional e sempre asíncrono/con teito curto (ver taoTimeout e
// resolverNomesTao en informe.go): se Tao non está en marcha, non ten sesión de rol
// activa, ou tarda de máis, o informe xérase igual coa mesma info que tiña antes —
// esta consulta só pode MELLORAR unha fila, nunca facer fallar o informe.

// contextoDescubrimentoTao é o contido de tao-api.json (docs/api-tao.md §2).
type contextoDescubrimentoTao struct {
	Version string `json:"version"`
	Socket  string `json:"socket"`
	Token   string `json:"token"`
}

// localizarAPITao busca tao-api.json no mesmo dataDir que usa Tao
// (os.UserConfigDir()/dixitalizacion/tao-api.json — ver tao/app.go). ok=false cando
// Tao non está en marcha (ficheiro ausente, borrado en shutdown()) ou o contexto
// está incompleto.
func localizarAPITao() (contextoDescubrimentoTao, bool) {
	var ctx contextoDescubrimentoTao
	base, err := os.UserConfigDir()
	if err != nil {
		return ctx, false
	}
	ruta := filepath.Join(base, "dixitalizacion", "tao-api.json")
	dados, err := os.ReadFile(ruta)
	if err != nil {
		return ctx, false
	}
	if err := json.Unmarshal(dados, &ctx); err != nil {
		return ctx, false
	}
	if ctx.Socket == "" || ctx.Token == "" {
		return ctx, false
	}
	return ctx, true
}

// taoTimeout é o teito de cada chamada individual a Tao: é un socket Unix na MESMA
// máquina, así que uns segundos abondan de sobra para calquera resposta lexítima —
// un teito curto é o que garante que un Tao esgotado/sen resposta nunca bloquee a
// xeración do informe máis aló deste tempo (ver resolverNomesTao en informe.go).
const taoTimeout = 3 * time.Second

// clienteTao fala coa API local de Tao sobre o seu socket Unix. baseURL é
// "http://tao" (calquera valor abonda: DialContext ignora host/porto e conecta
// sempre ao socket) agás nos tests, que a apuntan a un httptest.Server real.
type clienteTao struct {
	http    *http.Client
	token   string
	baseURL string
}

// novoClienteTao constrúe un cliente se hai un Tao en marcha con API dispoñible
// nesta máquina; ok=false se non (Tao pechado, ou executándose noutra máquina —
// esta API nunca sae do socket local, ver docs/api-tao.md §3).
func novoClienteTao() (*clienteTao, bool) {
	ctx, ok := localizarAPITao()
	if !ok {
		return nil, false
	}
	socket := ctx.Socket
	return &clienteTao{
		token:   ctx.Token,
		baseURL: "http://tao",
		http: &http.Client{
			Timeout: taoTimeout,
			Transport: &http.Transport{
				DialContext: func(dialCtx context.Context, _, _ string) (net.Conn, error) {
					var d net.Dialer
					return d.DialContext(dialCtx, "unix", socket)
				},
			},
		},
	}, true
}

// respostaUsuarioTao é a resposta de GET /api/v1/usuarios/{username}.
type respostaUsuarioTao struct {
	Username string `json:"username"`
	Name     string `json:"name"`
	Surname  string `json:"surname"`
}

// Usuario resolve o nome e apelidos completos de username a través de Tao.
// ok=false para calquera cousa que non sexa unha resposta 200 con nome non baleiro
// (sen sesión de rol activa en Tao, usuario non atopado, erro de rede, timeout
// vencido...) — o chamador (resolverNomesTao, informe.go) trata todo "non ok" coma
// "sen dato extra", nunca coma un erro que rompa o informe.
func (c *clienteTao) Usuario(ctx context.Context, username string) (nome string, ok bool) {
	endpoint := c.baseURL + "/api/v1/usuarios/" + url.PathEscape(username)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return "", false
	}
	req.Header.Set("Authorization", "Bearer "+c.token)

	res, err := c.http.Do(req)
	if err != nil {
		return "", false
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return "", false
	}
	var resp respostaUsuarioTao
	if err := json.NewDecoder(res.Body).Decode(&resp); err != nil {
		return "", false
	}
	nome = strings.TrimSpace(strings.TrimSpace(resp.Name) + " " + strings.TrimSpace(resp.Surname))
	if nome == "" {
		return "", false
	}
	return nome, true
}
