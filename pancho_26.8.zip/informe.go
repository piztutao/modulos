package main

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/go-pdf/fpdf"
	"github.com/wailsapp/wails/v2/pkg/runtime"
)

// sesionBruta é o ficheiro que Tao publica en
// dixitalizacion/sesions/<equipo>.json (mesmo contrato JSON que
// piztu/internal/tao.sesionBruta e tao/filebrowser.go's sesionTao) — non
// se importa dende alí porque internal/tao é un paquete interno de
// piztu, inaccesible fóra do seu módulo Go, e porque Pancho lese
// directamente de File Browser en vez de pasar pola API de módulos (ver
// contexto.go).
type sesionBruta struct {
	Equipo      string `json:"equipo"`
	Usuario     string `json:"usuario"`
	Nome        string `json:"nome"`
	Conectado   bool   `json:"conectado"`
	Actualizado string `json:"actualizado"`
}

// CredenciaisFB son as credenciais que o profesor escribe cada vez que fan
// falla — nunca se gardan (ver Settings en settings.go).
type CredenciaisFB struct {
	ServidorURL string `json:"servidorURL"`
	Usuario     string `json:"usuario"`
	Contrasinal string `json:"contrasinal"`
}

// InformeRow é unha fila do informe — tanto na previsualización editable da
// UI coma na táboa do PDF final (que se xera a partir destas mesmas filas,
// xa editadas/eliminadas polo profesor: ver XerarPDF).
type InformeRow struct {
	Equipo    string `json:"equipo"`
	IP        string `json:"ip"`
	Usuario   string `json:"usuario"`
	Nome      string `json:"nome"`
	Conectado bool   `json:"conectado"`
}

// InformeResult é o que XerarPDF devolve á UI: o PDF xa feito, en base64,
// para ofrecer gardalo local sen ter que ir buscalo ao disco (mesmo patrón
// que GeneratePDFResult en yang/latexdoc.go).
type InformeResult struct {
	PDFBase64    string `json:"pdfBase64"`
	NomeSuxerido string `json:"nomeSuxerido"`
	XeradoEn     string `json:"xeradoEn"`
}

// ObterFilas conéctase a File Browser coas credenciais dadas e le quen está
// a usar cada equipo (dixitalizacion/sesions/*.json, o mesmo dato que xa
// amosa o mapa de Piztu). Devolve unha fila por cada equipo do inventario
// de Piztu (a.contexto.Equipos) — nin equipos alleos á aula nin o propio
// servidor de File Browser aparecen aquí, aínda que teñan ficheiro de
// sesión — para que o profesor as revise, edite ou elimine na UI antes de
// que XerarPDF converta o resultado en PDF.
func (a *App) ObterFilas(cred CredenciaisFB) ([]InformeRow, error) {
	base := normalizeServerURL(cred.ServidorURL)
	if base == "" {
		return nil, fmt.Errorf("escribe o enderezo do servidor de File Browser")
	}
	a.lembrarServidor(base)
	if strings.TrimSpace(cred.Usuario) == "" || cred.Contrasinal == "" {
		return nil, fmt.Errorf("escribe o usuario e o contrasinal do servidor")
	}

	token, err := fbLogin(base, cred.Usuario, cred.Contrasinal)
	if err != nil {
		return nil, err
	}

	sesions, err := lerSesions(base, token)
	if err != nil {
		return nil, err
	}

	return construirFilas(a.contexto.Equipos, sesions), nil
}

// lembrarServidor garda o enderezo do servidor (nunca as credenciais) para
// prerrechear a próxima vez que se abra o formulario — chámase en canto se
// escribe un enderezo válido, ANTES de intentar o login, así se o profesor
// escribe ben o servidor pero falla o usuario/contrasinal (ou o propio
// servidor está caído), a próxima vez non ten que volver escribir o
// enderezo, só corrixir o que fallou.
func (a *App) lembrarServidor(base string) {
	if a.settings.ServidorURL == base {
		return
	}
	a.settings.ServidorURL = base
	_ = saveSettingsToDisk(a.settings)
}

// XerarPDF constrúe o PDF a partir das filas que manda a UI — xa coas
// edicións/eliminacións que fixese o profesor sobre o que devolveu
// ObterFilas, non se volve ler nada de File Browser aquí. O PDF queda en
// memoria (a.ultimoPDF) para GardarInformeLocal/SubirInforme; non se
// escribe nada en disco nesta chamada.
func (a *App) XerarPDF(filas []InformeRow) (InformeResult, error) {
	if len(filas) == 0 {
		return InformeResult{}, fmt.Errorf("non hai filas que xerar")
	}
	agora := time.Now()
	a.ultimoPDF = construirPDF(filas, agora)
	a.ultimoNome = nomeInforme(agora)

	return InformeResult{
		PDFBase64:    base64.StdEncoding.EncodeToString(a.ultimoPDF),
		NomeSuxerido: a.ultimoNome,
		XeradoEn:     agora.Format("02/01/2006 15:04"),
	}, nil
}

// GardarInformeLocal amosa un diálogo "Gardar como" e escribe o último
// informe xerado. Non precisa credenciais: escribe no disco local, non en
// File Browser.
func (a *App) GardarInformeLocal() (string, error) {
	if len(a.ultimoPDF) == 0 {
		return "", fmt.Errorf("xera un informe antes de gardalo")
	}
	path, err := runtime.SaveFileDialog(a.ctx, runtime.SaveDialogOptions{
		Title:           "Gardar informe",
		DefaultFilename: a.ultimoNome,
		Filters:         []runtime.FileFilter{{DisplayName: "PDF (*.pdf)", Pattern: "*.pdf"}},
	})
	if err != nil || path == "" {
		return "", err
	}
	if err := os.WriteFile(path, a.ultimoPDF, 0o644); err != nil {
		return "", err
	}
	return path, nil
}

// SubirInforme sobe o último informe xerado a File Browser
// (pancho/<nomeSuxerido>), coas credenciais que o profesor escriba
// nese intre — sempre unhas novas, nunca as usadas para xerar as filas
// (que puideron quedar obsoletas, e porque subir require permiso de
// escritura, non só lectura).
func (a *App) SubirInforme(cred CredenciaisFB) (string, error) {
	if len(a.ultimoPDF) == 0 {
		return "", fmt.Errorf("xera un informe antes de subilo")
	}
	base := normalizeServerURL(cred.ServidorURL)
	if base == "" {
		return "", fmt.Errorf("escribe o enderezo do servidor de File Browser")
	}
	a.lembrarServidor(base)
	if strings.TrimSpace(cred.Usuario) == "" || cred.Contrasinal == "" {
		return "", fmt.Errorf("escribe o usuario e o contrasinal do servidor")
	}

	token, err := fbLogin(base, cred.Usuario, cred.Contrasinal)
	if err != nil {
		return "", err
	}
	if err := fbEnsureDir(base, token, fbInformesDir); err != nil {
		return "", err
	}
	remotePath := fbInformesDir + "/" + a.ultimoNome
	if err := fbUpload(base, token, remotePath, a.ultimoPDF); err != nil {
		return "", err
	}
	return remotePath, nil
}

// lerSesions le todos os ficheiros de dixitalizacion/sesions/*.json e
// devolve {equipo: sesionBruta}. Tolerante: un ficheiro individual
// corrompido ou ilexible sáltase sen afectar aos demais (mesmo criterio ca
// internal/tao.Listar en piztu) — un cartafol de sesións aínda
// inexistente (aula sen ningún alumno conectado nunca) devolve un mapa
// baleiro, non un erro.
func lerSesions(base, token string) (map[string]sesionBruta, error) {
	itens, err := fbList(base, token, fbSesionsDir)
	if err != nil {
		return nil, err
	}
	resultado := map[string]sesionBruta{}
	for _, it := range itens {
		if it.IsDir || !strings.HasSuffix(it.Name, ".json") {
			continue
		}
		raw, err := fbRawGet(base, token, fbSesionsDir+"/"+it.Name)
		if err != nil {
			continue
		}
		var s sesionBruta
		if err := json.Unmarshal(raw, &s); err != nil {
			continue
		}
		equipo := s.Equipo
		if equipo == "" {
			equipo = strings.TrimSuffix(it.Name, ".json")
		}
		resultado[equipo] = s
	}
	return resultado, nil
}

// nomeBase quita o sufixo de dominio dun nome de equipo ("bac01.local" →
// "bac01"). Tao publica a sesión co hostname curto que ve o propio cliente,
// mentres que o inventario de Piztu (hosts) adoita levar o FQDN — sen isto
// "bac01" e "bac01.local" casaban coma equipos DISTINTOS: o do inventario
// quedaba sempre "sen sesión" e o de Tao aparecía coma unha fila extra,
// allea ao inventario, que ObterFilas xa non amosa (ver construirFilas).
func nomeBase(equipo string) string {
	if i := strings.IndexByte(equipo, '.'); i >= 0 {
		return equipo[:i]
	}
	return equipo
}

// construirFilas devolve UNHA fila por cada equipo do inventario de Piztu
// (a.contexto.Equipos), ordenadas por nome — nunca máis, nunca menos: nin
// equipos que só existan no cartafol de sesións (outra máquina da rede, o
// propio servidor de File Browser publicando de proba, un equipo xa dado
// de baixa) nin equipos repetidos por mor do sufixo de dominio (ver
// nomeBase). O IP e o nome completo (via Tao, ver resolverNomesTao) resólvense
// en paralelo.
func construirFilas(equipos []EquipoContexto, sesions map[string]sesionBruta) []InformeRow {
	// tao pode ser nil (Tao non está en marcha nesta máquina, ou non ten sesión de
	// rol activa): resolverNomesTao trátao coma "sen mellora dispoñible", nunca
	// coma un erro — ver taoclient.go.
	tao, _ := novoClienteTao()
	return construirFilasCon(equipos, sesions, tao)
}

// construirFilasCon fai o traballo real, co cliente de Tao xa resolto — á parte de
// construirFilas para poder testar sen depender de se a máquina que executa os
// tests ten ou non un Tao real en marcha (ver informe_test.go).
func construirFilasCon(equipos []EquipoContexto, sesions map[string]sesionBruta, tao *clienteTao) []InformeRow {
	porBase := map[string]sesionBruta{}
	for equipo, s := range sesions {
		porBase[nomeBase(equipo)] = s
	}

	ordenados := make([]EquipoContexto, len(equipos))
	copy(ordenados, equipos)
	sort.Slice(ordenados, func(i, j int) bool { return ordenados[i].Nome < ordenados[j].Nome })

	arp := lerTaboaARP()

	filas := make([]InformeRow, len(ordenados))
	var wg sync.WaitGroup
	for i, e := range ordenados {
		fila := InformeRow{Equipo: e.Nome}
		if s, ok := porBase[nomeBase(e.Nome)]; ok {
			fila.Usuario = s.Usuario
			fila.Nome = s.Nome
			fila.Conectado = s.Conectado
		}
		filas[i] = fila

		wg.Add(1)
		go func(i int, nome, mac string) {
			defer wg.Done()
			filas[i].IP = resolverIP(nome, mac, arp)
		}(i, e.Nome, e.Mac)

		if tao != nil && filas[i].Usuario != "" {
			wg.Add(1)
			go func(i int, usuario string) {
				defer wg.Done()
				resolverNomeTao(tao, &filas[i], usuario)
			}(i, filas[i].Usuario)
		}
	}
	wg.Wait()
	return filas
}

// resolverNomeTao substitúe fila.Nome polo nome e apelidos completos que devolva
// Tao (fonte autoritativa: roster compartido ou profiles.json local, ver
// tao/api_handlers.go handleUsuario) cando está dispoñible. Se Tao non responde a
// tempo, non recoñece ese usuario, ou simplemente non está en marcha, fila.Nome
// queda co que xa tiña (o "nome" publicado pola propia sesión — que pode ser só o
// username repetido, o bug real que motivou esta consulta). Nunca bloquea máis do
// teito de taoTimeout.
func resolverNomeTao(tao *clienteTao, fila *InformeRow, usuario string) {
	ctx, cancel := context.WithTimeout(context.Background(), taoTimeout)
	defer cancel()
	if nome, ok := tao.Usuario(ctx, usuario); ok {
		fila.Nome = nome
	}
}

// resolverIP busca a IP dun equipo, MAC primeiro: Piztu xa coñece a MAC de
// cada equipo (ficheiro hosts, EquipoContexto.Mac) e o seu propio monitor
// de acendido (piztu/internal/ping) fai ping periódico a todos os
// equipos, o que dá de bald a táboa ARP do sistema quente — abonda con
// lela (ver lerTaboaARP), sen resolver nada por rede aquí.
//
// Fallback a DNS/hosts (net.LookupHost) só se non hai MAC ou non está na
// táboa ARP (equipo recén engadido, ou sen tráfico aínda dende esta
// máquina) — funciona para hostnames "normais", pero NON para ".local"
// (mDNS): o resolvedor Go puro non fai mDNS, a diferenza do comando
// `ping` do sistema que usa internal/ping (por iso a IP podía faltar
// aínda cando o mapa xa amosaba o equipo acendido).
func resolverIP(equipo, mac string, arp map[string]string) string {
	if ip, ok := arp[strings.ToLower(strings.TrimSpace(mac))]; ok && ip != "" {
		return ip
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	ips, err := net.DefaultResolver.LookupHost(ctx, equipo)
	if err != nil || len(ips) == 0 {
		return ""
	}
	return ips[0]
}

// lerTaboaARP le /proc/net/arp (Linux) e devolve {mac_en_minusculas: ip}.
// Formato de exemplo (primeira liña é cabeceira, ignorada):
//
//	IP address       HW type     Flags       HW address            Mask     Device
//	192.168.1.23     0x1         0x2         64:4e:d7:c3:e2:cf     *        eth0
//
// Tolerante: nun sistema sen /proc/net/arp (non-Linux) ou con formato
// inesperado devolve un mapa baleiro, non un erro — resolverIP cae ao
// fallback de DNS igualmente.
func lerTaboaARP() map[string]string {
	data, err := os.ReadFile("/proc/net/arp")
	if err != nil {
		return map[string]string{}
	}
	return parsearTaboaARP(string(data))
}

// parsearTaboaARP fai o parseo en si (separado de lerTaboaARP para poder
// testalo sen tocar /proc/net/arp, que é do kernel).
func parsearTaboaARP(contido string) map[string]string {
	resultado := map[string]string{}
	liñas := strings.Split(contido, "\n")
	if len(liñas) > 0 {
		liñas = liñas[1:] // cabeceira
	}
	for _, liña := range liñas {
		campos := strings.Fields(liña)
		if len(campos) < 4 {
			continue
		}
		ip, mac := campos[0], strings.ToLower(campos[3])
		if mac == "" || mac == "00:00:00:00:00:00" {
			continue // entrada incompleta, aínda sen resolver
		}
		resultado[mac] = ip
	}
	return resultado
}

func nomeInforme(t time.Time) string {
	return "informe-" + t.Format("2006-01-02-1504") + ".pdf"
}

// toLatin1 converte un string UTF-8 aos bytes cp1252/Latin-1 que esperan as
// fontes básicas de fpdf (Helvetica) — evita depender dun ficheiro externo
// "cp1252.map" (UnicodeTranslatorFromDescriptor precisaría un en disco, que
// non se distribúe co binario). Latin-1 e cp1252 coinciden exactamente nos
// puntos de código que usa o galego (áéíóúñü, maiúsculas incluídas), así
// que abonda con truncar cada rune a un byte; calquera outro carácter (fóra
// de rango) vira "?" en vez de romper a xeración do PDF.
func toLatin1(s string) string {
	runes := []rune(s)
	buf := make([]byte, len(runes))
	for i, r := range runes {
		if r > 255 {
			r = '?'
		}
		buf[i] = byte(r)
	}
	return string(buf)
}

// construirPDF debuxa a táboa Equipo/IP/Usuario/Nome, unha folla A4 en
// vertical — sen depender de LaTeX nin dun navegador embebido (ver
// decisión no deseño do módulo), só fpdf.
func construirPDF(filas []InformeRow, xeradoEn time.Time) []byte {
	pdf := fpdf.New("P", "mm", "A4", "")
	pdf.SetTitle("Informe de equipos - Pancho", false)
	pdf.SetMargins(15, 15, 15)
	pdf.AddPage()

	pdf.SetFont("Helvetica", "B", 16)
	pdf.CellFormat(0, 10, toLatin1("Informe de equipos"), "", 1, "L", false, 0, "")
	pdf.SetFont("Helvetica", "", 10)
	pdf.SetTextColor(100, 100, 100)
	pdf.CellFormat(0, 6, toLatin1("Xerado: "+xeradoEn.Format("02/01/2006 15:04")), "", 1, "L", false, 0, "")
	pdf.SetTextColor(0, 0, 0)
	pdf.Ln(4)

	const colEquipo, colIP, colUsuario, colNome = 42.0, 32.0, 45.0, 46.0
	debuxarCabeceira := func() {
		pdf.SetFont("Helvetica", "B", 11)
		pdf.SetFillColor(230, 230, 230)
		pdf.CellFormat(colEquipo, 8, toLatin1("Equipo"), "1", 0, "L", true, 0, "")
		pdf.CellFormat(colIP, 8, toLatin1("IP"), "1", 0, "L", true, 0, "")
		pdf.CellFormat(colUsuario, 8, toLatin1("Usuario"), "1", 0, "L", true, 0, "")
		pdf.CellFormat(colNome, 8, toLatin1("Nome"), "1", 1, "L", true, 0, "")
	}
	debuxarCabeceira()

	pdf.SetFont("Helvetica", "", 10)
	for _, fila := range filas {
		if pdf.GetY() > 270 { // preto do pé de páxina: folla nova con cabeceira
			pdf.AddPage()
			debuxarCabeceira()
			pdf.SetFont("Helvetica", "", 10)
		}
		usuario := fila.Usuario
		if !fila.Conectado || usuario == "" {
			usuario = "-- sen sesion --"
		}
		ip := fila.IP
		if ip == "" {
			ip = "--"
		}
		pdf.CellFormat(colEquipo, 7, toLatin1(fila.Equipo), "1", 0, "L", false, 0, "")
		pdf.CellFormat(colIP, 7, toLatin1(ip), "1", 0, "L", false, 0, "")
		pdf.CellFormat(colUsuario, 7, toLatin1(usuario), "1", 0, "L", false, 0, "")
		pdf.CellFormat(colNome, 7, toLatin1(fila.Nome), "1", 1, "L", false, 0, "")
	}

	var buf bytes.Buffer
	_ = pdf.Output(&buf)
	return buf.Bytes()
}
