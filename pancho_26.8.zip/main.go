package main

import (
	"embed"

	"github.com/wailsapp/wails/v2"
	"github.com/wailsapp/wails/v2/pkg/options"
	"github.com/wailsapp/wails/v2/pkg/options/assetserver"
	wailslinux "github.com/wailsapp/wails/v2/pkg/options/linux"
)

//go:embed all:frontend/src
var assets embed.FS

// appIcon é logo.png (o cadelo, ver DESIGN.md/README) — sen isto Wails usa
// a súa icona de gopher por defecto na barra de tarefas/selector de
// xanelas do sistema (distinto da icona do módulo na barra de Piztu, que
// xa vén de modulo.json: "iconaImaxe"). Mesmo patrón que yang/main.go.
//
//go:embed logo.png
var appIcon []byte

func main() {
	// Create an instance of the app structure
	app := NewApp()

	// Create application with options
	err := wails.Run(&options.App{
		Title: "Pancho",
		// Fallback ata que OnStartup recoloque a xanela coma columna
		// lateral dereita, do alto real da pantalla e do ancho
		// configurado en ⚙ Aula (ver App.posicionarColumna en app.go).
		Width:  anchoColumnaDefecto,
		Height: 900,
		AssetServer: &assetserver.Options{
			Assets: assets,
		},
		// Mesma escala de grises ca Piztu/Tao/Yang (ver DESIGN.md) — fondo
		// da xanela antes de que cargue o CSS, non a cor de fondo real.
		BackgroundColour: &options.RGBA{R: 245, G: 245, B: 244, A: 255},
		OnStartup:        app.startup,
		Bind: []interface{}{
			app,
		},
		Linux: &wailslinux.Options{
			Icon:        appIcon,
			ProgramName: "Pancho",
		},
	})

	if err != nil {
		println("Error:", err.Error())
	}
}
