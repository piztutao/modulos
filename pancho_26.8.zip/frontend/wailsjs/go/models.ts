export namespace main {
	
	export class CredenciaisFB {
	    servidorURL: string;
	    usuario: string;
	    contrasinal: string;
	
	    static createFrom(source: any = {}) {
	        return new CredenciaisFB(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.servidorURL = source["servidorURL"];
	        this.usuario = source["usuario"];
	        this.contrasinal = source["contrasinal"];
	    }
	}
	export class EstadoActualizacionPancho {
	    disponible: boolean;
	    versionLocal: string;
	    versionRemota: string;
	    urlDescarga: string;
	    urlChecksum: string;
	    notas: string;
	
	    static createFrom(source: any = {}) {
	        return new EstadoActualizacionPancho(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.disponible = source["disponible"];
	        this.versionLocal = source["versionLocal"];
	        this.versionRemota = source["versionRemota"];
	        this.urlDescarga = source["urlDescarga"];
	        this.urlChecksum = source["urlChecksum"];
	        this.notas = source["notas"];
	    }
	}
	export class InformeResult {
	    pdfBase64: string;
	    nomeSuxerido: string;
	    xeradoEn: string;
	
	    static createFrom(source: any = {}) {
	        return new InformeResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.pdfBase64 = source["pdfBase64"];
	        this.nomeSuxerido = source["nomeSuxerido"];
	        this.xeradoEn = source["xeradoEn"];
	    }
	}
	export class InformeRow {
	    equipo: string;
	    ip: string;
	    usuario: string;
	    nome: string;
	    conectado: boolean;
	
	    static createFrom(source: any = {}) {
	        return new InformeRow(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.equipo = source["equipo"];
	        this.ip = source["ip"];
	        this.usuario = source["usuario"];
	        this.nome = source["nome"];
	        this.conectado = source["conectado"];
	    }
	}
	export class Settings {
	    servidorURL: string;
	
	    static createFrom(source: any = {}) {
	        return new Settings(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.servidorURL = source["servidorURL"];
	    }
	}

}

