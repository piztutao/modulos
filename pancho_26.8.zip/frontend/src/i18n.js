// i18n.js — motor de tradución mínimo para Pancho.
//
// Sen bundler nin i18next (Pancho é "plain": ver a nota de main.js) — os
// textos viven en i18n/locales/{gl,es,en,pt}.js (cada un define
// window.PANCHO_I18N.<código>, cargados en index.html ANTES deste
// ficheiro). Detección: localStorage (elección explícita do profesorado
// dentro do propio Pancho) > idioma que Piztu ten escollido (GetIdioma(),
// ver contexto.go/app.go) > idioma do navegador > galego.
//
// Dous papeis:
//   1. t(clave, vars) — tradución programática, usada en main.js. vars.count
//      escolle entre "<clave>_one" e "<clave>_other" (pluralización simple,
//      mesmo criterio ca Tao/Xesta).
//   2. aplicarTraducionsEstaticas() — percorre o DOM e substitúe o texto/
//      atributo dos elementos marcados con data-i18n/data-i18n-placeholder/
//      data-i18n-title (o texto xa escrito en index.html).
;(function () {
  const CLAVE_LOCALSTORAGE = 'pancho_idioma'
  const IDIOMAS_DISPONIBLES = ['gl', 'es', 'en', 'pt']
  const FALLBACK = 'gl'

  function resolverIdiomaInicial() {
    const gardado = localStorage.getItem(CLAVE_LOCALSTORAGE)
    if (gardado && IDIOMAS_DISPONIBLES.includes(gardado)) return gardado
    const nav = (navigator.language || '').slice(0, 2).toLowerCase()
    if (IDIOMAS_DISPONIBLES.includes(nav)) return nav
    return FALLBACK
  }

  let idiomaActual = resolverIdiomaInicial()

  function dicionario(codigo) {
    return (window.PANCHO_I18N && window.PANCHO_I18N[codigo]) || {}
  }

  function buscarValor(dic, clave) {
    return clave.split('.').reduce((o, k) => (o && typeof o === 'object' ? o[k] : undefined), dic)
  }

  function interpolar(texto, vars) {
    if (!vars) return texto
    return texto.replace(/\{\{(\w+)}}/g, (_, k) => (k in vars ? String(vars[k]) : `{{${k}}}`))
  }

  function t(clave, vars) {
    let claveResolta = clave
    if (vars && typeof vars.count === 'number') {
      claveResolta = clave + (vars.count === 1 ? '_one' : '_other')
    }
    let valor = buscarValor(dicionario(idiomaActual), claveResolta)
    if (valor === undefined && idiomaActual !== FALLBACK) {
      valor = buscarValor(dicionario(FALLBACK), claveResolta)
    }
    if (valor === undefined) valor = clave // clave descoñecida: amosala tal cal, nunca baleiro
    return interpolar(valor, vars)
  }

  function aplicarTraducionsEstaticas() {
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      el.textContent = t(el.getAttribute('data-i18n'))
    })
    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      el.setAttribute('placeholder', t(el.getAttribute('data-i18n-placeholder')))
    })
    document.querySelectorAll('[data-i18n-title]').forEach((el) => {
      el.setAttribute('title', t(el.getAttribute('data-i18n-title')))
    })
  }

  // Aplícase xa, síncrono, co idioma detectado (localStorage/navegador) — o
  // caso normal (elección xa gardada, ou Pancho executado á man sen Piztu)
  // non agarda nada.
  aplicarTraducionsEstaticas()

  // Se aínda non había elección explícita, comproba en fondo se Piztu ten un
  // idioma escollido distinto e, de ser así, volve aplicar as traducións —
  // GetIdioma() é unha chamada local instantánea (non de rede), así que o
  // posible flash é imperceptible; evita complicar a orde de arranque cun
  // paso previo bloqueante só para este caso.
  //
  // window.go pode aínda non estar inxectado por Wails no instante exacto en
  // que se executa este script (sen bundler, execútase moi cedo, a
  // diferenza de Tao/Xesta) — sen reintento, esa carreira facía que Pancho
  // caese sempre no idioma do navegador/SO en vez do de Piztu. Ata 20
  // intentos de 50ms (1s de marxe) antes de renunciar.
  function intentarSeguirIdiomaPiztu(intentosRestantes) {
    if (localStorage.getItem(CLAVE_LOCALSTORAGE)) return
    if (!(window.go && window.go.main && window.go.main.App)) {
      if (intentosRestantes > 0) {
        setTimeout(() => intentarSeguirIdiomaPiztu(intentosRestantes - 1), 50)
      }
      return
    }
    window.go.main.App.GetIdioma()
      .then((idioma) => {
        if (idioma && IDIOMAS_DISPONIBLES.includes(idioma) && idioma !== idiomaActual) {
          idiomaActual = idioma
          aplicarTraducionsEstaticas()
        }
      })
      .catch(() => {
        // Sen contexto de Piztu (executable á man): queda o idioma xa detectado.
      })
  }
  intentarSeguirIdiomaPiztu(20)

  window.PanchoI18n = {t, IDIOMAS_DISPONIBLES}
})()
