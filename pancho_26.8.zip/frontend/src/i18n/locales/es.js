// es.js — textos en castelán de Pancho. Formato JS (non JSON) porque este
// módulo non ten bundler (ver frontend/src/main.js): un obxecto global é
// máis simple de cargar cun <script> normal ca facer fetch() dun .json en
// tempo de execución. Mesma estrutura de claves ca gl.js/en.js/pt.js —
// tradúcense á parte, ver i18n.js.
window.PANCHO_I18N = window.PANCHO_I18N || {}
window.PANCHO_I18N.es = {
  cabeceira: {
    titulo: 'Pancho',
  },
  boton: {
    xerarInforme: 'Generar informe',
    xerarPDF: 'Generar PDF',
    gardarComo: 'Guardar como...',
    subirFileBrowser: 'Subir a File Browser',
    cancelar: 'Cancelar',
    continuar: 'Continuar',
  },
  baleiro: {
    mensaxe: 'Genera un informe para ver aquí los equipos y quién los está usando ahora mismo, ordenados por nombre de equipo.',
  },
  taboa: {
    equipo: 'Equipo',
    ip: 'IP',
    usuario: 'Usuario',
    nome: 'Nombre',
    notaEdicion: 'Puedes editar Usuario/Nombre o eliminar filas antes de generar el PDF.',
    eliminarFila: 'Eliminar esta fila',
  },
  credenciais: {
    titulo: 'Credenciales de File Browser',
    nota: 'Se escriben cada vez que hacen falta: Pancho nunca las guarda.',
    servidor: 'Servidor',
    usuario: 'Usuario',
    contrasinal: 'Contraseña',
    obterTitulo: 'Obtener equipos',
    subirTitulo: 'Subir informe a File Browser',
  },
  estado: {
    conectando: 'Conectando con File Browser...',
    equiposAtopados_one: '{{count}} equipo encontrado. Revisa la tabla y genera el PDF.',
    equiposAtopados_other: '{{count}} equipos encontrados. Revisa la tabla y genera el PDF.',
    senFilas: 'No hay filas que generar',
    xerandoPDF: 'Generando PDF...',
    pdfXeradoAs: 'PDF generado a las {{hora}}',
    subindo: 'Subiendo a File Browser...',
    subidoA: 'Subido a {{ruta}}',
    gardando: 'Guardando...',
    gardadoEn: 'Guardado: {{ruta}}',
    senGardar: 'sin guardar',
  },
  resumo: {
    equipos_one: '{{count}} equipo',
    equipos_other: '{{count}} equipos',
  },
  sobre: {
    titulo: 'Acerca de Pancho',
    btn: 'Acerca de Pancho',
    version: 'Versión',
    novaversion: 'Nueva versión disponible: {{v}}',
    actualizar: '⟳ Actualizar',
    actualizando: 'Actualizando...',
    actualizarConfirmar: 'Esto va a reiniciar Pancho para aplicar la actualización. ¿Continuar?',
    autor: 'Autor: Martín Pardiñas',
    contacto: 'Contacto: piztu@omeu.gal',
    licenza: 'Licencia GNU General Public License v3 (GPLv3)',
    licdesc: 'Software libre: se puede usar, estudiar, modificar y redistribuir libremente. Cualquier trabajo derivado que se redistribuya tiene que publicarse también bajo GPLv3, con el código fuente disponible (copyleft). Texto completo en el fichero LICENSE.',
    pechar: 'Cerrar',
  },
}
