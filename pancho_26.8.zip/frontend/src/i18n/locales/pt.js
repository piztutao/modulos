// pt.js — textos en portugués de Pancho. Formato JS (non JSON) porque este
// módulo non ten bundler (ver frontend/src/main.js): un obxecto global é
// máis simple de cargar cun <script> normal ca facer fetch() dun .json en
// tempo de execución. Mesma estrutura de claves ca gl.js/es.js/en.js —
// tradúcense á parte, ver i18n.js.
window.PANCHO_I18N = window.PANCHO_I18N || {}
window.PANCHO_I18N.pt = {
  cabeceira: {
    titulo: 'Pancho',
  },
  boton: {
    xerarInforme: 'Gerar relatório',
    xerarPDF: 'Gerar PDF',
    gardarComo: 'Guardar como...',
    subirFileBrowser: 'Enviar para o File Browser',
    cancelar: 'Cancelar',
    continuar: 'Continuar',
  },
  baleiro: {
    mensaxe: 'Gera um relatório para ver aqui os equipamentos e quem os está a usar agora mesmo, ordenados por nome de equipamento.',
  },
  taboa: {
    equipo: 'Equipamento',
    ip: 'IP',
    usuario: 'Utilizador',
    nome: 'Nome',
    notaEdicion: 'Podes editar Utilizador/Nome ou eliminar linhas antes de gerar o PDF.',
    eliminarFila: 'Eliminar esta linha',
  },
  credenciais: {
    titulo: 'Credenciais do File Browser',
    nota: 'Escrevem-se sempre que são precisas: o Pancho nunca as guarda.',
    servidor: 'Servidor',
    usuario: 'Utilizador',
    contrasinal: 'Palavra-passe',
    obterTitulo: 'Obter equipamentos',
    subirTitulo: 'Enviar relatório para o File Browser',
  },
  estado: {
    conectando: 'A ligar ao File Browser...',
    equiposAtopados_one: '{{count}} equipamento encontrado. Revê a tabela e gera o PDF.',
    equiposAtopados_other: '{{count}} equipamentos encontrados. Revê a tabela e gera o PDF.',
    senFilas: 'Não há linhas para gerar',
    xerandoPDF: 'A gerar PDF...',
    pdfXeradoAs: 'PDF gerado às {{hora}}',
    subindo: 'A enviar para o File Browser...',
    subidoA: 'Enviado para {{ruta}}',
    gardando: 'A guardar...',
    gardadoEn: 'Guardado: {{ruta}}',
    senGardar: 'não guardado',
  },
  resumo: {
    equipos_one: '{{count}} equipamento',
    equipos_other: '{{count}} equipamentos',
  },
  sobre: {
    titulo: 'Sobre o Pancho',
    btn: 'Sobre o Pancho',
    version: 'Versão',
    novaversion: 'Nova versão disponível: {{v}}',
    actualizar: '⟳ Atualizar',
    actualizando: 'Atualizando...',
    actualizarConfirmar: 'Isto vai reiniciar o Pancho para aplicar a atualização. Continuar?',
    autor: 'Autor: Martín Pardiñas',
    contacto: 'Contacto: piztu@omeu.gal',
    licenza: 'Licença GNU General Public License v3 (GPLv3)',
    licdesc: 'Software livre: pode ser usado, estudado, modificado e redistribuído livremente. Qualquer trabalho derivado que seja redistribuído tem de ser publicado também sob GPLv3, com o código-fonte disponível (copyleft). Texto completo no ficheiro LICENSE.',
    pechar: 'Fechar',
  },
}
