// en.js — English texts for Pancho. JS format (not JSON) because this
// módulo has no bundler (see frontend/src/main.js): a global object is
// simpler to load with a plain <script> than doing fetch() on a .json at
// runtime. Same key structure as gl.js/es.js/pt.js — translated
// separately, see i18n.js.
window.PANCHO_I18N = window.PANCHO_I18N || {}
window.PANCHO_I18N.en = {
  cabeceira: {
    titulo: 'Pancho',
  },
  boton: {
    xerarInforme: 'Generate report',
    xerarPDF: 'Generate PDF',
    gardarComo: 'Save as...',
    subirFileBrowser: 'Upload to File Browser',
    cancelar: 'Cancel',
    continuar: 'Continue',
  },
  baleiro: {
    mensaxe: 'Generate a report to see here the computers and who is using them right now, sorted by computer name.',
  },
  taboa: {
    equipo: 'Computer',
    ip: 'IP',
    usuario: 'User',
    nome: 'Name',
    notaEdicion: 'You can edit User/Name or delete rows before generating the PDF.',
    eliminarFila: 'Delete this row',
  },
  credenciais: {
    titulo: 'File Browser credentials',
    nota: 'Entered every time they are needed: Pancho never saves them.',
    servidor: 'Server',
    usuario: 'User',
    contrasinal: 'Password',
    obterTitulo: 'Get computers',
    subirTitulo: 'Upload report to File Browser',
  },
  estado: {
    conectando: 'Connecting to File Browser...',
    equiposAtopados_one: '{{count}} computer found. Check the table and generate the PDF.',
    equiposAtopados_other: '{{count}} computers found. Check the table and generate the PDF.',
    senFilas: 'No rows to generate',
    xerandoPDF: 'Generating PDF...',
    pdfXeradoAs: 'PDF generated at {{hora}}',
    subindo: 'Uploading to File Browser...',
    subidoA: 'Uploaded to {{ruta}}',
    gardando: 'Saving...',
    gardadoEn: 'Saved: {{ruta}}',
    senGardar: 'not saved',
  },
  resumo: {
    equipos_one: '{{count}} computer',
    equipos_other: '{{count}} computers',
  },
  sobre: {
    titulo: 'About Pancho',
    btn: 'About Pancho',
    version: 'Version',
    novaversion: 'New version available: {{v}}',
    actualizar: '⟳ Update',
    actualizando: 'Updating...',
    actualizarConfirmar: 'This will restart Pancho to apply the update. Continue?',
    autor: 'Author: Martín Pardiñas',
    contacto: 'Contact: piztu@omeu.gal',
    licenza: 'GNU General Public License v3 (GPLv3)',
    licdesc: 'Free software: it can be used, studied, modified and redistributed freely. Any derivative work that gets redistributed must also be published under GPLv3, with the source code available (copyleft). Full text in the LICENSE file.',
    pechar: 'Close',
  },
}
