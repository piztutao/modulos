// gl.js — textos en galego de Pancho. Formato JS (non JSON) porque este
// módulo non ten bundler (ver frontend/src/main.js): un obxecto global é
// máis simple de cargar cun <script> normal ca facer fetch() dun .json en
// tempo de execución. Mesma estrutura de claves ca es.js/en.js/pt.js —
// tradúcense á parte, ver i18n.js.
window.PANCHO_I18N = window.PANCHO_I18N || {}
window.PANCHO_I18N.gl = {
  cabeceira: {
    titulo: 'Pancho',
  },
  boton: {
    xerarInforme: 'Xerar informe',
    xerarPDF: 'Xerar PDF',
    gardarComo: 'Gardar como...',
    subirFileBrowser: 'Subir a File Browser',
    cancelar: 'Cancelar',
    continuar: 'Continuar',
  },
  baleiro: {
    mensaxe: 'Xera un informe para ver aquí os equipos e quen os está a usar agora mesmo, ordenados por nome de equipo.',
  },
  taboa: {
    equipo: 'Equipo',
    ip: 'IP',
    usuario: 'Usuario',
    nome: 'Nome',
    notaEdicion: 'Podes editar Usuario/Nome ou eliminar filas antes de xerar o PDF.',
    eliminarFila: 'Eliminar esta fila',
  },
  credenciais: {
    titulo: 'Credenciais de File Browser',
    nota: 'Escríbense cada vez que fan falla: Pancho nunca as garda.',
    servidor: 'Servidor',
    usuario: 'Usuario',
    contrasinal: 'Contrasinal',
    obterTitulo: 'Obter equipos',
    subirTitulo: 'Subir informe a File Browser',
  },
  estado: {
    conectando: 'Conectando con File Browser...',
    equiposAtopados_one: '{{count}} equipo atopado. Revisa a táboa e xera o PDF.',
    equiposAtopados_other: '{{count}} equipos atopados. Revisa a táboa e xera o PDF.',
    senFilas: 'Non hai filas que xerar',
    xerandoPDF: 'Xerando PDF...',
    pdfXeradoAs: 'PDF xerado ás {{hora}}',
    subindo: 'Subindo a File Browser...',
    subidoA: 'Subido a {{ruta}}',
    gardando: 'Gardando...',
    gardadoEn: 'Gardado: {{ruta}}',
    senGardar: 'sen gardar',
  },
  resumo: {
    equipos_one: '{{count}} equipo',
    equipos_other: '{{count}} equipos',
  },
  sobre: {
    titulo: 'Sobre Pancho',
    btn: 'Sobre Pancho',
    version: 'Versión',
    novaversion: 'Nova versión dispoñible: {{v}}',
    actualizar: '⟳ Actualizar',
    actualizando: 'Actualizando...',
    actualizarConfirmar: 'Isto vai reiniciar Pancho para aplicar a actualización. ¿Continuar?',
    autor: 'Autor: Martín Pardiñas',
    contacto: 'Contacto: piztu@omeu.gal',
    licenza: 'Licenza GNU General Public License v3 (GPLv3)',
    licdesc: 'Software libre: pódese usar, estudar, modificar e redistribuír libremente. Calquera traballo derivado que se redistribúa ten que publicarse tamén baixo GPLv3, co código fonte dispoñible (copyleft). Texto completo no ficheiro LICENSE.',
    pechar: 'Pechar',
  },
}
