// Pancho: sen bundler nin bindings xerados a propósito (módulo "plain"
// de Wails, ver wails.json) — os métodos de App están sempre en
// window.go.main.App.* en tempo de execución, non fai falla importar nada
// (mesmo obxecto que usarían os ficheiros xerados en frontend/wailsjs/go/
// noutros módulos coma Yang).
const App = () => window.go.main.App
const t = (clave, vars) => window.PanchoI18n.t(clave, vars)

const btnXerar = document.getElementById('btnXerar')
const btnXerarPDF = document.getElementById('btnXerarPDF')
const btnGardar = document.getElementById('btnGardar')
const btnSubir = document.getElementById('btnSubir')
const statusEl = document.getElementById('status')
const emptyEl = document.getElementById('empty')
const resultadoEl = document.getElementById('resultado')
const resumoEl = document.getElementById('resumo')
const taboaCorpoEl = document.getElementById('taboaCorpo')

const overlay = document.getElementById('overlayCredenciais')
const credenciaisTitulo = document.getElementById('credenciaisTitulo')
const credServidor = document.getElementById('credServidor')
const credUsuario = document.getElementById('credUsuario')
const credContrasinal = document.getElementById('credContrasinal')
const credCancelar = document.getElementById('credCancelar')
const credAceptar = document.getElementById('credAceptar')

let modoActual = null // 'obter' | 'subir'

function setStatus(text) {
  statusEl.textContent = text
}

async function abrirCredenciais(modo, titulo) {
  modoActual = modo
  credenciaisTitulo.textContent = titulo
  try {
    const s = await App().GetSettings()
    credServidor.value = s.servidorURL || ''
  } catch (_) {
    // sen contexto de arranque (ex. probando o binario á man) - deixar baleiro
  }
  credUsuario.value = ''
  credContrasinal.value = ''
  overlay.classList.remove('hidden')
  credUsuario.focus()
}

function pecharCredenciais() {
  overlay.classList.add('hidden')
  credContrasinal.value = '' // non deixar o contrasinal no DOM máis do necesario
}

credCancelar.addEventListener('click', pecharCredenciais)
overlay.addEventListener('click', (ev) => {
  if (ev.target === overlay) pecharCredenciais()
})

credAceptar.addEventListener('click', async () => {
  const cred = {
    servidorURL: credServidor.value.trim(),
    usuario: credUsuario.value.trim(),
    contrasinal: credContrasinal.value,
  }
  const modo = modoActual
  credAceptar.disabled = true
  try {
    if (modo === 'obter') {
      await obterFilas(cred)
    } else if (modo === 'subir') {
      await subirInforme(cred)
    }
    pecharCredenciais()
  } catch (err) {
    setStatus(String(err))
  } finally {
    credAceptar.disabled = false
  }
})

async function obterFilas(cred) {
  setStatus(t('estado.conectando'))
  const filas = await App().ObterFilas(cred)
  pintarFilas(filas)
  setStatus(t('estado.equiposAtopados', {count: filas.length}))
}

function pintarFilas(filas) {
  emptyEl.classList.add('hidden')
  resultadoEl.classList.remove('hidden')
  resumoEl.textContent = t('resumo.equipos', {count: filas.length})
  marcarPDFDesactualizado()

  taboaCorpoEl.innerHTML = ''
  for (const fila of filas) {
    const tr = document.createElement('tr')
    tr.dataset.equipo = fila.equipo
    tr.dataset.ip = fila.ip || ''
    tr.dataset.conectado = fila.conectado ? '1' : ''

    const tdEquipo = document.createElement('td')
    tdEquipo.textContent = fila.equipo
    tr.appendChild(tdEquipo)

    const tdIP = document.createElement('td')
    tdIP.textContent = fila.ip || '—'
    tr.appendChild(tdIP)

    const tdUsuario = document.createElement('td')
    const inUsuario = document.createElement('input')
    inUsuario.type = 'text'
    inUsuario.className = 'cel-usuario'
    inUsuario.value = fila.usuario || ''
    inUsuario.addEventListener('input', marcarPDFDesactualizado)
    tdUsuario.appendChild(inUsuario)
    tr.appendChild(tdUsuario)

    const tdNome = document.createElement('td')
    const inNome = document.createElement('input')
    inNome.type = 'text'
    inNome.className = 'cel-nome'
    inNome.value = fila.nome || ''
    inNome.addEventListener('input', marcarPDFDesactualizado)
    tdNome.appendChild(inNome)
    tr.appendChild(tdNome)

    const tdAccions = document.createElement('td')
    tdAccions.className = 'col-accions'
    const btnBorrar = document.createElement('button')
    btnBorrar.className = 'btn-borrar'
    btnBorrar.title = t('taboa.eliminarFila')
    btnBorrar.textContent = '✕'
    btnBorrar.addEventListener('click', () => {
      tr.remove()
      resumoEl.textContent = t('resumo.equipos', {count: taboaCorpoEl.children.length})
      marcarPDFDesactualizado()
    })
    tdAccions.appendChild(btnBorrar)
    tr.appendChild(tdAccions)

    taboaCorpoEl.appendChild(tr)
  }
}

// marcarPDFDesactualizado desactiva Gardar/Subir en canto a táboa cambia
// (edición, eliminación de filas) - así nunca se garda/sube un PDF que xa
// non coincide co que se ve na pantalla; hai que premer "Xerar PDF" de novo.
function marcarPDFDesactualizado() {
  btnGardar.disabled = true
  btnSubir.disabled = true
}

function lerFilasDaTaboa() {
  return Array.from(taboaCorpoEl.children).map((tr) => ({
    equipo: tr.dataset.equipo,
    ip: tr.dataset.ip,
    conectado: tr.dataset.conectado === '1',
    usuario: tr.querySelector('.cel-usuario').value.trim(),
    nome: tr.querySelector('.cel-nome').value.trim(),
  }))
}

btnXerarPDF.addEventListener('click', async () => {
  const filas = lerFilasDaTaboa()
  if (filas.length === 0) {
    setStatus(t('estado.senFilas'))
    return
  }
  try {
    setStatus(t('estado.xerandoPDF'))
    const resultado = await App().XerarPDF(filas)
    btnGardar.disabled = false
    btnSubir.disabled = false
    setStatus(t('estado.pdfXeradoAs', {hora: resultado.xeradoEn}))
  } catch (err) {
    setStatus(String(err))
  }
})

async function subirInforme(cred) {
  setStatus(t('estado.subindo'))
  const rutaRemota = await App().SubirInforme(cred)
  setStatus(t('estado.subidoA', {ruta: rutaRemota}))
}

btnXerar.addEventListener('click', () => {
  abrirCredenciais('obter', t('credenciais.obterTitulo'))
})

btnSubir.addEventListener('click', () => {
  abrirCredenciais('subir', t('credenciais.subirTitulo'))
})

btnGardar.addEventListener('click', async () => {
  try {
    setStatus(t('estado.gardando'))
    const path = await App().GardarInformeLocal()
    setStatus(path ? t('estado.gardadoEn', {ruta: path}) : t('estado.senGardar'))
  } catch (err) {
    setStatus(String(err))
  }
})

// ── "Sobre Pancho" (← botón "i" da barra) ───────────────────────────────
// Mesmo mecanismo ca Piztu/Yang/Tao: o backend comproba en fondo ao
// arrincar (evento "actualizacion_pancho_cambiada", pancho/actualizacion.go)
// e aquí só se pinta o que xa se sabe.
const btnSobre = document.getElementById('btnSobre')
const overlaySobre = document.getElementById('overlaySobre')
const sobreVersion = document.getElementById('sobreVersion')
const sobreActualizacion = document.getElementById('sobreActualizacion')
const btnSobreActualizar = document.getElementById('btnSobreActualizar')
const btnSobrePechar = document.getElementById('btnSobrePechar')

let actualizacionPancho = null

function pintarSobreActualizacion() {
  sobreVersion.textContent = t('sobre.version') + ' ' + (actualizacionPancho ? actualizacionPancho.versionLocal : '')

  const dispo = !!(actualizacionPancho && actualizacionPancho.disponible)
  btnSobre.classList.toggle('btn-actualizacion-dispo', dispo)

  if (dispo) {
    sobreActualizacion.textContent = t('sobre.novaversion', {v: actualizacionPancho.versionRemota})
    sobreActualizacion.classList.remove('hidden')
    btnSobreActualizar.classList.remove('hidden')
    btnSobreActualizar.disabled = false
    btnSobreActualizar.textContent = t('sobre.actualizar')
  } else {
    sobreActualizacion.classList.add('hidden')
    btnSobreActualizar.classList.add('hidden')
  }
}

function aplicarActualizacionPancho(estado) {
  actualizacionPancho = estado || null
  pintarSobreActualizacion()
}

App().GetActualizacionPancho().then(aplicarActualizacionPancho).catch(() => {})
if (window.runtime) {
  window.runtime.EventsOn('actualizacion_pancho_cambiada', aplicarActualizacionPancho)
}

btnSobre.addEventListener('click', () => overlaySobre.classList.remove('hidden'))
btnSobrePechar.addEventListener('click', () => overlaySobre.classList.add('hidden'))
overlaySobre.addEventListener('click', (ev) => {
  if (ev.target === overlaySobre) overlaySobre.classList.add('hidden')
})

btnSobreActualizar.addEventListener('click', () => {
  if (!confirm(t('sobre.actualizarConfirmar'))) return
  btnSobreActualizar.disabled = true
  btnSobreActualizar.textContent = t('sobre.actualizando')
  App().AplicarActualizacionPancho()
    .then(() => {
      btnSobreActualizar.textContent = '✔'
      setTimeout(() => window.runtime && window.runtime.Quit(), 400)
    })
    .catch((err) => {
      btnSobreActualizar.disabled = false
      btnSobreActualizar.textContent = t('sobre.actualizar')
      setStatus(String(err))
    })
})
