package main

import (
	"encoding/json"
	"os"
	"path/filepath"
)

// Settings persiste só o enderezo do servidor de File Browser entre
// arranques — nunca as credenciais do profesor, que se piden cada vez que
// fan falla (ver filebrowser.go e CredenciaisFB), sen gardalas nin en disco
// nin en memoria máis alá da chamada que as usa.
type Settings struct {
	ServidorURL string `json:"servidorURL"`
}

// servidorURLPorDefecto é o mesmo enderezo local que usa piztu por
// defecto (config.yaml: filebrowser.url) — Pancho lánzase sempre na
// mesma máquina ca Piztu (é un módulo do mapa da aula), así que o servidor
// de File Browser adoita estar no propio equipo.
const servidorURLPorDefecto = "http://127.0.0.1:8080"

func settingsPath() (string, error) {
	dir, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	dir = filepath.Join(dir, "pancho")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	return filepath.Join(dir, "settings.json"), nil
}

func loadSettings() Settings {
	s := Settings{ServidorURL: servidorURLPorDefecto}
	path, err := settingsPath()
	if err != nil {
		return s
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return s
	}
	var loaded Settings
	if json.Unmarshal(b, &loaded) == nil && loaded.ServidorURL != "" {
		s.ServidorURL = loaded.ServidorURL
	}
	return s
}

func saveSettingsToDisk(s Settings) error {
	path, err := settingsPath()
	if err != nil {
		return err
	}
	b, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o644)
}

// GetSettings devolve os axustes actuais, para prerrechear o campo de
// servidor no formulario de credenciais.
func (a *App) GetSettings() Settings {
	return a.settings
}

// SaveSettings garda só o enderezo do servidor (o campo ServidorURL) —
// calquera outro campo que a UI mande queda ignorado a propósito, coma
// medida extra para que nunca se poida colar unha credencial aquí por
// erro futuro no frontend.
func (a *App) SaveSettings(s Settings) error {
	a.settings = Settings{ServidorURL: s.ServidorURL}
	return saveSettingsToDisk(a.settings)
}
