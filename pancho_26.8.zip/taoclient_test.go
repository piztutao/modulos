package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

// servidorTaoProba monta un httptest.Server que responde GET /api/v1/usuarios/{u}
// coma o faría Tao (tao/api_handlers.go handleUsuario): 200 con {name,surname} para
// os usuarios de `coñecidos`, 404 para calquera outro. Comproba tamén o token.
func servidorTaoProba(t *testing.T, token string, coñecidos map[string]respostaUsuarioTao) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer "+token {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		username := r.URL.Path[len("/api/v1/usuarios/"):]
		resp, ok := coñecidos[username]
		if !ok {
			w.WriteHeader(http.StatusNotFound)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_ = json.NewEncoder(w).Encode(resp)
	}))
}

func TestClienteTaoUsuarioResolveNomeCompleto(t *testing.T) {
	server := servidorTaoProba(t, "tok123", map[string]respostaUsuarioTao{
		"xoel": {Username: "xoel", Name: "Xoel", Surname: "Pérez Vidal"},
	})
	defer server.Close()

	c := &clienteTao{token: "tok123", baseURL: server.URL, http: server.Client()}
	nome, ok := c.Usuario(t.Context(), "xoel")
	if !ok || nome != "Xoel Pérez Vidal" {
		t.Fatalf("esperaba (\"Xoel Pérez Vidal\", true), obtiven (%q, %v)", nome, ok)
	}
}

func TestClienteTaoUsuarioNonAtopadoDevolveOkFalse(t *testing.T) {
	server := servidorTaoProba(t, "tok123", map[string]respostaUsuarioTao{})
	defer server.Close()

	c := &clienteTao{token: "tok123", baseURL: server.URL, http: server.Client()}
	nome, ok := c.Usuario(t.Context(), "descoñecido")
	if ok || nome != "" {
		t.Fatalf("un 404 debe devolver (\"\", false), obtiven (%q, %v)", nome, ok)
	}
}

func TestClienteTaoUsuarioTokenIncorrectoDevolveOkFalse(t *testing.T) {
	server := servidorTaoProba(t, "tok-de-verdade", map[string]respostaUsuarioTao{
		"xoel": {Username: "xoel", Name: "Xoel", Surname: "Pérez"},
	})
	defer server.Close()

	c := &clienteTao{token: "tok-vello", baseURL: server.URL, http: server.Client()}
	nome, ok := c.Usuario(t.Context(), "xoel")
	if ok || nome != "" {
		t.Fatalf("token incorrecto (401) debe devolver (\"\", false), obtiven (%q, %v)", nome, ok)
	}
}

// TestClienteTaoUsuarioTimeoutNonBloqueaAlenDoTeito cobre o requisito de que a
// consulta a Tao nunca atrase o informe máis do teito: un servidor que non
// responde nunca debe facer que Usuario() devolva antes do contexto vencer, e
// devolver (_, false) sen entrar en pánico.
func TestClienteTaoUsuarioTimeoutNonBloqueaAlenDoTeito(t *testing.T) {
	bloqueado := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		<-bloqueado // nunca responde antes de que o test o libere
	}))
	// Orde de defer (LIFO) a propósito: primeiro liberar o handler bloqueado
	// (close(bloqueado)), SÓ DESPOIS pechar o servidor — server.Close() agarda a
	// que calquera handler en curso remate, así que pechalo antes de liberar o
	// handler sería un deadlock (quedou colgado a primeira vez que se escribiu así).
	defer server.Close()
	defer close(bloqueado)

	c := &clienteTao{token: "tok", baseURL: server.URL, http: server.Client()}
	inicio := time.Now()
	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	defer cancel()
	nome, ok := c.Usuario(ctx, "xoel")
	transcorrido := time.Since(inicio)

	if ok || nome != "" {
		t.Fatalf("esperaba (\"\", false) ao vencer o teito, obtiven (%q, %v)", nome, ok)
	}
	if transcorrido > time.Second {
		t.Fatalf("Usuario() tardou %v, debería ter respectado o teito do contexto (~200ms)", transcorrido)
	}
}

// TestConstruirFilasConTaoMellorAONomeCompleto cobre o bug real: a sesión que
// publica Tao pode traer só o username en Nome (cando aínda non coñecía o nome
// real dese alumno nese equipo) — construirFilasCon debe substituílo polo nome e
// apelidos completos que devolva a API de Tao.
func TestConstruirFilasConTaoMellorAONomeCompleto(t *testing.T) {
	server := servidorTaoProba(t, "tok", map[string]respostaUsuarioTao{
		"xoel": {Username: "xoel", Name: "Xoel", Surname: "Pérez Vidal"},
	})
	defer server.Close()
	tao := &clienteTao{token: "tok", baseURL: server.URL, http: server.Client()}

	equipos := []EquipoContexto{{Nome: "bac01.local"}}
	sesions := map[string]sesionBruta{
		// Nome == Usuario: exactamente o bug que motivou isto.
		"bac01": {Equipo: "bac01", Usuario: "xoel", Nome: "xoel", Conectado: true},
	}

	filas := construirFilasCon(equipos, sesions, tao)
	if len(filas) != 1 {
		t.Fatalf("esperaba 1 fila, obtiven %d", len(filas))
	}
	if filas[0].Nome != "Xoel Pérez Vidal" {
		t.Errorf("Nome debería vir de Tao (\"Xoel Pérez Vidal\"), obtiven %q", filas[0].Nome)
	}
	if filas[0].Usuario != "xoel" {
		t.Errorf("Usuario non debería tocarse, obtiven %q", filas[0].Usuario)
	}
}

// TestConstruirFilasConTaoNilMantenComportamentoOrixinal cobre o caso sen Tao
// dispoñible (tao == nil, ex. Tao non está en marcha nesta máquina): o informe
// debe xerarse igual, co nome que xa viña na sesión, sen erro nin panic.
func TestConstruirFilasConTaoNilMantenComportamentoOrixinal(t *testing.T) {
	equipos := []EquipoContexto{{Nome: "bac01.local"}}
	sesions := map[string]sesionBruta{
		"bac01": {Equipo: "bac01", Usuario: "xoel", Nome: "xoel", Conectado: true},
	}

	filas := construirFilasCon(equipos, sesions, nil)
	if len(filas) != 1 || filas[0].Nome != "xoel" || filas[0].Usuario != "xoel" {
		t.Fatalf("sen Tao dispoñible debería manter o nome orixinal da sesión: %+v", filas)
	}
}

// TestConstruirFilasConTaoUsuarioNonAtopadoMantenNomeOrixinal cobre o caso en
// que Tao está dispoñible pero non coñece ese username (ex. profesor/admin
// sen ese usuario no roster nin en profiles.json): a fila non debe quedar baleira,
// mantense o que xa había.
func TestConstruirFilasConTaoUsuarioNonAtopadoMantenNomeOrixinal(t *testing.T) {
	server := servidorTaoProba(t, "tok", map[string]respostaUsuarioTao{})
	defer server.Close()
	tao := &clienteTao{token: "tok", baseURL: server.URL, http: server.Client()}

	equipos := []EquipoContexto{{Nome: "bac01.local"}}
	sesions := map[string]sesionBruta{
		"bac01": {Equipo: "bac01", Usuario: "descoñecido", Nome: "descoñecido", Conectado: true},
	}

	filas := construirFilasCon(equipos, sesions, tao)
	if filas[0].Nome != "descoñecido" {
		t.Errorf("Tao sen coñecer o usuario debería manter o nome orixinal, obtiven %q", filas[0].Nome)
	}
}
