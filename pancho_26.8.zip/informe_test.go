package main

import "testing"

// TestConstruirFilas cobre o bug real que motivou nomeBase: Tao publica a
// sesión co hostname curto ("bac01") mentres o inventario de Piztu adoita
// levar o FQDN ("bac01.local") — antes disto aparecían coma DOUS equipos
// distintos (un sen usuario, outro fóra do inventario). Tamén cobre que un
// equipo alleo ao inventario (outra máquina da rede, ou o propio servidor
// de File Browser) nunca aparece, aínda que teña sesión publicada.
func TestConstruirFilas(t *testing.T) {
	equipos := []EquipoContexto{{Nome: "bac01.local"}, {Nome: "bac02.local"}}
	sesions := map[string]sesionBruta{
		"bac01":     {Equipo: "bac01", Usuario: "xoel", Nome: "Xoel Pérez", Conectado: true},
		"bac0":      {Equipo: "bac0", Usuario: "root", Nome: "Servidor", Conectado: true}, // allea ao inventario
		"portatil7": {Equipo: "portatil7", Usuario: "alguen", Conectado: true},            // allea ao inventario
	}

	filas := construirFilas(equipos, sesions)

	if len(filas) != 2 {
		t.Fatalf("esperaba 2 filas (unha por equipo do inventario), obtiven %d: %+v", len(filas), filas)
	}
	if filas[0].Equipo != "bac01.local" || filas[0].Usuario != "xoel" || !filas[0].Conectado {
		t.Errorf("bac01.local debería casar coa sesión de bac01: %+v", filas[0])
	}
	if filas[1].Equipo != "bac02.local" || filas[1].Usuario != "" || filas[1].Conectado {
		t.Errorf("bac02.local non ten sesión publicada, debería quedar baleiro: %+v", filas[1])
	}
	for _, f := range filas {
		if f.Equipo == "bac0" || f.Equipo == "portatil7" {
			t.Errorf("equipo alleo ao inventario non debería aparecer: %+v", f)
		}
	}
}

func TestNomeBase(t *testing.T) {
	casos := map[string]string{
		"bac01.local": "bac01",
		"bac01":       "bac01",
		"a.b.c":       "a",
		"":            "",
	}
	for in, quero := range casos {
		if got := nomeBase(in); got != quero {
			t.Errorf("nomeBase(%q) = %q, quería %q", in, got, quero)
		}
	}
}

// TestResolverIPUsaARP cobre o caso real que motivou isto: un equipo
// ".local" que o resolvedor DNS puro de Go non pode resolver (sen mDNS),
// pero cuxa MAC xa está na táboa ARP (porque o propio Piztu fai ping
// periódico a todos os equipos) — debe atopar a IP igual, sen tocar rede.
func TestResolverIPUsaARP(t *testing.T) {
	arp := map[string]string{"64:4e:d7:c3:e2:cf": "192.168.1.23"}

	ip := resolverIP("bac01.local", "64:4E:D7:C3:E2:CF", arp) // maiúsculas: hosts adoita escribilas así
	if ip != "192.168.1.23" {
		t.Errorf("resolverIP debería atopar a IP pola MAC na táboa ARP, obtiven %q", ip)
	}

	// Sen MAC nin entrada ARP, e un hostname que non vai resolver en test
	// (rede illada/sandbox) - debe devolver "" sen tardar de máis, non
	// entrar en pánico nin bloquear.
	ip = resolverIP("equipo-inexistente.invalid", "", map[string]string{})
	if ip != "" {
		t.Errorf("esperaba \"\" para un equipo sen MAC nin DNS, obtiven %q", ip)
	}
}

func TestParsearTaboaARP(t *testing.T) {
	contido := "IP address       HW type     Flags       HW address            Mask     Device\n" +
		"192.168.1.23     0x1         0x2         64:4e:d7:c3:e2:cf     *        eth0\n" +
		"192.168.1.99     0x1         0x0         00:00:00:00:00:00     *        eth0\n" + // incompleta
		"\n" // liña baleira final, coma remata realmente o ficheiro

	arp := parsearTaboaARP(contido)

	if got := arp["64:4e:d7:c3:e2:cf"]; got != "192.168.1.23" {
		t.Errorf("esperaba 192.168.1.23 para a MAC completa, obtiven %q", got)
	}
	if _, ok := arp["00:00:00:00:00:00"]; ok {
		t.Error("unha entrada ARP incompleta (00:00:00:00:00:00) non debería quedar na táboa")
	}
	if len(arp) != 1 {
		t.Errorf("esperaba 1 entrada válida, obtiven %d: %+v", len(arp), arp)
	}
}
