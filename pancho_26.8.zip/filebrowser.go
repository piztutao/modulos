package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// Cliente mínimo de File Browser (https://filebrowser.org), mesmo protocolo
// que xa usa tao/filebrowser.go (POST /api/login devolve un JWT en texto
// plano, enviado despois na cabeceira X-Auth) pero recortado ao que
// Pancho precisa: ler o cartafol de sesións que Tao publica
// (dixitalizacion/sesions/*.json) e subir o PDF xerado. Sen ler/escribir
// nada máis, e sen gardar nunca as credenciais en disco — cada chamada
// recibe as súas propias (ver CredenciaisFB en informe.go).

const fbSesionsDir = "dixitalizacion/sesions"
const fbInformesDir = "pancho"
const fbHTTPTimeout = 20 * time.Second

func fbClient() *http.Client {
	return &http.Client{Timeout: fbHTTPTimeout}
}

// normalizeServerURL trims a trailing slash and ensures a scheme (defaulting
// to http, since the File Browser server is typically plain HTTP on the LAN)
// — mesma lóxica que tao/filebrowser.go.
func normalizeServerURL(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	if !strings.HasPrefix(raw, "http://") && !strings.HasPrefix(raw, "https://") {
		raw = "http://" + raw
	}
	return strings.TrimRight(raw, "/")
}

func fbEscapePath(p string) string {
	segments := strings.Split(strings.Trim(p, "/"), "/")
	for i, s := range segments {
		segments[i] = url.PathEscape(s)
	}
	return strings.Join(segments, "/")
}

// fbLogin exchanges credentials for a JWT. File Browser returns the token as
// the plain-text response body and answers 403/401 when the credentials are
// wrong.
func fbLogin(base, username, password string) (string, error) {
	body, _ := json.Marshal(map[string]string{
		"username":  username,
		"password":  password,
		"recaptcha": "",
	})
	resp, err := fbClient().Post(base+"/api/login", "application/json", bytes.NewReader(body))
	if err != nil {
		return "", fmt.Errorf("non se puido contactar co servidor de ficheiros: %w", err)
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(resp.Body)

	switch resp.StatusCode {
	case http.StatusOK:
	case http.StatusForbidden, http.StatusUnauthorized:
		return "", fmt.Errorf("usuario ou contrasinal incorrectos no servidor de ficheiros")
	default:
		return "", fmt.Errorf("o servidor de ficheiros devolveu un erro (%d): %s",
			resp.StatusCode, strings.TrimSpace(string(data)))
	}

	token := strings.TrimSpace(string(data))
	if token == "" {
		return "", fmt.Errorf("o servidor de ficheiros non devolveu un token de acceso")
	}
	return token, nil
}

type fbItem struct {
	Name  string `json:"name"`
	IsDir bool   `json:"isDir"`
}

// fbList devolve as entradas dun cartafol do servidor. Un 404 (cartafol
// inexistente aínda, ex. antes de que Tao publique a primeira sesión)
// devólvese como listaxe baleira, non como erro.
func fbList(base, token, dir string) ([]fbItem, error) {
	endpoint := base + "/api/resources/" + fbEscapePath(dir) + "/"
	req, err := http.NewRequest(http.MethodGet, endpoint, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("X-Auth", token)
	resp, err := fbClient().Do(req)
	if err != nil {
		return nil, fmt.Errorf("non se puido listar %q no servidor de ficheiros: %w", dir, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound {
		return nil, nil
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("erro %d ao listar %q", resp.StatusCode, dir)
	}
	var listing struct {
		Items []fbItem `json:"items"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&listing); err != nil {
		return nil, fmt.Errorf("resposta non válida do servidor de ficheiros")
	}
	return listing.Items, nil
}

// fbRawGet downloads a file through /api/raw using the X-Auth header.
func fbRawGet(base, token, remotePath string) ([]byte, error) {
	endpoint := base + "/api/raw/" + fbEscapePath(remotePath)
	req, err := http.NewRequest(http.MethodGet, endpoint, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("X-Auth", token)
	resp, err := fbClient().Do(req)
	if err != nil {
		return nil, fmt.Errorf("non se puido descargar %q: %w", remotePath, err)
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("erro %d ao descargar %q", resp.StatusCode, remotePath)
	}
	return data, nil
}

// fbEnsureDir crea un cartafol do servidor se aínda non existe (idempotente:
// File Browser non falla se xa existe).
func fbEnsureDir(base, token, dir string) error {
	endpoint := base + "/api/resources/" + fbEscapePath(dir) + "/"
	req, err := http.NewRequest(http.MethodPost, endpoint, nil)
	if err != nil {
		return err
	}
	req.Header.Set("X-Auth", token)
	resp, err := fbClient().Do(req)
	if err != nil {
		return fmt.Errorf("non se puido crear a carpeta %q: %w", dir, err)
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("erro %d ao crear a carpeta %q", resp.StatusCode, dir)
	}
	return nil
}

// fbUpload writes content to remotePath, overwriting any existing file.
func fbUpload(base, token, remotePath string, content []byte) error {
	endpoint := base + "/api/resources/" + fbEscapePath(remotePath) + "?override=true"
	req, err := http.NewRequest(http.MethodPost, endpoint, bytes.NewReader(content))
	if err != nil {
		return err
	}
	req.Header.Set("X-Auth", token)
	req.Header.Set("Content-Type", "application/octet-stream")
	resp, err := fbClient().Do(req)
	if err != nil {
		return fmt.Errorf("non se puido gardar no servidor de ficheiros: %w", err)
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("o servidor de ficheiros rexeitou o gardado (%d): %s",
			resp.StatusCode, strings.TrimSpace(string(data)))
	}
	return nil
}
