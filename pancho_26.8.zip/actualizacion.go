package main

// Autoactualización do propio Pancho, mesmo mecanismo ca Piztu/Tao/Yang
// (ver piztu/internal/actualizacion/actualizacion.go e
// yang/actualizacion.go, dos que este ficheiro é unha adaptación directa).
//
// A versión instalada lese do ficheiro VERSION embebido na raíz deste
// módulo. A versión publicada consúltase no repositorio compartido de
// módulos de Piztu, piztutao/modulos — cada publicación de Pancho crea a
// súa propia Release co tag prefixado "pancho-<versión>". Percórrense TODAS
// as Releases (máis recentes primeiro) ata atopar a primeira que traia un
// asset "pancho_<versión>.zip" — a versión remota parséase dese NOME DE
// ASSET. A Release tamén ten que publicar "<nome-do-zip>.sha256",
// verificado antes de instalar nada.
import (
	"archive/zip"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"

	wailsruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

//go:embed VERSION
var versionPanchoFicheiro string

const repoPanchoActualizacion = "piztutao/modulos"
const urlReleasesPancho = "https://api.github.com/repos/" + repoPanchoActualizacion + "/releases?per_page=100"
const timeoutComprobarPancho = 5 * time.Second
const timeoutDescargaPancho = 60 * time.Second

// EstadoActualizacionPancho é o resultado de comprobar unha actualización
// de Pancho — mesma forma ca EstadoActualizacionYang/Tao.
type EstadoActualizacionPancho struct {
	Disponible    bool   `json:"disponible"`
	VersionLocal  string `json:"versionLocal"`
	VersionRemota string `json:"versionRemota"`
	URLDescarga   string `json:"urlDescarga"`
	URLChecksum   string `json:"urlChecksum"`
	Notas         string `json:"notas"`
}

type assetGitHubPancho struct {
	Name               string `json:"name"`
	BrowserDownloadURL string `json:"browser_download_url"`
}

type releaseGitHubPancho struct {
	TagName string              `json:"tag_name"`
	Body    string              `json:"body"`
	Assets  []assetGitHubPancho `json:"assets"`
}

func escollerAssetsPancho(assets []assetGitHubPancho) (urlZip, nomeZip, urlChecksum string) {
	for _, a := range assets {
		nome := strings.ToLower(a.Name)
		if strings.HasPrefix(nome, "pancho_") && strings.HasSuffix(nome, ".zip") {
			urlZip = a.BrowserDownloadURL
			nomeZip = a.Name
			break
		}
	}
	if urlZip == "" {
		return "", "", ""
	}
	for _, a := range assets {
		if strings.EqualFold(a.Name, nomeZip+".sha256") {
			urlChecksum = a.BrowserDownloadURL
			break
		}
	}
	return urlZip, nomeZip, urlChecksum
}

func versionDesdeNomeZipPancho(nomeZip string) string {
	nome := strings.ToLower(nomeZip)
	nome = strings.TrimPrefix(nome, "pancho_")
	nome = strings.TrimSuffix(nome, ".zip")
	return strings.TrimSpace(nome)
}

func partesVersionPancho(v string) ([]int, bool) {
	v = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(v), "v"))
	if v == "" {
		return nil, false
	}
	anacos := strings.Split(v, ".")
	partes := make([]int, 0, len(anacos))
	for _, a := range anacos {
		n, err := strconv.Atoi(strings.TrimSpace(a))
		if err != nil {
			return nil, false
		}
		partes = append(partes, n)
	}
	return partes, true
}

func versionMaiorPancho(remota, local string) bool {
	r, okR := partesVersionPancho(remota)
	if !okR {
		return false
	}
	l, okL := partesVersionPancho(local)
	if !okL {
		l = []int{0}
	}
	for i := 0; i < len(r) || i < len(l); i++ {
		var rv, lv int
		if i < len(r) {
			rv = r[i]
		}
		if i < len(l) {
			lv = l[i]
		}
		if rv != lv {
			return rv > lv
		}
	}
	return false
}

// VersionLocalPancho devolve a versión instalada de Pancho.
func VersionLocalPancho() string {
	return strings.TrimSpace(versionPanchoFicheiro)
}

// GetActualizacionPancho devolve a última foto de se hai actualización de
// Pancho dispoñible, sen tocar a rede — bound ao frontend (← botón "i").
func (a *App) GetActualizacionPancho() EstadoActualizacionPancho {
	a.actualizacionMu.Lock()
	defer a.actualizacionMu.Unlock()
	return a.actualizacionPancho
}

// comprobarActualizacionPancho consulta a rede e garda o resultado, emitindo
// o evento se cambiou. Chamado en fondo (go a.comprobarActualizacionPancho())
// dende startup.
func (a *App) comprobarActualizacionPancho() {
	estado := comprobarActualizacionPanchoRede()
	a.actualizacionMu.Lock()
	a.actualizacionPancho = estado
	a.actualizacionMu.Unlock()
	if a.ctx != nil {
		wailsruntime.EventsEmit(a.ctx, "actualizacion_pancho_cambiada", estado)
	}
}

func comprobarActualizacionPanchoRede() EstadoActualizacionPancho {
	estado := EstadoActualizacionPancho{VersionLocal: VersionLocalPancho()}

	req, err := http.NewRequest(http.MethodGet, urlReleasesPancho, nil)
	if err != nil {
		return estado
	}
	req.Header.Set("Accept", "application/vnd.github+json")

	cliente := http.Client{Timeout: timeoutComprobarPancho}
	resp, err := cliente.Do(req)
	if err != nil {
		return estado
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return estado
	}

	var rels []releaseGitHubPancho
	if err := json.NewDecoder(resp.Body).Decode(&rels); err != nil {
		return estado
	}

	for _, rel := range rels {
		urlZip, nomeZip, urlChecksum := escollerAssetsPancho(rel.Assets)
		if urlZip == "" {
			continue
		}
		versionRemota := versionDesdeNomeZipPancho(nomeZip)
		if versionRemota == "" {
			continue
		}
		estado.VersionRemota = versionRemota
		estado.URLDescarga = urlZip
		estado.URLChecksum = urlChecksum
		estado.Notas = rel.Body
		estado.Disponible = versionMaiorPancho(versionRemota, estado.VersionLocal)
		return estado
	}
	return estado
}

func nomeExecutablePancho() string {
	if runtime.GOOS == "windows" {
		return "pancho.exe"
	}
	return "pancho"
}

func descargarPancho(url, destinoDir, nomeFicheiro string) (string, error) {
	if err := os.MkdirAll(destinoDir, 0o755); err != nil {
		return "", fmt.Errorf("non se puido crear %q: %w", destinoDir, err)
	}
	destino := filepath.Join(destinoDir, nomeFicheiro)

	cliente := http.Client{Timeout: timeoutDescargaPancho}
	resp, err := cliente.Get(url)
	if err != nil {
		return "", fmt.Errorf("non se puido descargar a actualización: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("non se puido descargar a actualización: HTTP %d", resp.StatusCode)
	}

	f, err := os.Create(destino)
	if err != nil {
		return "", fmt.Errorf("non se puido crear %q: %w", destino, err)
	}
	defer f.Close()
	if _, err := io.Copy(f, resp.Body); err != nil {
		return "", fmt.Errorf("non se puido gardar a actualización: %w", err)
	}
	return destino, nil
}

func extraerExecutablePancho(zipRuta, destDir string) (string, error) {
	zr, err := zip.OpenReader(zipRuta)
	if err != nil {
		return "", fmt.Errorf("o ficheiro descargado non é un zip válido: %w", err)
	}
	defer zr.Close()

	buscado := nomeExecutablePancho()
	for _, f := range zr.File {
		if f.FileInfo().IsDir() || filepath.Base(f.Name) != buscado {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			return "", fmt.Errorf("non se puido abrir %q dentro do zip: %w", f.Name, err)
		}
		defer rc.Close()

		destino := filepath.Join(destDir, buscado)
		out, err := os.OpenFile(destino, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
		if err != nil {
			return "", fmt.Errorf("non se puido crear %q: %w", destino, err)
		}
		defer out.Close()
		if _, err := io.Copy(out, rc); err != nil {
			return "", fmt.Errorf("non se puido extraer %q: %w", f.Name, err)
		}
		return destino, nil
	}
	return "", fmt.Errorf("o zip da actualización non contén %q — revisa como o empaquetaches", buscado)
}

func lerHashEsperadoPancho(r io.Reader) (string, error) {
	datos, err := io.ReadAll(io.LimitReader(r, 4096))
	if err != nil {
		return "", fmt.Errorf("non se puido ler o .sha256: %w", err)
	}
	campos := strings.Fields(string(datos))
	if len(campos) == 0 {
		return "", fmt.Errorf("o ficheiro .sha256 da Release está baleiro")
	}
	return strings.ToLower(campos[0]), nil
}

func comprobarChecksumPancho(ficheiroRuta, urlChecksum string) error {
	if urlChecksum == "" {
		return fmt.Errorf("esta Release non publica un .sha256 do .zip — non se pode verificar a súa integridade, así que se cancela a actualización por seguridade")
	}

	cliente := http.Client{Timeout: timeoutComprobarPancho}
	resp, err := cliente.Get(urlChecksum)
	if err != nil {
		return fmt.Errorf("non se puido descargar o .sha256 da actualización: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("non se puido descargar o .sha256 da actualización: HTTP %d", resp.StatusCode)
	}
	esperado, err := lerHashEsperadoPancho(resp.Body)
	if err != nil {
		return err
	}

	f, err := os.Open(ficheiroRuta)
	if err != nil {
		return fmt.Errorf("non se puido abrir %q para verificalo: %w", ficheiroRuta, err)
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return fmt.Errorf("non se puido calcular o SHA-256 de %q: %w", ficheiroRuta, err)
	}
	obtido := hex.EncodeToString(h.Sum(nil))

	if obtido != esperado {
		return fmt.Errorf("o SHA-256 do .zip descargado non coincide co publicado na Release — podería estar adulterado; cancélase a actualización")
	}
	return nil
}

func copiarFicheiroPancho(orixe, destino string) error {
	in, err := os.Open(orixe)
	if err != nil {
		return fmt.Errorf("non se puido abrir %q: %w", orixe, err)
	}
	defer in.Close()
	out, err := os.OpenFile(destino, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return fmt.Errorf("non se puido crear %q: %w", destino, err)
	}
	defer out.Close()
	if _, err := io.Copy(out, in); err != nil {
		return fmt.Errorf("non se puido copiar a %q: %w", destino, err)
	}
	return nil
}

// AplicarActualizacionPancho descarga a última versión de Pancho (estado xa
// coñecido por GetActualizacionPancho), substitúe o executable en execución
// e arrinca xa a nova copia (← botón "Actualizar" no diálogo "Sobre
// Pancho"). O frontend é quen peche esta xanela despois.
func (a *App) AplicarActualizacionPancho() error {
	estado := a.GetActualizacionPancho()
	if !estado.Disponible || estado.URLDescarga == "" {
		return fmt.Errorf("non hai ningunha actualización de Pancho dispoñible")
	}
	if err := aplicarActualizacionPanchoEnCaliente(estado.URLDescarga, estado.URLChecksum, estado.VersionRemota); err != nil {
		return err
	}
	return reiniciarPancho()
}

func aplicarActualizacionPanchoEnCaliente(urlZip, urlChecksum, versionNova string) error {
	if runtime.GOOS == "windows" {
		return fmt.Errorf("a actualización automática aínda non está soportada en Windows")
	}

	exeActual, err := os.Executable()
	if err != nil {
		return fmt.Errorf("non se puido localizar o executable actual: %w", err)
	}
	exeActual, err = filepath.EvalSymlinks(exeActual)
	if err != nil {
		return fmt.Errorf("non se puido resolver o executable actual: %w", err)
	}

	tmpDir, err := os.MkdirTemp("", "pancho-actualizacion-")
	if err != nil {
		return fmt.Errorf("non se puido crear un cartafol temporal: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	zipRuta, err := descargarPancho(urlZip, tmpDir, "actualizacion.zip")
	if err != nil {
		return err
	}
	if err := comprobarChecksumPancho(zipRuta, urlChecksum); err != nil {
		return err
	}
	novoExe, err := extraerExecutablePancho(zipRuta, tmpDir)
	if err != nil {
		return err
	}

	swapTmp := exeActual + ".novo"
	defer os.Remove(swapTmp)
	if err := copiarFicheiroPancho(novoExe, swapTmp); err != nil {
		return err
	}

	_ = copiarFicheiroPancho(exeActual, exeActual+".anterior")

	if err := os.Rename(swapTmp, exeActual); err != nil {
		return fmt.Errorf("non se puido instalar o binario novo: %w", err)
	}

	if versionNova != "" {
		actualizarVersionModuloJSONPancho(filepath.Dir(exeActual), versionNova)
	}
	return nil
}

func actualizarVersionModuloJSONPancho(dirModulo, versionNova string) {
	ruta := filepath.Join(dirModulo, "modulo.json")
	datos, err := os.ReadFile(ruta)
	if err != nil {
		return
	}
	var m map[string]any
	if err := json.Unmarshal(datos, &m); err != nil {
		return
	}
	m["version"] = versionNova
	novosDatos, err := json.MarshalIndent(m, "", "  ")
	if err != nil {
		return
	}
	_ = os.WriteFile(ruta, novosDatos, 0o644)
}

// reiniciarPancho arrinca unha nova copia de Pancho coma proceso
// independente, para que o frontend poida pechar esta xanela decontado.
func reiniciarPancho() error {
	exe, err := os.Executable()
	if err != nil {
		return fmt.Errorf("non se puido localizar o executable: %w", err)
	}
	exe, err = filepath.EvalSymlinks(exe)
	if err != nil {
		return fmt.Errorf("non se puido resolver o executable: %w", err)
	}

	cmd := exec.Command(exe)
	cmd.Dir = filepath.Dir(exe)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("non se puido reiniciar Pancho: %w", err)
	}
	return nil
}
