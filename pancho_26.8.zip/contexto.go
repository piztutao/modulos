package main

import (
	"encoding/json"
	"os"
)

// EquipoContexto é o subconxunto de ContextoModulo.Equipos (ver
// piztu/app.go) que Pancho precisa: o nome de cada equipo do
// inventario, para que o informe liste tamén os equipos sen sesión activa
// (non só os que teñen ficheiro de sesión en File Browser).
type EquipoContexto struct {
	Nome string `json:"nome"`
	Mac  string `json:"mac"`
}

// contextoModulo é o subconxunto do contrato que Piztu escribe ao lanzar un
// módulo externo (ver ContextoModulo/escribirContexto en piztu/app.go).
// Mesmo patrón que xesta/contexto.go: Pancho non fala coa API de
// módulos (internal/api) — non precisa "permisos" en modulo.json, xa que a
// listaxe de equipos xa vén nesta foto de arranque, e o dato de usuario por
// equipo non está exposto por esa API a propósito (illamento Xesta/Tao, ver
// CLAUDE.md) — Pancho lese directamente de File Browser coas
// credenciais que o profesor escribe (ver filebrowser.go).
type contextoModulo struct {
	Equipos []EquipoContexto `json:"equipos"`
	// Idioma é o código (gl/es/en/pt) que o profesorado ten escollido en ⚙ Aula
	// para o propio Piztu — Pancho úsao coma valor por defecto do seu propio
	// idioma (ver App.GetIdioma, frontend/src/i18n.js), nunca coma unha orde:
	// unha elección explícita xa gardada en localStorage segue gañando.
	Idioma string `json:"idioma"`
	// Axustes trae os valores do panel de Pancho en ⚙ Aula (ver panel.yaml e
	// PanelModulo/escribirContexto en piztu/app.go) — de momento só "ancho",
	// o ancho en píxeles da columna lateral (ver anchoColumna en app.go).
	Axustes map[string]string `json:"axustes"`
}

// lerContextoLanzamento intenta ler o contexto que Piztu escribiu ao abrir
// Pancho (variable de contorno PIZTU_CONTEXTO, ver lanzarAplicacion en
// piztu/app.go). Devolve ok=false se Pancho se abriu sen pasar por
// Piztu (ex.: en desenvolvemento, executando o binario á man) — nese caso
// o informe simplemente non inclúe ningún equipo sen sesión propia.
func lerContextoLanzamento() (contextoModulo, bool) {
	var ctx contextoModulo
	ruta := os.Getenv("PIZTU_CONTEXTO")
	if ruta == "" {
		return ctx, false
	}
	dados, err := os.ReadFile(ruta)
	if err != nil {
		return ctx, false
	}
	if err := json.Unmarshal(dados, &ctx); err != nil {
		return ctx, false
	}
	return ctx, true
}
