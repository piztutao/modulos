package main

import (
	"context"
	"strconv"
	"sync"

	wailsruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// anchoColumnaDefecto/Min/Max acoutan o campo "ancho" do panel (panel.yaml):
// un valor ausente, non numérico ou fóra de rango cae no defecto en vez de
// deixar a columna inusable (demasiado estreita) ou case a pantalla enteira.
const (
	anchoColumnaDefecto = 420
	anchoColumnaMin     = 280
	anchoColumnaMax     = 900
)

// App é o núcleo de Pancho: xera un informe PDF (equipo → usuario
// conectado, ordenado por nome de equipo) e permite gardalo en disco ou
// subilo a File Browser. Módulo pequeno a propósito — sen editor, sen
// estado persistente máis alá dos axustes locais (ver settings.go).
type App struct {
	ctx      context.Context
	contexto contextoModulo
	settings Settings

	// ultimoPDF/ultimoNome gardan o último informe xerado (só en memoria,
	// nunca en disco agás que o profesor o pida explicitamente) para que
	// GardarInformeLocal/SubirInforme non teñan que rexerar o PDF.
	ultimoPDF  []byte
	ultimoNome string

	// actualizacionPancho is the last known snapshot of whether a newer
	// Pancho is published (see actualizacion.go) — checked once in the
	// background at startup, refreshed by comprobarActualizacionPancho.
	actualizacionMu     sync.Mutex
	actualizacionPancho EstadoActualizacionPancho
}

func NewApp() *App {
	return &App{}
}

func (a *App) startup(ctx context.Context) {
	a.ctx = ctx
	a.contexto, _ = lerContextoLanzamento()
	a.settings = loadSettings()
	a.posicionarColumna(ctx)
	axustarXanelaTrasArranque()
	go a.comprobarActualizacionPancho()
}

// posicionarColumna ancora a xanela de Pancho ao bordo dereito da pantalla,
// coa altura enteira — unha columna fixa a carón do mapa, non unha xanela
// solta (ver mantenPiztuAberto en modulo.json). options.App (main.go) só
// admite tamaño fixo ao arrincar; aquí recalculamos con base na resolución
// real e no ancho configurado en ⚙ Aula (ver anchoColumna).
func (a *App) posicionarColumna(ctx context.Context) {
	pantallas, err := wailsruntime.ScreenGetAll(ctx)
	if err != nil || len(pantallas) == 0 {
		return // sen info de pantalla (ex. desenvolvemento): queda co tamaño por defecto de main.go
	}
	pantalla := pantallas[0]
	for _, p := range pantallas {
		if p.IsPrimary {
			pantalla = p
			break
		}
	}
	ancho := a.anchoColumna()
	x := pantalla.Size.Width - ancho
	if x < 0 {
		x = 0
	}
	wailsruntime.WindowSetSize(ctx, ancho, pantalla.Size.Height)
	wailsruntime.WindowSetPosition(ctx, x, 0)
}

// GetIdioma devolve o código de idioma que o profesorado ten escollido en
// Piztu, ou "" se Pancho arrincou sen ese contexto (desenvolvemento,
// executable á man) — nese caso o frontend cae ao seu propio fallback (ver
// frontend/src/i18n.js).
func (a *App) GetIdioma() string {
	return a.contexto.Idioma
}

// anchoColumna devolve o ancho (en píxeles) da columna lateral, lido do
// panel de Pancho en ⚙ Aula (campo "ancho", ver panel.yaml). Caído a
// anchoColumnaDefecto se Pancho se abriu sen contexto de Piztu, ou o valor
// gardado non é un número san — nunca dá unha xanela inusable.
func (a *App) anchoColumna() int {
	v, ok := a.contexto.Axustes["ancho"]
	if !ok {
		return anchoColumnaDefecto
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return anchoColumnaDefecto
	}
	if n < anchoColumnaMin {
		return anchoColumnaMin
	}
	if n > anchoColumnaMax {
		return anchoColumnaMax
	}
	return n
}
