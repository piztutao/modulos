package main

import (
	"context"
	"fmt"
	"strconv"
	"sync"

	wailsruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// anchoColumnaDefecto/Min/Max acoutan o campo "ancho" do panel (panel.yaml):
// un valor ausente, non numérico ou fóra de rango cae no defecto en vez de
// deixar a columna inusable (demasiado estreita) ou case a pantalla enteira.
// Mesmo criterio ca Pancho (ver anchoColumna en pancho/app.go).
const (
	anchoColumnaDefecto = 420
	anchoColumnaMin     = 280
	anchoColumnaMax     = 900
)

// App garda os axustes locais de Xesta en memoria.
//
// FRONTEIRA IMPORTANTE: Xesta non importa nin depende de nada relacionado con
// Tao (sesións do alumnado, historial, File Browser) — ver a nota equivalente
// en blueprints/xesta.py, do lado de Piztu. Xesta só fala coa API /api/xesta/*.
type App struct {
	ctx      context.Context
	cfg      Config
	contexto contextoModulo
	// idioma é o código (gl/es/en/pt) que o profesorado ten escollido en ⚙ Aula
	// para o propio Piztu — aprendido do PIZTU_CONTEXTO co que Piztu lanzou este
	// proceso, "" se Xesta arrincou sen ese contexto (nese caso o frontend cae
	// ao seu propio fallback, ver GetIdioma e frontend/src/i18n/index.ts).
	// Fixado unha soa vez en startup e nunca máis: a diferenza de cando Xesta
	// era un servidor de fondo persistente reutilizado en cada apertura do
	// panel, agora é unha xanela propia con proceso novo por lanzamento (coma
	// Tao/Pancho) — un cambio de idioma en Piztu só afecta lanzamentos futuros.
	idioma string

	// actualizacion is the last known snapshot of whether a newer Xesta is
	// published (see actualizacion.go) — checked once in the background at
	// startup, refreshed by comprobarActualizacionXesta.
	actualizacionMu sync.Mutex
	actualizacion   EstadoActualizacionXesta
}

// NewApp crea a estrutura da aplicación.
func NewApp() *App {
	return &App{}
}

// startup é o hook de arranque de Wails (OnStartup, ver main.go): carga os
// axustes gardados en disco e, se Xesta se abriu dende Piztu, sobrescribe o
// socket e o token cos que Piztu acaba de emitir (ver ContextoModulo en
// piztu/app.go) — así o profesorado nunca ten que escribir nada a man (ver
// contexto.go). Un token novo en cada arranque tamén é o que fai que un
// módulo desactivado en ⚙ Aula → Módulos deixe de poder falar coa API: sen
// pasar por Piztu, non hai token novo que recibir.
func (a *App) startup(ctx context.Context) {
	a.ctx = ctx
	c, err := cargarConfig()
	if err != nil {
		c = configPadron()
	}

	contexto, ok := lerContextoLanzamento()
	if ok && contexto.APISocket != "" {
		if contexto.APISocket != c.PiztuSocketPath || contexto.APIToken != c.PiztuAPIToken {
			c.PiztuSocketPath = contexto.APISocket
			c.PiztuAPIToken = contexto.APIToken
			_ = gardarConfig(c) // así segue valendo se se reabre sen pasar por Piztu
		}
	}
	if ok {
		a.idioma = contexto.Idioma
		a.contexto = contexto
	}

	a.cfg = c
	a.posicionarColumna(ctx)
	axustarXanelaTrasArranque()
	go a.comprobarActualizacionXesta()
}

// posicionarColumna ancora a xanela de Xesta ao bordo dereito da pantalla,
// coa altura enteira — unha columna fixa a carón do mapa, non unha xanela
// solta (ver mantenPiztuAberto en modulo.json). Mesmo patrón ca Pancho (ver
// posicionarColumna en pancho/app.go): options.App (main.go) só admite
// tamaño fixo ao arrincar; aquí recalculamos con base na resolución real e
// no ancho configurado en ⚙ Aula (ver anchoColumna).
func (a *App) posicionarColumna(ctx context.Context) {
	pantallas, err := wailsruntime.ScreenGetAll(ctx)
	if err != nil || len(pantallas) == 0 {
		return // sen info de pantalla (ex. desenvolvemento): queda co tamaño por defecto de main.go
	}
	pantalla := pantallas[0]
	for _, p := range pantallas {
		if p.IsPrimary {
			pantalla = p
			break
		}
	}
	ancho := a.anchoColumna()
	x := pantalla.Size.Width - ancho
	if x < 0 {
		x = 0
	}
	wailsruntime.WindowSetSize(ctx, ancho, pantalla.Size.Height)
	wailsruntime.WindowSetPosition(ctx, x, 0)
}

// anchoColumna devolve o ancho (en píxeles) da columna lateral, lido do
// panel de Xesta en ⚙ Aula (campo "ancho", ver panel.yaml). Caído a
// anchoColumnaDefecto se Xesta se abriu sen contexto de Piztu, ou o valor
// gardado non é un número san — nunca dá unha xanela inusable.
func (a *App) anchoColumna() int {
	v, ok := a.contexto.Axustes["ancho"]
	if !ok {
		return anchoColumnaDefecto
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return anchoColumnaDefecto
	}
	if n < anchoColumnaMin {
		return anchoColumnaMin
	}
	if n > anchoColumnaMax {
		return anchoColumnaMax
	}
	return n
}

// GetConfig devolve os axustes actuais para pintar a pantalla de Axustes.
func (a *App) GetConfig() Config {
	return a.cfg
}

// GetIdioma devolve o código de idioma que o profesorado ten escollido en
// Piztu (ver campo idioma), ou "" se Xesta arrincou sen ese contexto — mesmo
// patrón ca Pancho/Yang (GetIdioma), agora que Xesta tamén é unha xanela
// propia en vez dun servidor HTTP incrustado nun iframe.
func (a *App) GetIdioma() string {
	return a.idioma
}

// SaveConfig garda novos axustes en disco e actualiza o estado en memoria.
func (a *App) SaveConfig(c Config) error {
	if err := gardarConfig(c); err != nil {
		return err
	}
	a.cfg = c
	return nil
}

// ConsultarPiztu comproba a conexión con Piztu e devolve o motor activo
// (ansible/salt) e os equipos dispoñibles na aula.
func (a *App) ConsultarPiztu() (EstadoPiztu, error) {
	if a.cfg.PiztuSocketPath == "" {
		return EstadoPiztu{}, fmt.Errorf("non se atopou o socket de Piztu — abre Xesta dende Piztu, ou fixa a ruta a man nos Axustes")
	}
	return consultarEstado(a.cfg)
}

// XerarContido pide á IA un playbook/estado a partir da petición en texto
// libre do profesorado, tras consultar a Piztu cal é o motor activo.
// imaxeBase64/imaxeMimeType son opcionais (cadea baleira = sen imaxe) —
// a imaxe chega xa en base64 dende o navegador (FileReader do frontend web);
// mantense así por simplicidade aínda que Xesta volveu ser unha app de
// escritorio (non hai selector de ficheiros nativo aínda). ficheiroNome/
// ficheiroContido son opcionais tamén — un script ou ficheiro de texto de
// apoio (ver xerarContidoIA para as garantías de seguridade).
func (a *App) XerarContido(peticion string, imaxeBase64 string, imaxeMimeType string, ficheiroNome string, ficheiroContido string) (string, error) {
	estado, err := a.ConsultarPiztu()
	if err != nil {
		return "", err
	}
	return xerarContidoIA(a.cfg, estado.Motor, estado.Equipos, peticion, imaxeBase64, imaxeMimeType, ficheiroNome, ficheiroContido)
}

// CorrixirContido pide á IA que arranxe un contido que fallou nalgún equipo,
// achegándolle a mensaxe de erro real para que poida diagnosticar o problema.
func (a *App) CorrixirContido(contidoAnterior string, mensaxeErro string) (string, error) {
	estado, err := a.ConsultarPiztu()
	if err != nil {
		return "", err
	}
	return corrixirContidoIA(a.cfg, estado.Motor, contidoAnterior, mensaxeErro)
}

// ExecutarContido envía un contido (xerado pola IA, ou editado a man) a
// Piztu para que o execute nos equipos indicados (lista baleira = toda a aula).
func (a *App) ExecutarContido(contido string, destinos []string) (ResultadoExecucion, error) {
	if a.cfg.PiztuSocketPath == "" {
		return ResultadoExecucion{}, fmt.Errorf("non se atopou o socket de Piztu — abre Xesta dende Piztu, ou fixa a ruta a man nos Axustes")
	}
	return executarContido(a.cfg, contido, destinos)
}

// ListarBiblioteca devolve os scripts que o profesorado gardou localmente
// (ver biblioteca.go) — nada disto sae desta máquina.
func (a *App) ListarBiblioteca() ([]ScriptGardado, error) {
	return listarBiblioteca()
}

// GardarEnBiblioteca conserva un script xa comprobado na biblioteca persoal,
// xunto co prompt orixinal e o ficheiro/script de apoio (se os houbo) —
// así "Usar" pode restauralo todo, cada peza no seu sitio (ver ScriptGardado).
func (a *App) GardarEnBiblioteca(nome, descricion, motor, peticion, contido, ficheiroNome, ficheiroContido string) (ScriptGardado, error) {
	return gardarNaBiblioteca(nome, descricion, motor, peticion, contido, ficheiroNome, ficheiroContido)
}

// EliminarDaBiblioteca quita un script gardado polo seu ID.
func (a *App) EliminarDaBiblioteca(id string) error {
	return eliminarDaBiblioteca(id)
}
