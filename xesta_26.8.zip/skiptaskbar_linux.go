//go:build linux

// axustarXanelaTrasArranque (neste ficheiro) pídelle a GTK que agoche a
// xanela de Xesta da barra de tarefas/dock do sistema E que se poña en
// primeiro plano. Wails v2 non ofrece nin unha cousa nin outra en
// options/linux.Options, así que a única vía é pedirllo directamente a GTK:
// gtk_window_set_skip_taskbar_hint/skip_pager_hint e presentar a xanela
// (ver posicionarColumna en app.go). Copia case literal de
// pancho/skiptaskbar_linux.go — mesmo problema, mesma solución.
//
// As dúas cousas van xuntas a propósito: sen icona na barra de tarefas xa
// non hai forma de premer para traer a xanela ao primeiro plano coma antes
// (así se detectou o bug orixinal en Pancho — a xanela abría detrás de
// Piztu, sen foco, e só se via premendo na súa icona do sistema) — así que
// hai que presentala nós mesmos no arranque.
//
// gtk_window_present() a secas (sen timestamp) non abondaba: en xestores de
// xanelas con prevención de "roubo de foco" (KWin, o de KDE Plasma) un
// present() sen selo de tempo válido interprétase coma un intento non
// lexítimo de roubar o foco e o xestor simplemente ignora a petición — a
// xanela nin sequera se ve, porque tamén lle quitamos a icona da barra de
// tarefas (enriba). A solución estándar en X11 é pedirlle ao propio
// servidor un timestamp real (gdk_x11_get_server_time) e usalo con
// gtk_window_present_with_time — iso si o admiten as políticas anti-roubo
// de foco. Coma reforzo (por se aínda así o xestor de xanelas non move a
// xanela ao primeiro plano), tamén se acende e apaga
// gtk_window_set_keep_above nun intre: iso obriga a reordenala por riba sen
// deixala fixada para sempre.
//
// A #cgo desta liña abaixo liga contra gtk+-3.0, a mesma versión que xa usa
// o propio Wails v2 en Linux — non engade ningunha dependencia de sistema
// nova, xa é obrigatoria para compilar calquera app Wails v2 en Linux.
package main

/*
#cgo pkg-config: gtk+-3.0

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <stdlib.h>

#ifdef GDK_WINDOWING_X11
#include <gdk/gdkx.h>
#endif

extern gboolean xestaAxustarCallback(void *data);

// xestaAgendarAxuste programa xestaAxustarCallback para executarse no fío
// principal de GTK (o que corre gtk_main()) — g_idle_add é seguro de chamar
// dende calquera fío, a diferenza do resto da API de GTK. Mesmo patrón que
// usa o propio Wails en invoke.go (invokeOnMainThread).
static inline void xestaAgendarAxuste() {
    g_idle_add((GSourceFunc)xestaAxustarCallback, NULL);
}

// xestaPresentar eleva e enfoca a xanela cun timestamp real do servidor X
// cando é posible (ver nota de arriba sobre a prevención de roubo de foco);
// se non está en X11 (ou o backend non o soporta) cae en present() a secas,
// coma antes. O keep_above on/off é un empurrón extra: forza a reordenar a
// xanela por riba sen fixala para sempre.
static void xestaPresentar(GtkWindow *xanela) {
    guint32 marca = GDK_CURRENT_TIME;
#ifdef GDK_WINDOWING_X11
    GdkWindow *gdkxanela = gtk_widget_get_window(GTK_WIDGET(xanela));
    if (gdkxanela != NULL && GDK_IS_X11_WINDOW(gdkxanela)) {
        marca = gdk_x11_get_server_time(gdkxanela);
    }
#endif
    gtk_window_set_keep_above(xanela, TRUE);
    gtk_window_present_with_time(xanela, marca);
    gtk_window_set_keep_above(xanela, FALSE);
}

// xestaAxustarToplevels percorre as xanelas de nivel superior de GTK e, na
// que teña o título de Xesta (ver Title en main.go), agóchaa da barra de
// tarefas/paxinador e presenta (eleva e enfoca). Só debería haber unha —
// Xesta é unha app dunha soa xanela — pero compróbase o título por
// seguridade en vez de tocalas todas ás cegas.
static void xestaAxustarToplevels(const char *titulo) {
    GList *xanelas = gtk_window_list_toplevels();
    for (GList *it = xanelas; it != NULL; it = it->next) {
        GtkWindow *xanela = GTK_WINDOW(it->data);
        const gchar *t = gtk_window_get_title(xanela);
        if (t != NULL && titulo != NULL && g_strcmp0(t, titulo) == 0) {
            gtk_window_set_skip_taskbar_hint(xanela, TRUE);
            gtk_window_set_skip_pager_hint(xanela, TRUE);
            xestaPresentar(xanela);
        }
    }
    g_list_free(xanelas);
}
*/
import "C"

import "unsafe"

//export xestaAxustarCallback
func xestaAxustarCallback(_ unsafe.Pointer) C.gboolean {
	titulo := C.CString("Xesta")
	defer C.free(unsafe.Pointer(titulo))
	C.xestaAxustarToplevels(titulo)
	return C.G_SOURCE_REMOVE
}

// axustarXanelaTrasArranque chámase dende startup() (app.go). Non se pode
// chamar a GTK directamente dende a goroutine de OnStartup — só é seguro
// dende o fío que corre gtk_main() — así que isto só agenda o traballo.
func axustarXanelaTrasArranque() {
	C.xestaAgendarAxuste()
}
