//go:build !linux

package main

// axustarXanelaTrasArranque non fai nada fóra de Linux — ver skiptaskbar_linux.go.
func axustarXanelaTrasArranque() {}
