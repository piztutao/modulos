// Cliente para a API local de Xesta — agora as bindings nativas que Wails
// xera para App (ver ../wailsjs/go/main/App), non fetch(). Xesta volveu ser
// unha app de escritorio propia (xanela, non un servidor HTTP incrustado
// nun <iframe>): JS chama Go directamente pola ponte do webview, sen porto
// nin socket que outro proceso local puidese tocar (mesmo patrón ca
// Pancho/Tao). Este ficheiro só reexpón esas bindings cos mesmos nomes e
// formas que xa usaban App.tsx/Sobre.tsx, para non ter que tocalos.
import * as go from '../wailsjs/go/main/App'

export interface Config {
    piztu_socket_path: string
    // piztu_api_token nunca se amosa nin edita na UI de Axustes (App.tsx só
    // le/escribe piztu_socket_path/gemini_*) — vai aquí só para que o obxecto
    // que se manda de volta a SaveConfig leve o mesmo valor que se recibiu de
    // GetConfig, en vez de baleiralo por omisión.
    piztu_api_token: string
    gemini_api_key: string
    gemini_model: string
}

export interface EstadoPiztu {
    motor: string
    equipos: string[]
}

export interface ResultadoHost {
    estado: string
    msg?: string
}

export interface ResultadoExecucion {
    motor: string
    resultados: Record<string, ResultadoHost>
}

export interface ScriptGardado {
    id: string
    nome: string
    descricion: string
    motor: string
    peticion?: string
    contido: string
    ficheiro_nome?: string
    ficheiro_contido?: string
    gardado: string // data ISO
}

export function getConfig(): Promise<Config> {
    return go.GetConfig()
}

export function saveConfig(cfg: Config): Promise<void> {
    return go.SaveConfig(cfg)
}

export function consultarPiztu(): Promise<EstadoPiztu> {
    return go.ConsultarPiztu()
}

// obterIdioma devolve o código de idioma (gl/es/en/pt) que o profesorado ten
// escollido en ⚙ Aula de Piztu, ou "" se Xesta arrincou sen ese contexto —
// ver i18n/index.ts. Empaquetado en {idioma} por compatibilidade co chamador
// existente (a binding en si devolve a cadea soa, ver GetIdioma en app.go).
export async function obterIdioma(): Promise<{ idioma: string }> {
    return {idioma: await go.GetIdioma()}
}

export interface EstadoActualizacion {
    disponible: boolean
    version_local: string
    version_remota: string
    notas: string
}

export function getActualizacion(): Promise<EstadoActualizacion> {
    return go.GetActualizacionXesta()
}

export function aplicarActualizacion(): Promise<void> {
    return go.AplicarActualizacionXesta()
}

export function xerarContido(
    peticion: string,
    imaxeBase64: string,
    imaxeMimeType: string,
    ficheiroNome: string = '',
    ficheiroContido: string = '',
): Promise<string> {
    return go.XerarContido(peticion, imaxeBase64, imaxeMimeType, ficheiroNome, ficheiroContido)
}

export function corrixirContido(contidoAnterior: string, mensaxeErro: string): Promise<string> {
    return go.CorrixirContido(contidoAnterior, mensaxeErro)
}

export function executarContido(contido: string, destinos: string[]): Promise<ResultadoExecucion> {
    return go.ExecutarContido(contido, destinos)
}

export function listarBiblioteca(): Promise<ScriptGardado[]> {
    return go.ListarBiblioteca()
}

export function gardarEnBiblioteca(
    nome: string,
    descricion: string,
    motor: string,
    peticion: string,
    contido: string,
    ficheiroNome: string = '',
    ficheiroContido: string = '',
): Promise<ScriptGardado> {
    return go.GardarEnBiblioteca(nome, descricion, motor, peticion, contido, ficheiroNome, ficheiroContido)
}

export function eliminarDaBiblioteca(id: string): Promise<void> {
    return go.EliminarDaBiblioteca(id)
}
