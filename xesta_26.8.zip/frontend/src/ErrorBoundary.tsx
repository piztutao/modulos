import React from 'react'
import i18n from './i18n'

interface Props {
    children: React.ReactNode
}

interface State {
    erro: Error | null
}

// Sen isto, un erro de render calquera (coma o de biblioteca.length sobre
// null que motivou este ficheiro) deixa o <iframe> en branco para sempre: o
// panel de Piztu que o mostra só recarga a URL se cambia (ver main.js →
// btn-xesta), e a URL de Xesta é sempre a mesma (porto fixo), así que pechar
// e reabrir o panel non serve de nada — queda "conxelado" na mesma páxina
// crashada ata que se reinicia Piztu enteiro.
//
// Este ErrorBoundary captura calquera erro de render dos compoñentes fillos
// e ofrece un botón para recargar só o documento de Xesta (window.location
// .reload() recarga o iframe, non toda a xanela de Piztu) — sen tocar nada
// en Piztu nin depender do seu comportamento de caché do iframe.
export default class ErrorBoundary extends React.Component<Props, State> {
    state: State = {erro: null}

    static getDerivedStateFromError(erro: Error): State {
        return {erro}
    }

    componentDidCatch(erro: Error, info: React.ErrorInfo) {
        console.error('[Xesta] erro non capturado:', erro, info.componentStack)
    }

    render() {
        if (this.state.erro) {
            return (
                <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-stone-50 p-6 text-center">
                    <p className="text-lg font-medium text-stone-900">{i18n.t('errorBoundary.titulo')}</p>
                    <p className="max-w-md text-sm text-stone-500">{this.state.erro.message}</p>
                    <button
                        className="rounded-md bg-stone-900 px-4 py-2 text-sm font-medium text-white"
                        onClick={() => window.location.reload()}
                    >
                        {i18n.t('errorBoundary.recargar')}
                    </button>
                </div>
            )
        }
        return this.props.children
    }
}
