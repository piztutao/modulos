// i18n/index.ts — Configuración de i18next para Xesta.
//
// Xesta é unha app Wails propia (xanela, proceso novo por lanzamento — ver
// api.ts): o idioma que Piztu ten escollido chega pola ponte JS↔Go nativa
// (GetIdioma, ver app.go), mesmo patrón ca Tao/Pancho. Mesmo criterio de
// prioridade ca Tao: unha elección explícita real (CLAVE_EXPLICITA, hoxe sen
// selector propio que a escriba) gañaría sobre o de Piztu; o de Piztu gaña
// sobre o do navegador en calquera outro caso.
import i18n from 'i18next'
import {initReactI18next} from 'react-i18next'
import LanguageDetector from 'i18next-browser-languagedetector'

import gl from './locales/gl.json'
import es from './locales/es.json'
import en from './locales/en.json'
import pt from './locales/pt.json'

import {obterIdioma} from '../api'

export const IDIOMAS_DISPONIBLES = [
    {code: 'gl', nome: 'Galego'},
    {code: 'es', nome: 'Castellano'},
    {code: 'en', nome: 'English'},
    {code: 'pt', nome: 'Português'},
] as const

const CLAVE_LOCALSTORAGE = 'xesta_idioma'

// CLAVE_EXPLICITA marcaría unha elección real feita a man en Xesta — hoxe
// Xesta NON ten selector de idioma propio na UI (a diferenza de Tao), así
// que nada escribe esta chave aínda; queda preparada para cando exista un.
// Sen ela, o único que se podía mirar era CLAVE_LOCALSTORAGE, que
// LanguageDetector escribe en CALQUERA cambio de idioma (autodetección do
// navegador, ou o propio idioma de Piztu aplicado nun arranque anterior) —
// non só cando alguén escolle algo a propósito. Iso facía que o idioma de
// Piztu só se aplicase a primeira vez que arrincaba Xesta e nunca máis,
// aínda que o profesorado cambiase o idioma de Piztu despois.
const CLAVE_EXPLICITA = 'xesta_idioma_explicito'

// marcarIdiomaExplicito rexistra unha elección real de idioma feita a man en
// Xesta. Chamar SÓ dende un futuro selector propio, nunca dende código que
// aplica un valor por defecto.
export function marcarIdiomaExplicito(): void {
    localStorage.setItem(CLAVE_EXPLICITA, '1')
}

i18n
    .use(LanguageDetector)
    .use(initReactI18next)
    .init({
        resources: {
            gl: {translation: gl},
            es: {translation: es},
            en: {translation: en},
            pt: {translation: pt},
        },
        fallbackLng: 'gl',
        supportedLngs: ['gl', 'es', 'en', 'pt'],
        interpolation: {escapeValue: false},
        detection: {
            order: ['localStorage', 'navigator'],
            caches: ['localStorage'],
            lookupLocalStorage: CLAVE_LOCALSTORAGE,
        },
    })

export default i18n

// aplicarIdiomaPiztuPorDefecto consulta GetIdioma() e, SO SE ninguén fixo
// unha elección real en Xesta (CLAVE_EXPLICITA — non CLAVE_LOCALSTORAGE, que
// tamén se escribe por autodetección ou por un arranque anterior seguindo a
// Piztu, ver nota en CLAVE_EXPLICITA), aplícao. Chámase en CADA arranque de
// Xesta, non só o primeiro: se o profesorado cambia o idioma de Piztu,
// Xesta debe reflectilo a próxima vez que se abra (proceso novo por
// lanzamento, coma Tao/Pancho — non hai aviso en quente se xa está aberto,
// ver escribirContexto en piztu/app.go). Chámase unha soa vez por carga de
// páxina, en main.tsx, ANTES do primeiro render, para evitar un flash
// (arrincar nun idioma e trocar decontado a outro).
//
// Tolerante de máis a fallos a propósito: sen contexto de Piztu (Xesta
// arrincado á man, desenvolvemento) GetIdioma() devolve "", e calquera fallo
// da chamada simplemente non cambia nada — o idioma xa detectado
// (localStorage/navegador) segue a valer.
export async function aplicarIdiomaPiztuPorDefecto(): Promise<void> {
    if (localStorage.getItem(CLAVE_EXPLICITA)) {
        return
    }
    try {
        const {idioma} = await obterIdioma()
        const codigo = idioma.trim()
        if (codigo && IDIOMAS_DISPONIBLES.some((d) => d.code === codigo)) {
            await i18n.changeLanguage(codigo)
        }
    } catch {
        // Sen contexto de Piztu ou API non dispoñible: queda o idioma xa detectado.
    }
}
