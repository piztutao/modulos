import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import ErrorBoundary from './ErrorBoundary'
import './index.css'
import {aplicarIdiomaPiztuPorDefecto} from './i18n'

// Agarda a aplicar o idioma de Piztu (se toca, ver i18n/index.ts) ANTES do
// primeiro render, para non amosar un flash no idioma detectado do
// navegador e trocar decontado ao de Piztu.
aplicarIdiomaPiztuPorDefecto().finally(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <ErrorBoundary>
        <App/>
      </ErrorBoundary>
    </React.StrictMode>,
  )
})
