import {useEffect, useState} from 'react'
import {useTranslation} from 'react-i18next'
import xestaLogo from './assets/xesta-logo.png'
import {aplicarActualizacion, EstadoActualizacion, getActualizacion} from './api'

// SobreXesta ("i" da cabeceira) — versión, licenza GPLv3 e autoactualización
// (ver actualizacion.go). Aplicar a actualización só substitúe o executable
// en disco, NON reinicia Xesta soa (mesmo criterio ca AplicarActualizacionXesta,
// ver actualizacion.go) — pídeselle ao profesorado que peche e reabra Xesta
// dende Piztu para usar a versión nova.
interface Props {
    onClose: () => void
}

export default function SobreXesta({onClose}: Props) {
    const {t} = useTranslation()
    const [estado, setEstado] = useState<EstadoActualizacion | null>(null)
    const [actualizando, setActualizando] = useState(false)
    const [feito, setFeito] = useState(false)
    const [erro, setErro] = useState('')

    useEffect(() => {
        getActualizacion().then(setEstado).catch(() => {
        })
    }, [])

    const dispo = !!(estado && estado.disponible)

    const handleActualizar = async () => {
        if (!confirm(t('sobre.actualizarConfirmar'))) return
        setActualizando(true)
        setErro('')
        try {
            await aplicarActualizacion()
            setFeito(true)
        } catch (e: any) {
            setErro(e?.message || String(e))
        } finally {
            setActualizando(false)
        }
    }

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col">
                <div className="flex items-center justify-between px-4 py-3 border-b border-stone-200">
                    <span className="font-bold text-stone-800">{t('sobre.titulo')}</span>
                    <button onClick={onClose} className="p-1 rounded hover:bg-stone-100 text-stone-500">✕</button>
                </div>
                <div className="flex flex-col items-center gap-1.5 px-6 py-5 text-center text-sm text-stone-600">
                    <img src={xestaLogo} alt="Xesta" className="w-16 h-16 object-contain mb-1 rounded"/>
                    <p className="text-stone-800 font-medium">{t('sobre.version')} {estado?.version_local || ''}</p>

                    {feito ? (
                        <p className="text-emerald-700 font-semibold">{t('sobre.actualizadoPecha')}</p>
                    ) : dispo && (
                        <>
                            <p className="text-amber-700 font-semibold">
                                {t('sobre.novaversion', {v: estado?.version_remota})}
                            </p>
                            <button onClick={handleActualizar} disabled={actualizando}
                                    className="mt-1 px-3 py-1.5 text-sm bg-amber-500 hover:bg-amber-600 text-white font-medium rounded-lg transition-colors disabled:opacity-50">
                                {actualizando ? t('sobre.actualizando') : t('sobre.actualizar')}
                            </button>
                        </>
                    )}
                    {erro && <p className="text-xs text-red-600">{erro}</p>}

                    <p className="mt-2">{t('sobre.autor')}</p>
                    <p><a href="https://piztu.org" target="_blank" rel="noreferrer"
                          className="text-indigo-600 underline">piztu.org</a></p>
                    <p>{t('sobre.contacto')}</p>
                    <p className="font-semibold mt-2">{t('sobre.licenza')}</p>
                    <p className="text-xs text-stone-500 whitespace-pre-line">{t('sobre.licdesc')}</p>
                </div>
            </div>
        </div>
    )
}
