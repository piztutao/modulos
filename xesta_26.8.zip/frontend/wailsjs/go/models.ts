export namespace main {
	
	export class Config {
	    piztu_socket_path: string;
	    piztu_api_token: string;
	    gemini_api_key: string;
	    gemini_model: string;
	
	    static createFrom(source: any = {}) {
	        return new Config(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.piztu_socket_path = source["piztu_socket_path"];
	        this.piztu_api_token = source["piztu_api_token"];
	        this.gemini_api_key = source["gemini_api_key"];
	        this.gemini_model = source["gemini_model"];
	    }
	}
	export class EstadoActualizacionXesta {
	    disponible: boolean;
	    version_local: string;
	    version_remota: string;
	    url_descarga: string;
	    url_checksum: string;
	    notas: string;
	
	    static createFrom(source: any = {}) {
	        return new EstadoActualizacionXesta(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.disponible = source["disponible"];
	        this.version_local = source["version_local"];
	        this.version_remota = source["version_remota"];
	        this.url_descarga = source["url_descarga"];
	        this.url_checksum = source["url_checksum"];
	        this.notas = source["notas"];
	    }
	}
	export class ScriptGardado {
	    id: string;
	    nome: string;
	    descricion: string;
	    motor: string;
	    peticion?: string;
	    contido: string;
	    ficheiro_nome?: string;
	    ficheiro_contido?: string;
	    // Go type: time
	    gardado: any;
	
	    static createFrom(source: any = {}) {
	        return new ScriptGardado(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.id = source["id"];
	        this.nome = source["nome"];
	        this.descricion = source["descricion"];
	        this.motor = source["motor"];
	        this.peticion = source["peticion"];
	        this.contido = source["contido"];
	        this.ficheiro_nome = source["ficheiro_nome"];
	        this.ficheiro_contido = source["ficheiro_contido"];
	        this.gardado = this.convertValues(source["gardado"], null);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}

}

export namespace piztuclient {
	
	export class EstadoMotor {
	    motor: string;
	    equipos: string[];
	
	    static createFrom(source: any = {}) {
	        return new EstadoMotor(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.motor = source["motor"];
	        this.equipos = source["equipos"];
	    }
	}
	export class ResultadoHost {
	    estado: string;
	    msg?: string;
	
	    static createFrom(source: any = {}) {
	        return new ResultadoHost(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.estado = source["estado"];
	        this.msg = source["msg"];
	    }
	}
	export class ResultadoExecucion {
	    motor: string;
	    resultados: Record<string, ResultadoHost>;
	
	    static createFrom(source: any = {}) {
	        return new ResultadoExecucion(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.motor = source["motor"];
	        this.resultados = this.convertValues(source["resultados"], ResultadoHost, true);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}

}

