package main

import (
	"context"

	"piztuclient"
)

// Alias directos aos tipos do SDK: as formas JSON son as mesmas que xa
// esperaba o resto de Xesta (frontend incluído), así que non fai falla
// redefinilas nin traducir entre unhas e outras.
type (
	EstadoPiztu        = piztuclient.EstadoMotor
	ResultadoHost      = piztuclient.ResultadoHost
	ResultadoExecucion = piztuclient.ResultadoExecucion
)

// cliente constrúe un piztuclient.Cliente cos axustes actuais (socket +
// token). Sen estado propio máis alá diso — un cliente novo por chamada é
// abondo barato e evita ter que invalidalo cando cfg cambia (ver SaveConfig).
func cliente(cfg Config) *piztuclient.Cliente {
	return piztuclient.Novo(cfg.PiztuSocketPath, cfg.PiztuAPIToken)
}

func consultarEstado(cfg Config) (EstadoPiztu, error) {
	return cliente(cfg).MotorEstado(context.Background())
}

func executarContido(cfg Config, contido string, destinos []string) (ResultadoExecucion, error) {
	return cliente(cfg).MotorExecutar(context.Background(), contido, destinos)
}
