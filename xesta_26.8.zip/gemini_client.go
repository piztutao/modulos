package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

// Chamada REST directa á API de Google Gemini — sen SDK externo, para non
// depender dun paquete de terceiros só para isto. O nome do modelo é
// configurable nos Axustes (ex.: "gemini-flash-latest"; consulta a lista
// actual de modelos en ai.google.dev, os nomes cambian coa versión).
const geminiEndpointFmt = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"

type geminiPeticion struct {
	SystemInstruction *geminiContido  `json:"systemInstruction,omitempty"`
	Contents          []geminiContido `json:"contents"`
}

type geminiContido struct {
	Role  string        `json:"role,omitempty"`
	Parts []geminiParte `json:"parts"`
}

// geminiParte é ou ben texto ou ben unha imaxe en base64 (inlineData) —
// nunca os dous á vez neste código, aínda que a API admite mesturalos
// dentro do mesmo array de Parts (é o que facemos para texto+imaxe xuntos).
type geminiParte struct {
	Text       string            `json:"text,omitempty"`
	InlineData *geminiInlineData `json:"inlineData,omitempty"`
}

type geminiInlineData struct {
	MimeType string `json:"mimeType"`
	Data     string `json:"data"` // base64, SEN o prefixo "data:...;base64,"
}

type geminiResposta struct {
	Candidates []struct {
		Content geminiContido `json:"content"`
	} `json:"candidates"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

var geminiClient = &http.Client{Timeout: 90 * time.Second}

// xerarContidoIA pide á IA un playbook Ansible (YAML) ou estado Salt (.sls)
// que cumpra a petición do profesorado, adaptado ao motor activo en Piztu.
// imaxeBase64/imaxeMimeType son opcionais (cadea baleira = sen imaxe): unha
// captura de pantalla ou foto que apoie a petición en texto, para que a IA
// teña máis contexto e xere unha instrución máis precisa.
//
// ficheiroNome/ficheiroContido son opcionais tamén (cadea baleira = sen
// ficheiro): un script ou ficheiro de texto que o profesorado quere que se
// despregue/execute nos equipos. A diferenza da imaxe, NON vai coma
// inlineData binario — métese coma texto plano, delimitado, dentro da
// mesma conversa. Así o seu contido remata sempre, literal, dentro do
// playbook/estado que a IA xera (ver instruccionsSistema), e o profesorado
// pode revisalo enteiro antes de executar — nunca se envía nin se executa
// nada que non pase por esa revisión.
func xerarContidoIA(cfg Config, motor string, equipos []string, peticion string, imaxeBase64 string, imaxeMimeType string, ficheiroNome string, ficheiroContido string) (string, error) {
	partes := []geminiParte{{Text: peticion}}
	if imaxeBase64 != "" {
		partes = append(partes, geminiParte{
			InlineData: &geminiInlineData{MimeType: imaxeMimeType, Data: imaxeBase64},
		})
	}
	if ficheiroContido != "" {
		partes = append(partes, geminiParte{
			Text: fmt.Sprintf("--- FICHEIRO ADXUNTO: %s ---\n%s\n--- FIN DO FICHEIRO ---", ficheiroNome, ficheiroContido),
		})
	}
	return chamarGemini(cfg, instruccionsSistema(motor, equipos), partes)
}

// corrixirContidoIA pide á IA que arranxe un contido que fallou nalgún
// equipo, achegándolle o erro real devolto por Ansible/Salt.
func corrixirContidoIA(cfg Config, motor string, contidoAnterior string, mensaxeErro string) (string, error) {
	peticion := fmt.Sprintf(
		"Este contido fallou ao executarse. Corríxeo para que funcione, mantendo o obxectivo orixinal. "+
			"Devolve de novo SÓ o contido completo corrixido.\n\n"+
			"--- CONTIDO ANTERIOR ---\n%s\n\n--- ERRO DEVOLTO ---\n%s\n",
		contidoAnterior, mensaxeErro,
	)
	return chamarGemini(cfg, instruccionsSistema(motor, nil), []geminiParte{{Text: peticion}})
}

func chamarGemini(cfg Config, sistema string, partesUsuario []geminiParte) (string, error) {
	if cfg.GeminiAPIKey == "" {
		return "", fmt.Errorf("falta a clave da API de IA (configúraa nos Axustes)")
	}
	if cfg.GeminiModel == "" {
		return "", fmt.Errorf("falta o modelo de IA (configúrao nos Axustes)")
	}

	corpo := geminiPeticion{
		// OLLO: a API de Gemini rexeita a petición enteira (400 "invalid
		// argument", sen máis detalle) se systemInstruction non leva "role"
		// — aínda que os exemplos oficiais ás veces o omiten. Comprobado
		// empiricamente contra a API real.
		SystemInstruction: &geminiContido{Role: "user", Parts: []geminiParte{{Text: sistema}}},
		Contents: []geminiContido{
			{Role: "user", Parts: partesUsuario},
		},
	}
	dados, err := json.Marshal(corpo)
	if err != nil {
		return "", err
	}

	url := fmt.Sprintf(geminiEndpointFmt, cfg.GeminiModel)
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(dados))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-goog-api-key", cfg.GeminiAPIKey)

	resp, err := geminiClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("non se puido contactar coa IA: %w", err)
	}
	defer resp.Body.Close()

	corpoResposta, _ := io.ReadAll(resp.Body)
	var r geminiResposta
	if err := json.Unmarshal(corpoResposta, &r); err != nil {
		return "", fmt.Errorf("resposta non válida da IA (HTTP %d)", resp.StatusCode)
	}
	if r.Error != nil {
		return "", fmt.Errorf("erro da IA: %s", r.Error.Message)
	}
	if resp.StatusCode != http.StatusOK || len(r.Candidates) == 0 || len(r.Candidates[0].Content.Parts) == 0 {
		return "", fmt.Errorf("a IA non devolveu resultado (HTTP %d)", resp.StatusCode)
	}

	return limparValadosMarkdown(r.Candidates[0].Content.Parts[0].Text), nil
}

func instruccionsSistema(motor string, equipos []string) string {
	var b strings.Builder
	b.WriteString("Es un axudante que xera automatizacións para unha aula de informática Linux xestionada con Piztu.\n")
	b.WriteString(fmt.Sprintf("O motor de execución activo é %q. Xera EXCLUSIVAMENTE %s.\n", motor, formatoPorMotor(motor)))
	b.WriteString("Regras estritas:\n")
	b.WriteString("- Devolve SÓ o contido do ficheiro, sen explicacións, sen marcado Markdown (nada de ``` ao redor).\n")
	b.WriteString("- Non incluas contrasinais nin datos persoais.\n")
	b.WriteString("- Usa privilexios de administrador (become/root) só cando a tarefa realmente o precise.\n")
	b.WriteString("- Se se achega unha imaxe (captura de pantalla, mensaxe de erro, etc.), úsaa coma contexto " +
		"visual para entender mellor e con menos ambigüidade que se pide — pero o resultado segue sendo SÓ o " +
		"contido do playbook/estado, nunca unha descrición da imaxe.\n")
	b.WriteString("- Se se achega un FICHEIRO ADXUNTO (marcado entre '--- FICHEIRO ADXUNTO: <nome> ---' e " +
		"'--- FIN DO FICHEIRO ---') e a petición pide despregalo ou executalo nos equipos, incorpora o seu " +
		"contido EXACTO e LITERAL (sen alteralo, resumilo nin corrixilo) nunha tarefa axeitada do " +
		"playbook/estado para copialo aos equipos e executalo (p.ex. módulo 'copy'/'file.managed' co " +
		"contido, seguido de 'command'/'cmd.run' cos permisos mínimos necesarios). O ficheiro adxunto ten " +
		"que quedar sempre visible, literal, dentro do resultado — nunca opaco nin resumido.\n")
	if len(equipos) > 0 {
		b.WriteString(fmt.Sprintf("- Hai %d equipo(s) na aula; o contido aplicarase a todos ou a un subconxunto deles, non fai falla nomealos.\n", len(equipos)))
	}
	return b.String()
}

func formatoPorMotor(motor string) string {
	if motor == "salt" {
		return "un ESTADO de SaltStack en formato .sls válido (un dicionario YAML de estados, SEN 'hosts' nin 'tasks' ao estilo Ansible)"
	}
	return "un PLAYBOOK de Ansible en YAML válido (unha LISTA cunha ou máis 'plays', cada unha con 'hosts: all' e 'tasks')"
}

// limparValadosMarkdown quita un posible cerco ```yaml ... ``` que a IA
// engada malia que llo pedimos explicitamente que non o faga.
func limparValadosMarkdown(texto string) string {
	t := strings.TrimSpace(texto)
	if strings.HasPrefix(t, "```") {
		primeiraLiña := strings.IndexByte(t, '\n')
		if primeiraLiña != -1 {
			t = t[primeiraLiña+1:]
		}
		t = strings.TrimSuffix(strings.TrimSpace(t), "```")
	}
	return strings.TrimSpace(t)
}
