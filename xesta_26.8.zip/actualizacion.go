package main

// Autoactualización do propio Xesta, mesmo mecanismo ca Piztu/Tao/Yang
// (ver piztu/internal/actualizacion/actualizacion.go e
// yang/actualizacion.go, dos que este ficheiro é unha adaptación directa).
//
// A versión instalada lese do ficheiro VERSION embebido na raíz deste
// módulo. A versión publicada consúltase no repositorio compartido de
// módulos de Piztu, piztutao/modulos — cada publicación de Xesta crea a súa
// propia Release co tag prefixado "xesta-<versión>". Percórrense TODAS as
// Releases (máis recentes primeiro) ata atopar a primeira que traia un
// asset "xesta_<versión>.zip" — a versión remota parséase dese NOME DE
// ASSET. A Release tamén ten que publicar "<nome-do-zip>.sha256",
// verificado antes de instalar nada.
//
// AplicarActualizacionXesta só substitúe o executable en disco, NON reinicia
// o proceso en marcha (mesmo criterio ca outros módulos con xanela propia,
// ver Sobre.tsx): o profesorado ten que pechar e volver abrir Xesta dende
// Piztu para usar a versión nova.
import (
	"archive/zip"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
)

//go:embed VERSION
var versionXestaFicheiro string

const repoXestaActualizacion = "piztutao/modulos"
const urlReleasesXesta = "https://api.github.com/repos/" + repoXestaActualizacion + "/releases?per_page=100"
const timeoutComprobarXesta = 5 * time.Second
const timeoutDescargaXesta = 60 * time.Second

// EstadoActualizacionXesta é o resultado de comprobar unha actualización de
// Xesta — snake_case en JSON, mesma convención ca Config (config.go), a
// diferenza do camelCase que usan Tao/Yang/Piztu.
type EstadoActualizacionXesta struct {
	Disponible    bool   `json:"disponible"`
	VersionLocal  string `json:"version_local"`
	VersionRemota string `json:"version_remota"`
	URLDescarga   string `json:"url_descarga"`
	URLChecksum   string `json:"url_checksum"`
	Notas         string `json:"notas"`
}

type assetGitHubXesta struct {
	Name               string `json:"name"`
	BrowserDownloadURL string `json:"browser_download_url"`
}

type releaseGitHubXesta struct {
	TagName string             `json:"tag_name"`
	Body    string             `json:"body"`
	Assets  []assetGitHubXesta `json:"assets"`
}

func escollerAssetsXesta(assets []assetGitHubXesta) (urlZip, nomeZip, urlChecksum string) {
	for _, a := range assets {
		nome := strings.ToLower(a.Name)
		if strings.HasPrefix(nome, "xesta_") && strings.HasSuffix(nome, ".zip") {
			urlZip = a.BrowserDownloadURL
			nomeZip = a.Name
			break
		}
	}
	if urlZip == "" {
		return "", "", ""
	}
	for _, a := range assets {
		if strings.EqualFold(a.Name, nomeZip+".sha256") {
			urlChecksum = a.BrowserDownloadURL
			break
		}
	}
	return urlZip, nomeZip, urlChecksum
}

func versionDesdeNomeZipXesta(nomeZip string) string {
	nome := strings.ToLower(nomeZip)
	nome = strings.TrimPrefix(nome, "xesta_")
	nome = strings.TrimSuffix(nome, ".zip")
	return strings.TrimSpace(nome)
}

func partesVersionXesta(v string) ([]int, bool) {
	v = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(v), "v"))
	if v == "" {
		return nil, false
	}
	anacos := strings.Split(v, ".")
	partes := make([]int, 0, len(anacos))
	for _, a := range anacos {
		n, err := strconv.Atoi(strings.TrimSpace(a))
		if err != nil {
			return nil, false
		}
		partes = append(partes, n)
	}
	return partes, true
}

func versionMaiorXesta(remota, local string) bool {
	r, okR := partesVersionXesta(remota)
	if !okR {
		return false
	}
	l, okL := partesVersionXesta(local)
	if !okL {
		l = []int{0}
	}
	for i := 0; i < len(r) || i < len(l); i++ {
		var rv, lv int
		if i < len(r) {
			rv = r[i]
		}
		if i < len(l) {
			lv = l[i]
		}
		if rv != lv {
			return rv > lv
		}
	}
	return false
}

// VersionLocalXesta devolve a versión instalada de Xesta.
func VersionLocalXesta() string {
	return strings.TrimSpace(versionXestaFicheiro)
}

// GetActualizacionXesta devolve a última foto de se hai actualización de
// Xesta dispoñible, sen tocar a rede — servido en GET /api/actualizacion
// (← botón "i" do frontend).
func (a *App) GetActualizacionXesta() EstadoActualizacionXesta {
	a.actualizacionMu.Lock()
	defer a.actualizacionMu.Unlock()
	return a.actualizacion
}

// comprobarActualizacionXesta consulta a rede e garda o resultado. Chamado
// en fondo (go a.comprobarActualizacionXesta()) dende startup — nunca
// bloquea o arranque. Sen evento en directo (Xesta non ten canle
// Wails/WebSocket cara ao frontend): o panel "Sobre" simplemente pide o
// estado cada vez que se abre.
func (a *App) comprobarActualizacionXesta() {
	estado := comprobarActualizacionXestaRede()
	a.actualizacionMu.Lock()
	a.actualizacion = estado
	a.actualizacionMu.Unlock()
}

func comprobarActualizacionXestaRede() EstadoActualizacionXesta {
	estado := EstadoActualizacionXesta{VersionLocal: VersionLocalXesta()}

	req, err := http.NewRequest(http.MethodGet, urlReleasesXesta, nil)
	if err != nil {
		return estado
	}
	req.Header.Set("Accept", "application/vnd.github+json")

	cliente := http.Client{Timeout: timeoutComprobarXesta}
	resp, err := cliente.Do(req)
	if err != nil {
		return estado
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return estado
	}

	var rels []releaseGitHubXesta
	if err := json.NewDecoder(resp.Body).Decode(&rels); err != nil {
		return estado
	}

	for _, rel := range rels {
		urlZip, nomeZip, urlChecksum := escollerAssetsXesta(rel.Assets)
		if urlZip == "" {
			continue
		}
		versionRemota := versionDesdeNomeZipXesta(nomeZip)
		if versionRemota == "" {
			continue
		}
		estado.VersionRemota = versionRemota
		estado.URLDescarga = urlZip
		estado.URLChecksum = urlChecksum
		estado.Notas = rel.Body
		estado.Disponible = versionMaiorXesta(versionRemota, estado.VersionLocal)
		return estado
	}
	return estado
}

func nomeExecutableXesta() string {
	if runtime.GOOS == "windows" {
		return "xesta.exe"
	}
	return "xesta"
}

func descargarXesta(url, destinoDir, nomeFicheiro string) (string, error) {
	if err := os.MkdirAll(destinoDir, 0o755); err != nil {
		return "", fmt.Errorf("non se puido crear %q: %w", destinoDir, err)
	}
	destino := filepath.Join(destinoDir, nomeFicheiro)

	cliente := http.Client{Timeout: timeoutDescargaXesta}
	resp, err := cliente.Get(url)
	if err != nil {
		return "", fmt.Errorf("non se puido descargar a actualización: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("non se puido descargar a actualización: HTTP %d", resp.StatusCode)
	}

	f, err := os.Create(destino)
	if err != nil {
		return "", fmt.Errorf("non se puido crear %q: %w", destino, err)
	}
	defer f.Close()
	if _, err := io.Copy(f, resp.Body); err != nil {
		return "", fmt.Errorf("non se puido gardar a actualización: %w", err)
	}
	return destino, nil
}

func extraerExecutableXesta(zipRuta, destDir string) (string, error) {
	zr, err := zip.OpenReader(zipRuta)
	if err != nil {
		return "", fmt.Errorf("o ficheiro descargado non é un zip válido: %w", err)
	}
	defer zr.Close()

	buscado := nomeExecutableXesta()
	for _, f := range zr.File {
		if f.FileInfo().IsDir() || filepath.Base(f.Name) != buscado {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			return "", fmt.Errorf("non se puido abrir %q dentro do zip: %w", f.Name, err)
		}
		defer rc.Close()

		destino := filepath.Join(destDir, buscado)
		out, err := os.OpenFile(destino, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
		if err != nil {
			return "", fmt.Errorf("non se puido crear %q: %w", destino, err)
		}
		defer out.Close()
		if _, err := io.Copy(out, rc); err != nil {
			return "", fmt.Errorf("non se puido extraer %q: %w", f.Name, err)
		}
		return destino, nil
	}
	return "", fmt.Errorf("o zip da actualización non contén %q — revisa como o empaquetaches", buscado)
}

func lerHashEsperadoXesta(r io.Reader) (string, error) {
	datos, err := io.ReadAll(io.LimitReader(r, 4096))
	if err != nil {
		return "", fmt.Errorf("non se puido ler o .sha256: %w", err)
	}
	campos := strings.Fields(string(datos))
	if len(campos) == 0 {
		return "", fmt.Errorf("o ficheiro .sha256 da Release está baleiro")
	}
	return strings.ToLower(campos[0]), nil
}

func comprobarChecksumXesta(ficheiroRuta, urlChecksum string) error {
	if urlChecksum == "" {
		return fmt.Errorf("esta Release non publica un .sha256 do .zip — non se pode verificar a súa integridade, así que se cancela a actualización por seguridade")
	}

	cliente := http.Client{Timeout: timeoutComprobarXesta}
	resp, err := cliente.Get(urlChecksum)
	if err != nil {
		return fmt.Errorf("non se puido descargar o .sha256 da actualización: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("non se puido descargar o .sha256 da actualización: HTTP %d", resp.StatusCode)
	}
	esperado, err := lerHashEsperadoXesta(resp.Body)
	if err != nil {
		return err
	}

	f, err := os.Open(ficheiroRuta)
	if err != nil {
		return fmt.Errorf("non se puido abrir %q para verificalo: %w", ficheiroRuta, err)
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return fmt.Errorf("non se puido calcular o SHA-256 de %q: %w", ficheiroRuta, err)
	}
	obtido := hex.EncodeToString(h.Sum(nil))

	if obtido != esperado {
		return fmt.Errorf("o SHA-256 do .zip descargado non coincide co publicado na Release — podería estar adulterado; cancélase a actualización")
	}
	return nil
}

func copiarFicheiroXesta(orixe, destino string) error {
	in, err := os.Open(orixe)
	if err != nil {
		return fmt.Errorf("non se puido abrir %q: %w", orixe, err)
	}
	defer in.Close()
	out, err := os.OpenFile(destino, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return fmt.Errorf("non se puido crear %q: %w", destino, err)
	}
	defer out.Close()
	if _, err := io.Copy(out, in); err != nil {
		return fmt.Errorf("non se puido copiar a %q: %w", destino, err)
	}
	return nil
}

// AplicarActualizacionXesta descarga a última versión de Xesta (estado xa
// coñecido por GetActualizacionXesta), verifica o seu SHA-256 e substitúe o
// executable en disco — NON reinicia o proceso (ver a nota de cabeceira). O
// chamador (frontend) debe avisar o profesorado de pechar e reabrir Xesta
// dende Piztu para usar a versión nova.
func (a *App) AplicarActualizacionXesta() error {
	estado := a.GetActualizacionXesta()
	if !estado.Disponible || estado.URLDescarga == "" {
		return fmt.Errorf("non hai ningunha actualización de Xesta dispoñible")
	}
	if runtime.GOOS == "windows" {
		return fmt.Errorf("a actualización automática aínda non está soportada en Windows")
	}

	exeActual, err := os.Executable()
	if err != nil {
		return fmt.Errorf("non se puido localizar o executable actual: %w", err)
	}
	exeActual, err = filepath.EvalSymlinks(exeActual)
	if err != nil {
		return fmt.Errorf("non se puido resolver o executable actual: %w", err)
	}

	tmpDir, err := os.MkdirTemp("", "xesta-actualizacion-")
	if err != nil {
		return fmt.Errorf("non se puido crear un cartafol temporal: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	zipRuta, err := descargarXesta(estado.URLDescarga, tmpDir, "actualizacion.zip")
	if err != nil {
		return err
	}
	if err := comprobarChecksumXesta(zipRuta, estado.URLChecksum); err != nil {
		return err
	}
	novoExe, err := extraerExecutableXesta(zipRuta, tmpDir)
	if err != nil {
		return err
	}

	swapTmp := exeActual + ".novo"
	defer os.Remove(swapTmp)
	if err := copiarFicheiroXesta(novoExe, swapTmp); err != nil {
		return err
	}

	_ = copiarFicheiroXesta(exeActual, exeActual+".anterior")

	if err := os.Rename(swapTmp, exeActual); err != nil {
		return fmt.Errorf("non se puido instalar o binario novo: %w", err)
	}

	if estado.VersionRemota != "" {
		actualizarVersionModuloJSONXesta(filepath.Dir(exeActual), estado.VersionRemota)
	}
	return nil
}

func actualizarVersionModuloJSONXesta(dirModulo, versionNova string) {
	ruta := filepath.Join(dirModulo, "modulo.json")
	datos, err := os.ReadFile(ruta)
	if err != nil {
		return
	}
	var m map[string]any
	if err := json.Unmarshal(datos, &m); err != nil {
		return
	}
	m["version"] = versionNova
	novosDatos, err := json.MarshalIndent(m, "", "  ")
	if err != nil {
		return
	}
	_ = os.WriteFile(ruta, novosDatos, 0o644)
}
