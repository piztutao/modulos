package main

import (
	"encoding/json"
	"os"
	"path/filepath"
)

// Config garda os axustes locais de Xesta: como falar coa API de Piztu
// (internal/api, ver /docs/api-modulos.md — socket Unix + token, xa non hai
// que adiviñar a ruta a partir de tmp_dir) e a clave/modelo da IA (ex.:
// Google Gemini). Persístese en JSON no directorio de configuración do
// usuario — NUNCA no repositorio nin en control de versións, e con permisos
// 0600 por levar a clave da IA e o token de Piztu.
//
// O token gardado caduca cando Piztu reinicia (as sesións só viven en
// memoria, ver internal/api) ou pasadas as súas horas de validez — non é un
// segredo permanente, só sobrevive a un peche e reapertura de Xesta sen
// pasar por Piztu no medio. Se deixa de valer, ConsultarPiztu falla cun erro
// claro (401 token_invalido) e hai que reabrir Xesta dende Piztu.
type Config struct {
	PiztuSocketPath string `json:"piztu_socket_path"`
	PiztuAPIToken   string `json:"piztu_api_token"`
	GeminiAPIKey    string `json:"gemini_api_key"`
	GeminiModel     string `json:"gemini_model"`
}

// rutaSocketAPIPorDefecto é a mesma convención ca api.NomeSocket en
// piztu/internal/api — Xesta non pode importar ese paquete interno (regra
// de visibilidade de Go para internal/), así que o nome do ficheiro
// duplícase aquí á man. Só se usa como reserva se algún día se abre Xesta
// sen contexto de Piztu nin axustes previos gardados.
func rutaSocketAPIPorDefecto(tmpDir string) string {
	return filepath.Join(tmpDir, "piztu-api.sock")
}

func configPadron() Config {
	return Config{
		PiztuSocketPath: rutaSocketAPIPorDefecto("/opt/piztu/tmp"),
	}
}

func configPath() (string, error) {
	base, err := os.UserConfigDir()
	if err != nil {
		base = os.TempDir()
	}
	dir := filepath.Join(base, "piztu-xesta")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	return filepath.Join(dir, "config.json"), nil
}

func cargarConfig() (Config, error) {
	ruta, err := configPath()
	if err != nil {
		return configPadron(), err
	}
	dados, err := os.ReadFile(ruta)
	if err != nil {
		if os.IsNotExist(err) {
			return configPadron(), nil
		}
		return configPadron(), err
	}
	var c Config
	if err := json.Unmarshal(dados, &c); err != nil {
		return configPadron(), err
	}
	return c, nil
}

func gardarConfig(c Config) error {
	ruta, err := configPath()
	if err != nil {
		return err
	}
	dados, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(ruta, dados, 0o600)
}
