package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"
)

// ScriptGardado é un playbook/estado que o profesorado decidiu conservar
// despois de comprobar que funciona. Vive só en local, na mesma máquina e
// conta de usuario ca config.json (ver bibliotecaPath) — non hai nada
// compartido entre usuarios nin entre Xesta e Piztu. É deliberadamente un
// cambio pequeno e illado: se no futuro se quere compartir entre usuarios,
// iso é unha peza á parte (repo Git + revisión), non isto.
type ScriptGardado struct {
	ID         string `json:"id"`
	Nome       string `json:"nome"`
	Descricion string `json:"descricion"`
	Motor      string `json:"motor"` // "ansible" ou "salt"

	// Peticion é o texto orixinal que se lle pediu á IA (opcional — baleiro
	// se o contido se escribiu/editou a man sen pasar pola IA).
	Peticion string `json:"peticion,omitempty"`
	Contido  string `json:"contido"`

	// FicheiroNome/FicheiroContido son o script/ficheiro de texto que se
	// adxuntou como apoio ao xerar este contido (opcional). Adrede só se
	// gardan ficheiros de TEXTO — nunca imaxes nin binarios, mesma regra que
	// no adxunto orixinal (ver AdxuntoSeleccionado no frontend): así todo o
	// que hai na biblioteca segue sendo lexible e auditable.
	FicheiroNome    string `json:"ficheiro_nome,omitempty"`
	FicheiroContido string `json:"ficheiro_contido,omitempty"`

	Gardado time.Time `json:"gardado"`
}

// biblioteca é o contido completo do ficheiro persistido en disco.
type biblioteca struct {
	Scripts []ScriptGardado `json:"scripts"`
}

// mutexBiblioteca evita que dúas peticións HTTP concorrentes (p.ex. gardar e
// eliminar á vez) corrompan o ficheiro coa clásica condición de carreira
// ler-modificar-escribir — o servidor HTTP de Xesta atende peticións en
// goroutines independentes (ver main.go).
var mutexBiblioteca sync.Mutex

func bibliotecaPath() (string, error) {
	base, err := os.UserConfigDir()
	if err != nil {
		base = os.TempDir()
	}
	dir := filepath.Join(base, "piztu-xesta")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	return filepath.Join(dir, "biblioteca.json"), nil
}

func cargarBiblioteca() (biblioteca, error) {
	ruta, err := bibliotecaPath()
	if err != nil {
		return biblioteca{}, err
	}
	dados, err := os.ReadFile(ruta)
	if err != nil {
		if os.IsNotExist(err) {
			return biblioteca{}, nil
		}
		return biblioteca{}, err
	}
	var b biblioteca
	if err := json.Unmarshal(dados, &b); err != nil {
		return biblioteca{}, err
	}
	return b, nil
}

func gardarBibliotecaEnDisco(b biblioteca) error {
	ruta, err := bibliotecaPath()
	if err != nil {
		return err
	}
	dados, err := json.MarshalIndent(b, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(ruta, dados, 0o600)
}

func novoIDScript() (string, error) {
	buf := make([]byte, 8)
	if _, err := rand.Read(buf); err != nil {
		return "", err
	}
	return hex.EncodeToString(buf), nil
}

// listarBiblioteca devolve os scripts gardados, os máis recentes primeiro.
// Nunca devolve nil: un slice nil serializaría coma JSON "null" en vez de
// "[]", e o frontend rompería ao chamar .length/.filter sobre null.
func listarBiblioteca() ([]ScriptGardado, error) {
	mutexBiblioteca.Lock()
	defer mutexBiblioteca.Unlock()

	b, err := cargarBiblioteca()
	if err != nil {
		return nil, err
	}
	if b.Scripts == nil {
		b.Scripts = []ScriptGardado{}
	}
	sort.Slice(b.Scripts, func(i, j int) bool {
		return b.Scripts[i].Gardado.After(b.Scripts[j].Gardado)
	})
	return b.Scripts, nil
}

// gardarNaBiblioteca engade un script novo. Non hai edición: se o contido
// cambia gárdase coma entrada nova — mantén o historial simple e evita bugs
// de concorrencia por edición parcial dunha entrada existente.
func gardarNaBiblioteca(nome, descricion, motor, peticion, contido, ficheiroNome, ficheiroContido string) (ScriptGardado, error) {
	if nome == "" {
		return ScriptGardado{}, errors.New("o script precisa un nome")
	}
	if contido == "" {
		return ScriptGardado{}, errors.New("o script está baleiro")
	}

	mutexBiblioteca.Lock()
	defer mutexBiblioteca.Unlock()

	id, err := novoIDScript()
	if err != nil {
		return ScriptGardado{}, err
	}
	entrada := ScriptGardado{
		ID:              id,
		Nome:            nome,
		Descricion:      descricion,
		Motor:           motor,
		Peticion:        peticion,
		Contido:         contido,
		FicheiroNome:    ficheiroNome,
		FicheiroContido: ficheiroContido,
		Gardado:         time.Now(),
	}

	b, err := cargarBiblioteca()
	if err != nil {
		return ScriptGardado{}, err
	}
	b.Scripts = append(b.Scripts, entrada)
	if err := gardarBibliotecaEnDisco(b); err != nil {
		return ScriptGardado{}, err
	}
	return entrada, nil
}

// eliminarDaBiblioteca quita un script polo seu ID.
func eliminarDaBiblioteca(id string) error {
	mutexBiblioteca.Lock()
	defer mutexBiblioteca.Unlock()

	b, err := cargarBiblioteca()
	if err != nil {
		return err
	}

	restantes := b.Scripts[:0]
	atopado := false
	for _, s := range b.Scripts {
		if s.ID == id {
			atopado = true
			continue
		}
		restantes = append(restantes, s)
	}
	if !atopado {
		return errors.New("non se atopou ese script na biblioteca")
	}

	b.Scripts = restantes
	return gardarBibliotecaEnDisco(b)
}
