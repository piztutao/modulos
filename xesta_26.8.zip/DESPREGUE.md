# Xesta — despregue

Xesta é unha app Wails normal (xanela propia, ponte JS↔Go nativa — mesmo
patrón ca Tao/Pancho). Chegou a ser un servidor HTTP local (`127.0.0.1:5510`)
incrustado nun `<iframe>` dentro de Piztu; volveuse ao modelo de xanela
propia porque aquel servidor non tiña autenticación ningunha (calquera
proceso local podía chamar á súa API, incluído `/api/executar`).

Fala con Piztu por `piztuclient` sobre `piztu-api.sock` (socket Unix +
token por sesión, ver `docs/api-modulos.md`) para consultar o motor
activo/equipos e executar contido — non hai porto TCP nin socket propio de
Xesta que outro proceso local poida tocar.

Non hai selector de ficheiros nativo aínda: a imaxe de apoio escóllese cun
`<input type="file">` normal do navegador (o frontend segue sendo web, só
que embebido nunha xanela Wails en vez de servido por HTTP).

## Compilar

```sh
cd xesta && wails build -tags gtk3   # -tags gtk3 necesario en Debian 12
# → xesta/build/bin/xesta
```

## Instalación manual

```sh
# Nunha instalación xa feita, con base_dir=/opt/piztu (ou o que teñas):
mkdir -p /opt/piztu/modulos/xesta
cp xesta/build/bin/xesta  /opt/piztu/modulos/xesta/xesta
cp xesta/modulo.json      /opt/piztu/modulos/xesta/modulo.json
cp xesta/panel.yaml       /opt/piztu/modulos/xesta/panel.yaml
chmod +x /opt/piztu/modulos/xesta/xesta
```

## Configuración necesaria antes do primeiro uso

Ningunha da parte de quen administra Piztu: o socket e o token de
`piztu-api.sock` chegan xa incluídos no contexto de arranque cada vez que
Piztu lanza Xesta (ver `ContextoModulo`/`escribirContexto` en
`piztu/app.go` e `contexto.go`) — ninguén ten que escribir nada á man.

O único que cada profesor/a configura dentro da propia interface de Xesta é
a súa clave da IA (ex.: Google Gemini), en ⚙ Axustes.

Se Xesta se abre sen pasar por Piztu (desenvolvemento, executando
`./build/bin/xesta` á man), non hai socket de Piztu coñecido — a sección
"Avanzado" de ⚙ Axustes permite escribir a ruta do socket e o token a man
coma alternativa.

## Pendente (próximo incremento, se se quere)

Automatizar a instalación coma un paso opcional do instalador
(`installer/main.go`), igual que os Pasos 7/8 fan con Tao.
