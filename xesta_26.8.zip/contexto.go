package main

import (
	"encoding/json"
	"os"
)

// contextoModulo é o subconxunto do contrato que Piztu escribe ao lanzar un
// módulo externo (ver ContextoModulo/escribirContexto en piztu/app.go).
// APISocket/APIToken son a porta de entrada á API en marcha (internal/api,
// ver /docs/api-modulos.md) — substitúen o vello cálculo manual da ruta do
// socket a partir de TmpDir (que xa non abonda: agora hai que autenticarse
// cun token, non abondaba con coñecer a ruta).
type contextoModulo struct {
	Motor       string            `json:"motor"`
	TmpDir      string            `json:"tmp_dir"`
	Axustes     map[string]string `json:"axustes"`
	APISocket   string            `json:"api_socket"`
	APIToken    string            `json:"api_token"`
	APIPermisos []string          `json:"api_permisos"`
	// Idioma é o código (gl/es/en/pt) que o profesorado ten escollido en ⚙ Aula
	// para o propio Piztu — Xesta úsao coma valor por defecto do seu idioma
	// (ver App.Idioma, api.go GET /api/idioma), non coma unha orde: unha
	// elección explícita xa gardada no navegador (localStorage) segue tendo
	// prioridade.
	Idioma string `json:"idioma"`
}

// lerContextoLanzamento intenta ler o contexto que Piztu escribiu ao abrir
// Xesta (variable de contorno PIZTU_CONTEXTO, ver lanzarAplicacion en
// piztu/app.go). Devolve ok=false se Xesta se abriu sen pasar por Piztu
// (ex.: en desenvolvemento, executando o binario á man) — nese caso Xesta
// cae aos axustes gardados a man en Axustes dentro da propia app.
func lerContextoLanzamento() (contextoModulo, bool) {
	var ctx contextoModulo
	ruta := os.Getenv("PIZTU_CONTEXTO")
	if ruta == "" {
		return ctx, false
	}
	dados, err := os.ReadFile(ruta)
	if err != nil {
		return ctx, false
	}
	if err := json.Unmarshal(dados, &ctx); err != nil {
		return ctx, false
	}
	return ctx, true
}
